// Function : get role details from role table
// Author   : Gadha PS, Anju Varghese
// Division : COM/CIG
// Date     : 28/01/2009

import java.io.*;
import java.util.*;
import java.util.Date;
import java.text.*;
import java.lang.String;
import java.sql.*;
import java.net.*;
import javax.servlet.*;
import javax.servlet.http.*;
import org.apache.log4j.Logger;
import dateform.*;

public class getPrintObservation extends HttpServlet {
    
    protected void doGet(HttpServletRequest request, HttpServletResponse response)
    throws ServletException, IOException {
        doPost(request,response);
    }
    
    protected void doPost(HttpServletRequest request, HttpServletResponse response)
    throws ServletException, IOException {
        
        RequestDispatcher view = null;
        PrintWriter out= response.getWriter();
        dbConn db=new dbConn();
        dateformat d1=new dateformat();
      //  Logger //objLog = Logger.getLogger("ApplicationDO");
        try
{
            Connection conn= null;
            conn = db.Connect();
            Statement stmt = conn.createStatement();
            ResultSet rs1=null;
            ArrayList arObserve=new ArrayList(); //observation
            String strFlag="invalidSession", strQuery="", strStartDate="", strEndDate="", strStartDate1="", strEndDate1="", strRemarks="", strRole="";
            
            // Get session
            HttpSession curSession=request.getSession(false);
            // Check if valid session
            if(curSession==null)
{
                //objLog.error("Invalid session");
                request.setAttribute("flag",strFlag);
                view=request.getRequestDispatcher("sessionError.jsp");
                view.forward(request, response);
            }
            
            else //valid session
            {
                if((String)curSession.getAttribute("userid")==null)
{
                    //objLog.error("Invalid session");
                    request.setAttribute("flag",strFlag);
                    view=request.getRequestDispatcher("sessionError.jsp");
                    view.forward(request, response);
                }
                else
                {
                     strStartDate1=request.getParameter("txtStartdate");
                    strStartDate=d1.savedate(strStartDate1);
                    strEndDate1=request.getParameter("txtEnddate");  
                    strEndDate=d1.savedate(strEndDate1);
                    
                    strRole=request.getParameter("role");  
                    //objLog.info("Role: "+strRole);
                    
                    strQuery="select observation, actionreqd, actiontaken,dutydate, shift from observations where dutydate between '"+strStartDate+"' and '"+strEndDate+"' order by dutydate, shift, slno";
                    rs1=stmt.executeQuery(strQuery);                        
                    //objLog.info(strQuery);
                    while (rs1.next())
                    {                
                        arObserve.add(d1.datedisplay(rs1.getString(4)));
                        arObserve.add(rs1.getString(5));
                        arObserve.add(rs1.getString(1));
                        arObserve.add(rs1.getString(2));
                        arObserve.add(rs1.getString(3));

                    }    
                    rs1.close();
                    
                    //get Remarks if present
                    
                    strQuery="select remarks from iocremarks where startdate='"+strStartDate+"' and enddate='"+strEndDate+"' and remarkno in (select max(remarkno) from iocremarks where startdate='"+strStartDate+"' and enddate='"+strEndDate+"')";
                    rs1=stmt.executeQuery(strQuery);                        
                    //objLog.info(strQuery);
                   if (rs1.next())
                    {                
                        strRemarks=rs1.getString(1);
                    }    
                    rs1.close();
                    
                    request.setAttribute("StartDate",strStartDate1);
                     request.setAttribute("EndDate",strEndDate1);
                     request.setAttribute("remarks",strRemarks);
                      request.setAttribute("arObserve",arObserve);
                      
                      if (strRole.equals("IOC"))
                      {
                        view = request.getRequestDispatcher("previewObservation.jsp");      
                      }
                      else
                      {
                          view = request.getRequestDispatcher("previewObservationHead.jsp");      
                      }
                    view.forward(request, response);
                }
            }
        }
catch(Exception e)
{
    //objLog.error("ERROR : "+e);
    view = request.getRequestDispatcher("Failure.jsp");
    view.forward(request, response);
}
finally
{
    db.close();
}
    }
}
