// Function : get role details from role table
// Author   : Gadha PS, Anju Varghese
// Division : COM/CIG
// Date     : 28/01/2009

import java.io.*;
import java.util.*;
import java.util.Date;
import java.text.*;
import java.lang.String;
import java.sql.*;
import java.net.*;
import javax.servlet.*;
import javax.servlet.http.*;
import org.apache.log4j.Logger;
import dateform.*;

public class getDutyHistory extends HttpServlet {
    
    protected void doGet(HttpServletRequest request, HttpServletResponse response)
    throws ServletException, IOException {
        doPost(request,response);
    }
    
    protected void doPost(HttpServletRequest request, HttpServletResponse response)
    throws ServletException, IOException {
        
        RequestDispatcher view = null;
        PrintWriter out= response.getWriter();
        dbConn db=new dbConn();
        dateformat d1=new dateformat();
       // Logger //objLog = Logger.getLogger("ApplicationDO");
        try
{
            Connection conn= null;
            conn = db.Connect();
            Statement stmt = conn.createStatement();
            Statement stmt2 = conn.createStatement();
            ResultSet rs1=null, rs2=null;
            String strFlag="invalidSession",strQuery="",strStaffcode="",strRoleFlag="", strName="";
            ArrayList arhistory=new ArrayList();
            
            // Get session
            HttpSession curSession=request.getSession(false);
            // Check if valid session
            if(curSession==null)
{
                //objLog.error("Invalid session");
                request.setAttribute("flag",strFlag);
                view=request.getRequestDispatcher("sessionError.jsp");
                view.forward(request, response);
            }
            
            else //valid session
            {
                if((String)curSession.getAttribute("userid")==null)
{
                    //objLog.error("Invalid session");
                    request.setAttribute("flag",strFlag);
                    view=request.getRequestDispatcher("sessionError.jsp");
                    view.forward(request, response);
                }
                else
                {
                    strRoleFlag= request.getParameter("link");
                    //objLog.info("Role Flag: "+strRoleFlag);
                    if(strRoleFlag.equals("AO"))
                    {
                        strStaffcode=request.getParameter("txtStaffcode");
                    }
                    else
                    {
                         strStaffcode=(String)curSession.getAttribute("userid");
                    }
                    
                    //get name
                    strQuery="select empname from dodetails where empcode='"+strStaffcode+"'";
                    rs1=stmt.executeQuery(strQuery);
                    if (rs1.next())
                    {
                          strName=rs1.getString(1);         
                     }
                    else
                    {
                        strQuery="select empname from reservelist where empcode='"+strStaffcode+"'";
                        rs2=stmt2.executeQuery(strQuery);
                        if (rs2.next())
                        {
                          strName=rs2.getString(1);         
                        }
                        rs2.close();
                    }
                    rs1.close();
                    
                    
                    strQuery="select scheduledate,shift,logindatetime from doschedule where empcode='"+strStaffcode+"' order by scheduledate desc ";
                    rs1=stmt.executeQuery(strQuery);
                    while (rs1.next())
                    {
                        arhistory.add(d1.datedisplay(rs1.getString(1)));
                        arhistory.add(rs1.getString(2));
                        arhistory.add(rs1.getString(3));                       
                     }
                    rs1.close();
                    
                     strQuery="select dutydate,shift,logindatetime from reservedutydone where empcode='"+strStaffcode+"' order by dutydate desc ";
                    rs1=stmt.executeQuery(strQuery);
                    while (rs1.next())
                    {
                        arhistory.add(d1.datedisplay(rs1.getString(1)));
                        arhistory.add(rs1.getString(2));
                        arhistory.add(rs1.getString(3));                       
                     }
                    rs1.close();
                    
                    request.setAttribute("empname",strName);
                    request.setAttribute("staffcode",strStaffcode);
                    request.setAttribute("arHistory",arhistory);
                    view = request.getRequestDispatcher("viewDutyHistory.jsp");
                    view.forward(request, response);
                }
            }
        }
catch(Exception e)
{
    //objLog.error("ERROR : "+e);
    view = request.getRequestDispatcher("Failure.jsp");
    view.forward(request, response);
}
finally
{
    db.close();
}
    }
}
