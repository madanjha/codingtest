// Function : get role details from role table
// Author   : Gadha PS, Anju Varghese
// Division : COM/CIG
// Date     : 28/01/2009

import java.io.*;
import java.util.*;
import java.util.Date;
import java.text.*;
import java.lang.String;
import java.sql.*;
import java.net.*;
import javax.servlet.*;
import javax.servlet.http.*;
import org.apache.log4j.Logger;
import dateform.*;

public class savePrintObservation extends HttpServlet {

    protected void doGet(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        doPost(request, response);
    }

    protected void doPost(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {

        RequestDispatcher view = null;
        PrintWriter out = response.getWriter();
        dbConn db = new dbConn();
        dateformat d1 = new dateformat();
       // Logger //objLog = Logger.getLogger("ApplicationDO");
        try {
            Connection conn = null;
            conn = db.Connect();
            Statement stmt = conn.createStatement();
            ResultSet rs1 = null;
            ArrayList arObserve = new ArrayList(); //observation
            String strFlag = "invalidSession", strQuery = "", strStartDate = "", strEndDate = "", strStartDate1 = "", strEndDate1 = "", strRemarks = "";
            int count = 1, maxid = 0;

            // Get session
            HttpSession curSession = request.getSession(false);
            // Check if valid session
            if (curSession == null) {
                //objLog.error("Invalid session");
                request.setAttribute("flag", strFlag);
                view = request.getRequestDispatcher("sessionError.jsp");
                view.forward(request, response);
            } else //valid session
            {
                if ((String) curSession.getAttribute("userid") == null) {
                    //objLog.error("Invalid session");
                    request.setAttribute("flag", strFlag);
                    view = request.getRequestDispatcher("sessionError.jsp");
                    view.forward(request, response);
                } else {
                    strStartDate1 = request.getParameter("startdate");
                    strStartDate = d1.savedate(strStartDate1);
                    strEndDate1 = request.getParameter("enddate");
                    strEndDate = d1.savedate(strEndDate1);

                    strRemarks = request.getParameter("txtRemarks");
                    //  count=Integer.parseInt(request.getParameter("count"));
                    // //objLog.info("count: "+count);

                    strQuery = "select observation, actionreqd, actiontaken,dutydate, shift from observations where dutydate between '" + strStartDate + "' and '" + strEndDate + "' ";
                    rs1 = stmt.executeQuery(strQuery);
                    //objLog.info(strQuery);
                    while (rs1.next()) {
                        if (request.getParameter("chkSelect" + new Integer(count).toString()) != null) {
                            arObserve.add(d1.datedisplay(rs1.getString(4)));
                            arObserve.add(rs1.getString(5));
                            arObserve.add(rs1.getString(1));
                            arObserve.add(rs1.getString(2));
                            arObserve.add(rs1.getString(3));
                        }
                        count += 1;

                    }
                    rs1.close();

                    //save remarks

                    strQuery = "select max(remarkno) as maxcode from iocremarks";
                    rs1 = stmt.executeQuery(strQuery);
                    if (rs1.next()) {
                        maxid = rs1.getInt("maxcode");
                        maxid = maxid + 1;
                    } else {
                        maxid = 1;
                    }
                    rs1.close();

                    strQuery = "insert into iocremarks values ('" + maxid + "', '" + strStartDate + "', '" + strEndDate + "', '" + strRemarks + "')";
                    stmt.executeUpdate(strQuery);

                    request.setAttribute("StartDate", strStartDate1);
                    request.setAttribute("EndDate", strEndDate1);
                    request.setAttribute("remarks", strRemarks);
                    request.setAttribute("arObserve", arObserve);
                    view = request.getRequestDispatcher("previewSelectObservation.jsp");
                    view.forward(request, response);
                }
            }
        } catch (Exception e) {
            //objLog.error("ERROR : " + e);
            view = request.getRequestDispatcher("Failure.jsp");
            view.forward(request, response);
        } finally {
            db.close();
        }
    }
}
