// Function : get role details from role table
// Author   : Gadha PS, Anju Varghese
// Division : COM/CIG
// Date     : 28/01/2009

import java.io.*;
import java.util.*;
import java.util.Date;
import java.text.*;
import java.lang.String;
import java.sql.*;
import java.net.*;
import javax.servlet.*;
import javax.servlet.http.*;
import org.apache.log4j.Logger;
import dateform.*;


import java.util.Properties;
import javax.mail.Authenticator;
import javax.mail.Message;
import javax.mail.PasswordAuthentication;
import javax.mail.Session;
import javax.mail.Transport;
import javax.mail.internet.InternetAddress;
import javax.mail.internet.MimeMessage;
import java.io.*;
public class requestExchangeDO extends HttpServlet {
    
    protected void doGet(HttpServletRequest request, HttpServletResponse response)
    throws ServletException, IOException {
        doPost(request,response);
    }
    
    
    class ThePasswordAuthenticator extends Authenticator {
		String user;
		String pw;
		public ThePasswordAuthenticator(String username, String password) {
			super();
			this.user = username;
			this.pw = password;
		}
		public PasswordAuthentication getPasswordAuthentication() {
			return new PasswordAuthentication(user, pw);
		}
    }
    
    protected void doPost(HttpServletRequest request, HttpServletResponse response)
    throws ServletException, IOException {
        
        RequestDispatcher view = null;
        PrintWriter out= response.getWriter();
        dbConn db=new dbConn();
        dateformat d1=new dateformat();
      //  Logger //objLog = Logger.getLogger("ApplicationDO");
        try
{
            Connection conn= null;
            conn = db.Connect();
            Statement stmt = conn.createStatement();
            Statement stmt2 = conn.createStatement();
            Statement stmt3 = conn.createStatement();
            ResultSet rs1=null, rs2=null;
            String strFlag="invalidSession";
             String strExStaffcode="",strExDutydate="",strExShift="",strShift="",strDutydate="", strQuery="", strStaffcode="";
             String strDivision="", strName="", strExName="", strExDivision="", strExMail="", mailPath="";
            
            // Get session
            HttpSession curSession=request.getSession(false);
            // Check if valid session
            if(curSession==null)
            {
                //objLog.error("Invalid session");
                request.setAttribute("flag",strFlag);
                view=request.getRequestDispatcher("sessionError.jsp");
                view.forward(request, response);
            }
            
            else //valid session
            {
                if((String)curSession.getAttribute("userid")==null)
                 {
                    //objLog.error("Invalid session");
                    request.setAttribute("flag",strFlag);
                    view=request.getRequestDispatcher("sessionError.jsp");
                    view.forward(request, response);
                }
                else
                {
                    strStaffcode=request.getParameter("strStaffcode");
                    strShift=request.getParameter("newShift");
                    strDutydate=request.getParameter("newDate");  
                    strDutydate=d1.savedate(strDutydate);
                    strDivision=request.getParameter("strDivision");
                    strName=request.getParameter("strName");
                   
                    strExStaffcode=request.getParameter("cboStaffcode");
                    strExShift=request.getParameter("txtShift");
                    strExDutydate=request.getParameter("txtDate");  
                    strExDutydate=d1.savedate(strExDutydate);       
                    strExName=request.getParameter("txtName");  
                    strExDivision=request.getParameter("txtDivision");  
                                      
                    //reset confirm flag of strStaffcode to N
                    stmt.executeUpdate("update doschedule set confirm='N' where empcode='"+strStaffcode+"' and scheduledate='"+strDutydate+"'");
                    
                    //send mail  
                    //after sending mail redirect to requestExchangeDO.jsp with strExName
                    
                    //get emailid of strExStaffcode
                    
                    strQuery="select email from empemail where scno='"+strExStaffcode+"'";
                    rs1=stmt.executeQuery(strQuery);
                    if (rs1.next())
                    {
                        strExMail=rs1.getString(1);
                        //objLog.info("Email id: "+strExMail);
                        
                         //update exchange flag to 1 
                        //    strQuery="select * from exchangedo where scheduledate='"+strDutydate+"' and ((empcode1='"+strStaffcode+"' and empcode2='"+strExStaffcode+"') or (empcode2='"+strStaffcode+"' and empcode1='"+strExStaffcode+"'))";
                        strQuery="select * from exchangedo where scheduledate='"+strDutydate+"' and empcode1='"+strStaffcode+"' and empcode2='"+strExStaffcode+"'";
                        //objLog.info(strQuery);
                        rs2=stmt2.executeQuery(strQuery);
                        if(rs2.first())
                        {
                           // stmt.executeUpdate("update exchangedo set exchangeflag ='1' where scheduledate='"+strDutydate+"' and ((empcode1='"+strStaffcode+"' and empcode2='"+strExStaffcode+"') or (empcode2='"+strStaffcode+"' and empcode1='"+strExStaffcode+"'))");
                         stmt3.executeUpdate("update exchangedo set exchangeflag ='1' where scheduledate='"+strDutydate+"' and empcode1='"+strStaffcode+"' and empcode2='"+strExStaffcode+"'");
                        }
                        else
                        {
                            stmt3.executeUpdate("insert into exchangedo values ('"+strDutydate+"','"+strStaffcode+"', '"+strExStaffcode+"','1')");
                        }
                        rs2.close();                    
                   
                    }                    
                    rs1.close();
                    
                     strDutydate = d1.datedisplay(strDutydate);
                    
                    if (!strExMail.equals(""))
                    {
                        //mailPath="http://10.41.6.137:8080/VDOS/der.do?emailid="+strExMail+"&name="+strName+"&dutydate="+strDutydate+"&shift="+strShift;
                        /*NEW CODE*/
                         
                         
                        String mailer = "myprogram";
			//comma separated list of recipients.
			//String to = "shiny@lpscv.dos.gov.in";
			String cc = null;
			String bcc = null;
			String from = "doadmin@lpscv.dos.gov.in";
			String subject = "(TESTING -PLEASE IGNORE THIS MAIL) LPSC Duty Officer System � Request to exchange duty";
			//String body = "LPSC Duty Officer System � Request to Exchange duty.\r\n"+
			//"Sent on: " + new Date() + "\r\n";
                     
                     
                        String smtpserver = "lpscv.dos.gov.in";
			String smtpport = "25";
			//my username for smtp.att.yahoo.com was a fully
			//qualified email, like joel@att.com.
			String user = "doadmin";
			//String password = "s1s2i3";
			String password = "lpsc1234";
                        Properties props = new Properties();
			//default to "localhost"
			props.put("mail.smtp.host", smtpserver);
			//default to "25"
			props.put("mail.smtp.port", smtpport);
			//uncomment to turn on debugging output which can be useful.
			//props.put("mail.debug", "true");
			//javax.mail.Session
			
			Session session = null;
			if (user != null && password != null)
                        {
                                    props.put("mail.smtp.auth", "true");
                                    session =Session.getInstance(props,new ThePasswordAuthenticator(user,password));
			}
                    
                         Message msg = new MimeMessage(session);
                         try
                         {
		         
                             String body ="Sir/Madam, (TESTING -PLEASE IGNORE THIS MAIL)"+strName+"has been requested to exchange his/her duty on"+strDutydate+","+strShift+"shift with your duty";
                             
                             String body1= "To access LPSC Duty Officer System(LPSCDOS), click on the link below: \n"+
                                           //"http://10.101.2.153:8080/LPSCDOS/login.jsp \n"+
                                           "http://X/LPSCDOS/login.jsp \n"+
                                            "Please login to the above system to record your willingness to exchange duty."+
                                           "Regards \n "+
                                           "System Administrator \n "+
                                           "NOTE:- This is an auto-generated mail. Do not reply to this mail.";
                        
                              body=body +  body1;
                                      
                                                                  
                            msg.setFrom(new InternetAddress(from));
                            msg.setRecipients(Message.RecipientType.TO,InternetAddress.parse(strExMail, false));
                            if (cc != null)
                            msg.setRecipients(Message.RecipientType.CC,InternetAddress.parse(cc, false));
                            if (bcc != null)
                            msg.setRecipients(Message.RecipientType.BCC,InternetAddress.parse(bcc, false));
                            //subject line.
                            msg.setSubject(subject);
                            //set the body of the message, also consider setContent()
                            //for Multipart content
                            msg.setText(body);
                            //the name of your program.
                            msg.setHeader("X-Mailer", mailer);
                            //Date sent from this computer.
                            msg.setSentDate(new Date());
                            // send the message!
                            Transport.send(msg);
                            System.out.println("\nMail was sent successfully.");
                                 
                      }
                      catch (Exception e) 
                      {
			    System.out.println("Error: " + e.getMessage());
                            //view = request.getRequestDispatcher("requestExchangeDOExptMailLPSC.jsp"); 
                           view = request.getRequestDispatcher("requestExchangeDOMailNotSndLPSC.jsp");
                            view.forward(request, response);
                          
		      }
                       /*NEW CODE*/ 
                     
   			//objLog.info("PATH for sending mail : "+mailPath);
                       // response.sendRedirect(mailPath);
                    }
                    else
                    {
                            //objLog.info("Mail id doesnt exist");
                            request.setAttribute("strExName", strExName);
                            view = request.getRequestDispatcher("requestExchangeDONoMail.jsp");                     
                            view.forward(request, response); 
                    }
                   
                           //request.setAttribute("strExName", strExName);
                            view = request.getRequestDispatcher("requestExchangeDO.jsp");                     
                            view.forward(request, response);                   
                    
                }
            }
        }
catch(Exception e)
{
    //objLog.error("ERROR : "+e);
    view = request.getRequestDispatcher("Failure.jsp");
    view.forward(request, response);
}
finally
{
    db.close();
}
    }
}
