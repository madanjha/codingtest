// Function : get role details from role table
// Author   : Gadha PS, Anju Varghese
// Division : COM/CIG
// Date     : 28/01/2009

import java.io.*;
import java.util.*;
import java.util.Date;
import java.text.*;
import java.lang.String;
import java.sql.*;
import java.net.*;
import javax.servlet.*;
import javax.servlet.http.*;
import org.apache.log4j.Logger;
import dateform.*;

public class getExemptDetails extends HttpServlet {
    
    protected void doGet(HttpServletRequest request, HttpServletResponse response)
    throws ServletException, IOException {
        doPost(request,response);
    }
    
    protected void doPost(HttpServletRequest request, HttpServletResponse response)
    throws ServletException, IOException {
        
        RequestDispatcher view = null;
        PrintWriter out= response.getWriter();
        dbConn db=new dbConn();
        dateformat d1=new dateformat();
     //   Logger //objLog = Logger.getLogger("ApplicationDO");
        try
{
            Connection conn= null;
            conn = db.Connect();
            Statement stmt = conn.createStatement();
            ResultSet rs1=null;
            ArrayList arrDetails=new ArrayList();
            String strFlag="invalidSession", strStaffcode="", strQuery="", strPermitFlag="true", strScDate="";
            
            // Get session
            HttpSession curSession=request.getSession(false);
            // Check if valid session
            if(curSession==null)
{
                //objLog.error("Invalid session");
                request.setAttribute("flag",strFlag);
                view=request.getRequestDispatcher("sessionError.jsp");
                view.forward(request, response);
            }
            
            else //valid session
            {
                if((String)curSession.getAttribute("userid")==null)
{
                    //objLog.error("Invalid session");
                    request.setAttribute("flag",strFlag);
                    view=request.getRequestDispatcher("sessionError.jsp");
                    view.forward(request, response);
                }
                else
                {
                    strStaffcode=request.getParameter("txtStaffcode1");
                    
                    //check if he is in scheduled list
                    strQuery="select * from doschedule where empcode='"+strStaffcode+"' and scheduledate>=curdate()";
                    rs1=stmt.executeQuery(strQuery);
                    if (rs1.next())
                    {
                        strPermitFlag="false";
                        strScDate=rs1.getString("scheduledate");
                        strScDate=d1.datedisplay(strScDate);
                    }
                    
                    strQuery="select empname,division, designation, sex,excludefromdate,excludetilldate,datediff(excludetilldate, curdate()),  eligibility, shift, remarks from dodetails where empcode='"+strStaffcode+"'";
                    rs1=stmt.executeQuery(strQuery);
                    if (rs1.next())
                    {
                        arrDetails.add(rs1.getString(1));
                         arrDetails.add(rs1.getString(2));
                          arrDetails.add(rs1.getString(3));
                           arrDetails.add(rs1.getString(4));
                           arrDetails.add(d1.datedisplay(rs1.getString(5)));
                           arrDetails.add(d1.datedisplay(rs1.getString(6)));
                           if (rs1.getInt(7)<0)  //show exclude till date only if greater than current date
                           {
                               arrDetails.add("false");
                           }
                           else
                           {
                                arrDetails.add("true");
                           }
                           
                           arrDetails.add(rs1.getString(8));
                           arrDetails.add(rs1.getString(9));
                           arrDetails.add(rs1.getString(10));
                    }
                    rs1.close();
                    
                     request.setAttribute("staffcode",strStaffcode);
                    request.setAttribute("arrDetails",arrDetails);
                    request.setAttribute("permitFlag",strPermitFlag);
                    request.setAttribute("scdate",strScDate);
                   
                    view = request.getRequestDispatcher("exemptDO.jsp");
                    view.forward(request, response);
                }
            }
        }
catch(Exception e)
{
    //objLog.error("ERROR : "+e);
    view = request.getRequestDispatcher("Failure.jsp");
    view.forward(request, response);
}
finally
{
    db.close();
}
    }
}
