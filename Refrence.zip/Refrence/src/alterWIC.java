/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
// Function : get new user details from sysuser table
// Author   : Gadha PS, Anju Varghese
// Division : COM/CIG
// Date     : 28/01/2009

import java.io.*;
import java.util.*;
import java.util.Date;
import java.text.*;
import java.lang.String;
import java.sql.*;
import java.net.*;
import javax.servlet.*;
import javax.servlet.http.*;
import org.apache.log4j.Logger;
import dateform.*;
public class alterWIC extends HttpServlet {

    protected void doGet(HttpServletRequest request, HttpServletResponse response)
    throws ServletException, IOException {
        doPost(request,response);
    }

    protected void doPost(HttpServletRequest request, HttpServletResponse response)
    throws ServletException, IOException {

        RequestDispatcher view = null;
        PrintWriter out= response.getWriter();
        dbConn db=new dbConn();
        dateformat d1=new dateformat();
      //  Logger //objLog = Logger.getLogger("ApplicationDO");
        String strQuery="",strScheduledate="",strEmpcode="";
        try
{
            Connection conn= null;
            conn = db.Connect();
            Statement stmt = conn.createStatement();
        
            ResultSet rs1=null;
            String strFlag="invalidSession",strEmpname="",strScheduledToDate="";

            ArrayList arrWIC=new ArrayList();

            // Get session
            HttpSession curSession=request.getSession(false);
            // Check if valid session
            if(curSession==null)
            {
                //objLog.error("Invalid session");
                request.setAttribute("flag",strFlag);
                view=request.getRequestDispatcher("sessionError.jsp");
                view.forward(request, response);
            }

            else //valid session
            {
                strScheduledate=request.getParameter("scheduledate");
                request.setAttribute("scheduledate",strScheduledate);
			strEmpname=request.getParameter("empname");
				strEmpcode=request.getParameter("empcode");

			strScheduledToDate=request.getParameter("scheduledtodate");
		    request.setAttribute("scheduledtodate",strScheduledToDate);
		    request.setAttribute("empname",strEmpname);

                strQuery="select empcode,empname,division from sysuser where empcode in (select distinct empcode from wicdetails where empcode!='"+strEmpcode+"')";
                //objLog.info(strQuery);
                rs1=stmt.executeQuery(strQuery);
                  while(rs1.next())
                  {
                      arrWIC.add(rs1.getString("empcode")); //objLog.info(rs1.getString("empcode"));
                      arrWIC.add(rs1.getString("empname"));//objLog.info(rs1.getString("empname"));
                      arrWIC.add(rs1.getString("division"));//objLog.info(rs1.getString("division"));

                  }
                    rs1.close();  
                request.setAttribute("arrWIC",arrWIC);
                view=request.getRequestDispatcher("editWIC.jsp");
                view.forward(request, response);
            }
        }
catch(Exception e)
{
    //objLog.error("ERROR : "+e);
    view = request.getRequestDispatcher("Failure.jsp");
    view.forward(request, response);
}
finally
{
    db.close();
}
}
}
