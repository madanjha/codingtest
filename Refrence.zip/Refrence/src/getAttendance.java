// Function : get role details from role table
// Author   : Gadha PS, Anju Varghese
// Division : COM/CIG
// Date     : 28/01/2009

import java.io.*;
import java.util.*;
import java.util.Date;
import java.text.*;
import java.lang.String;
import java.sql.*;
import java.net.*;
import javax.servlet.*;
import javax.servlet.http.*;
import org.apache.log4j.Logger;
import dateform.*;

public class getAttendance extends HttpServlet {
    
    protected void doGet(HttpServletRequest request, HttpServletResponse response)
    throws ServletException, IOException {
        doPost(request,response);
    }
    
    protected void doPost(HttpServletRequest request, HttpServletResponse response)
    throws ServletException, IOException {
        
        RequestDispatcher view = null;
        PrintWriter out= response.getWriter();
        dbConn db=new dbConn();
        dateformat d1=new dateformat();
       Logger objLog = Logger.getLogger("ApplicationDO");
        try
{
            Connection conn= null;            
            conn = db.Connect();
            Statement stmt = conn.createStatement();
            Statement stmt2 = conn.createStatement();
                 Statement stmt3=conn.createStatement();
                      Statement stmt4 = conn.createStatement();
            ResultSet rs1=null, rs2=null;            
            String strFlag="invalidSession";
             ArrayList arSchedule=new ArrayList(); //schedule
              ArrayList arRow=new ArrayList(); //row span
             String strStartDate1="", strStartDate="",strEndDate1="",strEndDate="", strQuery="", strPath="", strEmpcode="", strDutydate="", strShift="";
             String prevdate="", newdate="", newshift="";
             int fcount=0, scount=0;
            // Get session
            HttpSession curSession=request.getSession(false);
            // Check if valid session
            if(curSession==null)
{
                //objLog.error("Invalid session");
                request.setAttribute("flag",strFlag);
                view=request.getRequestDispatcher("sessionError.jsp");
                view.forward(request, response);
            }
            
            else //valid session
            {
                if((String)curSession.getAttribute("userid")==null)
{
                    //objLog.error("Invalid session");
                    request.setAttribute("flag",strFlag);
                    view=request.getRequestDispatcher("sessionError.jsp");
                    view.forward(request, response);
                }
                else
                {
                    strPath=request.getParameter("path");
                    //objLog.info("Path: "+strPath);
                    
                    if (strPath.equals("default"))
                    {
                        strQuery="select startdate, enddate from scheduledetails where status='PREV'";
                        rs1=stmt.executeQuery(strQuery);
                        if (rs1.next())
                        {
                            strStartDate=rs1.getString(1);        
                            strStartDate1=d1.datedisplay(strStartDate);
                            strEndDate=rs1.getString(2);
                            strEndDate1=d1.datedisplay(strEndDate);
                        }
                        rs1.close();
                    }
                    else if(strPath.equals("mark"))
                    {//objLog.info("in path mark");
                          strStartDate1 = (String)request.getAttribute("StartDate");
                          strStartDate=d1.savedate(strStartDate1);    
                          strEndDate1 = (String)request.getAttribute("EndDate");
                          strEndDate = d1.savedate(strEndDate1);
                          //objLog.info(strStartDate+","+strEndDate);
                         
                    }                    
                    else //path=print & path=select
                    {
                             strStartDate1 = request.getParameter("txtStartdate");
                             strStartDate=d1.savedate(strStartDate1);    
                             strEndDate1 = request.getParameter("txtEnddate");
                             strEndDate = d1.savedate(strEndDate1);
                    }               
                    
                    
                    stmt.executeUpdate("delete from doattendance_temp");
                                       
                     //add to doattendance_temp table
                    //select schedule list
                        strQuery = "insert into doattendance_temp SELECT scheduledate,dayofweek(scheduledate),a.shift,empname,a.empcode,division,designation,sittingphone,logindatetime ";
                        strQuery = strQuery + "FROM doschedule a, doaddress b, dodetails c where (a.scheduledate between '"+strStartDate+"' and '"+strEndDate+"') and ";
                        strQuery = strQuery + "a.empcode=b.empcode  and a.empcode=c.empcode order by scheduledate, a.shift,empname";
                                             
                        //objLog.info(strQuery);                        
                       stmt.executeUpdate(strQuery);
                     //  //objLog.info("here");   
                        
                       //check if details are in reservedutydone
                       strQuery="select * from reservedutydone where dutydate between '"+strStartDate+"' and '"+strEndDate+"'";
                       rs1=stmt.executeQuery(strQuery);
                       while (rs1.next())
                       {
                           strEmpcode=rs1.getString(1);
                           strDutydate=rs1.getString(2);
                           strShift=rs1.getString(3);
                           //check if details are in dodetails
                           strQuery="select * from dodetails where empcode='"+strEmpcode+"'";
                           rs2=stmt2.executeQuery(strQuery);
                           if (rs2.next())
                           {
                               //get from dodetails
                               strQuery = "insert into doattendance_temp SELECT dutydate,dayofweek(dutydate),a.shift,empname,a.empcode,division,designation,sittingphone,logindatetime ";
                                strQuery = strQuery + "FROM reservedutydone a, doaddress b, dodetails c where a.dutydate='"+strDutydate+"' and a.shift='"+strShift+"' and a.empcode='"+strEmpcode+"' and ";
                                strQuery = strQuery + "a.empcode=b.empcode  and a.empcode=c.empcode";
                                //objLog.info(strQuery);                        
                                stmt3.executeUpdate(strQuery);
                                
                           }
                           else
                           {
                               //get from reservelist                               
                               strQuery = "insert into doattendance_temp SELECT dutydate,dayofweek(dutydate),a.shift,empname,a.empcode,division,designation,phone,logindatetime ";
                                strQuery = strQuery + "FROM reservedutydone a, reservelist b where a.dutydate='"+strDutydate+"' and a.shift='"+strShift+"' and a.empcode='"+strEmpcode+"' and ";
                                strQuery = strQuery + "a.empcode=b.empcode";
                                //objLog.info(strQuery);                        
                                stmt4.executeUpdate(strQuery);
                           }
                           rs2.close();
                       }
                       rs1.close();
                       
                       //get row span
                       
                       strQuery="select * from doattendance_temp order by scheduledate, shift ";
                       rs1=stmt.executeQuery(strQuery);
                       while (rs1.next())
                       {
                           newdate = rs1.getString("scheduledate");   
                        //   //objLog.info(newdate);
                           if (prevdate.equals(""))
                           {
                               prevdate=newdate;
                           }
                           if (!newdate.equals(prevdate))
                           {                             
                                   //add to array
                                   arRow.add(prevdate);                                   
                                   arRow.add(new Integer(fcount).toString());
                                   arRow.add(new Integer(scount).toString());                                    
                                   
                                   fcount=0;
                                   scount=0;    
                                    prevdate=newdate;
                                    
                                    newshift=rs1.getString("shift");
                                       if (newshift.equals("FIRST"))
                                       {
                                           fcount+=1;
                                       }
                                       else
                                       {
                                           scount+=1;
                                       }        
                           }
                           else
                           {
                               newshift=rs1.getString("shift");
                               if (newshift.equals("FIRST"))
                               {
                                   fcount+=1;
                               }
                               else
                               {
                                   scount+=1;
                               }        
                                prevdate=newdate;
                           }                           
                           
                       }
                       
                       arRow.add(prevdate);                                   
                       arRow.add(new Integer(fcount).toString());
                       arRow.add(new Integer(scount).toString());        
                       
                       rs1.close();
                       
                       strQuery="select * from doattendance_temp order by scheduledate, shift, empname";
                       rs1=stmt.executeQuery(strQuery);
                        while (rs1.next())
                        {                           
                            
                            arSchedule.add(d1.datedisplay(rs1.getString(1)));
                            arSchedule.add(rs1.getString(2));
                            arSchedule.add(rs1.getString(3));
                            arSchedule.add(rs1.getString(4));
                            arSchedule.add(rs1.getString(5));
                            arSchedule.add(rs1.getString(6));
                            arSchedule.add(rs1.getString(7));
                            arSchedule.add(rs1.getString(8));
                         //   //objLog.info("login date time :"+rs1.getString(9));
                            arSchedule.add(rs1.getString(9));                                                
                           
                        }
                        rs1.close();                   
                        
                        
                         request.setAttribute("StartDate",strStartDate1);
                     request.setAttribute("EndDate",strEndDate1);
                      request.setAttribute("arSchedule",arSchedule);
                       request.setAttribute("arRow",arRow);
                       
                       if (strPath.equals("print"))
                       {
                           view = request.getRequestDispatcher("previewAttendance.jsp");                
                        view.forward(request, response);
                       }
                       else
                       {
                         view = request.getRequestDispatcher("viewAttendance.jsp");                
                        view.forward(request, response);
                       }
                   
                }
            }
        }
catch(Exception e)
{
    //objLog.error("ERROR : "+e);
	//log(" ERROR "+e);
	System.out.println("ERRORRrrr :: "+e);
    view = request.getRequestDispatcher("Failure.jsp");
    view.forward(request, response);
}
finally
{
    db.close();
}
    }
}
