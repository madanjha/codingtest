// Function : get role details from role table
// Author   : Gadha PS, Anju Varghese
// Division : COM/CIG
// Date     : 28/01/2009

import java.io.*;
import java.util.*;
import java.util.Date;
import java.text.*;
import java.lang.String;
import java.sql.*;
import java.net.*;
import javax.servlet.*;
import javax.servlet.http.*;
import org.apache.log4j.Logger;
import dateform.*;

public class checkValidDO extends HttpServlet {
    
    protected void doGet(HttpServletRequest request, HttpServletResponse response)
    throws ServletException, IOException {
        doPost(request,response);
    }
    
    protected void doPost(HttpServletRequest request, HttpServletResponse response)
    throws ServletException, IOException {
        
        RequestDispatcher view = null;
        PrintWriter out= response.getWriter();
        dbConn db=new dbConn();
        dateformat d1=new dateformat();
        //Logger //objLog = Logger.getLogger("ApplicationDO");
      
        
        try
{
            Connection conn= null;
            conn = db.Connect();
            Statement stmt = conn.createStatement();
            ResultSet rs1=null;
            ArrayList arrDODetails= new ArrayList();
            ArrayList arrObservations= new ArrayList();
            String strFlag="invalidSession", strStaffcode="", strQuery="", strFlagDO="false", strIpAddr="", strFlagIp="false";
            String strScheduleDate="", strShift="", strTime="", strDate="";
            
            // Get session
            HttpSession curSession=request.getSession(false);
            // Check if valid session
            if(curSession==null)
{
                //objLog.error("Invalid session");
                request.setAttribute("flag",strFlag);
                view=request.getRequestDispatcher("sessionError.jsp");
                view.forward(request, response);
            }
            
            else //valid session
            {
                if((String)curSession.getAttribute("userid")==null)
{
                    //objLog.error("Invalid session");
                    request.setAttribute("flag",strFlag);
                    view=request.getRequestDispatcher("sessionError.jsp");
                    view.forward(request, response);
                }
                else
                {
                    //objLog.info("-------Enter Observations------");
                    //get staffcode of logged in person
                    strStaffcode=(String)curSession.getAttribute("userid");
                    //objLog.info("Staffcode of logged in officer: "+strStaffcode);
                    strIpAddr=request.getRemoteAddr();
                    //objLog.info("IP: "+strIpAddr);
                    
                   // strIpAddr="localhost";
                    //check if he is logged in from permitted machine
                   strQuery="select * from doipaddress where ipaddress='"+strIpAddr+"'";
                    rs1=stmt.executeQuery(strQuery);
                   
                    if (rs1.next())
                    {
                         strFlagIp = "true";
                         //objLog.info("Valid IP");
                    }
                    rs1.close();
                    
                    if (strFlagIp.equals("true")) //valid IP
                    {                    
                        //check if scheduled DO (handle increment in curdate when time exceeds 12pm)
                        //first shift DO can enter observations on that day(24 hrs)
                        //second shift DO can enter observations on that day & next day(24 hrs)
                        
                        strQuery="select doschedule.empcode, empname, scheduledate, doschedule.shift from doschedule, dodetails where (scheduledate=curdate() or ((datediff(curdate(),scheduledate)=1) and doschedule.shift='SECOND'))and doschedule.empcode=dodetails.empcode and doschedule.empcode='"+strStaffcode+"'";
                        //objLog.info(strQuery);
                        rs1=stmt.executeQuery(strQuery);                        
                        if (rs1.next())
                        {
                            arrDODetails.add(rs1.getString(1));
                            arrDODetails.add(rs1.getString(2));                            
                            strScheduleDate=rs1.getString(3);
                            strShift=rs1.getString(4);
                            arrDODetails.add(d1.datedisplay(strScheduleDate));   
                            arrDODetails.add(strShift);   
                            strFlagDO="true";
                            //objLog.info("Valid DO");
                        }
                        rs1.close();
                        if (strFlagDO.equals("true"))
                        {
                            
                            //get current time
                            strQuery="select TIME_FORMAT(now(),'%h:%i %p')"; //hh:mm AM/PM
                            rs1=stmt.executeQuery(strQuery);
                            if (rs1.next())
                            {
                                 strTime=rs1.getString(1);
                                 //objLog.info("Time: "+strTime);
                            }
                             rs1.close();                            
                            
                            strQuery="select observations.empcode, slno, empname, observetime, observepriority, observation, actiontaken from observations, dodetails where dutydate='"+strScheduleDate+"' and observations.shift='"+strShift+"' and observations.empcode=dodetails.empcode order by empname";
                            //objLog.info(strQuery);
                            rs1=stmt.executeQuery(strQuery);
                            while (rs1.next())
                            {
                                arrObservations.add(rs1.getString(1));
                                arrObservations.add(rs1.getString(2));
                                arrObservations.add(rs1.getString(3));
                                arrObservations.add(rs1.getString(4));
                                arrObservations.add(rs1.getString(5));
                                arrObservations.add(rs1.getString(6));
                                arrObservations.add(rs1.getString(7));
                            }
                            rs1.close();                            
                                                         
                                 request.setAttribute("strTime",strTime); 
                                 request.setAttribute("arrObservations",arrObservations);
                                 request.setAttribute("arrDODetails",arrDODetails);
                                 view=request.getRequestDispatcher("enterObservation.jsp");
                                 view.forward(request, response);
                        }
                        else //confirm entering of observations from DO
                        {
                            //objLog.info("Not scheduled DO");
                            //check if he has already logged in before. if so, take him directly to enter observations page
                            strQuery="select * from reservedutydone where (dutydate=curdate() or datediff(curdate(),dutydate)=1) and empcode='"+strStaffcode+"' ";
                            rs1=stmt.executeQuery(strQuery);
                            if (rs1.next())
                            {
                                view=request.getRequestDispatcher("getReserveDetails.do");
                            } 
                            else
                            {
                                view=request.getRequestDispatcher("confirmEnterObservation.jsp");
                            }
                            view.forward(request, response);
                        }
                    }
                    else //invalid IP
                    {
                        //objLog.info("Invalid IP");
                        view=request.getRequestDispatcher("errorInvalidIP.jsp");
                        view.forward(request, response);
                    }
                }
            }
        }
catch(Exception e)
{
    //objLog.error("ERROR : "+e);
    view = request.getRequestDispatcher("Failure.jsp");
    view.forward(request, response);
}
finally
{
    db.close();
}
    }
}
