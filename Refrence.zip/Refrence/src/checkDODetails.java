// Function : get role details from role table
// Author   : Gadha PS, Anju Varghese
// Division : COM/CIG
// Date     : 28/01/2009

import java.io.*;
import java.util.*;
import java.util.Date;
import java.text.*;
import java.lang.String;
import java.sql.*;
import java.net.*;
import javax.servlet.*;
import javax.servlet.http.*;
import org.apache.log4j.Logger;
import dateform.*;

public class checkDODetails extends HttpServlet {
    
    protected void doGet(HttpServletRequest request, HttpServletResponse response)
    throws ServletException, IOException {
        doPost(request,response);
    }
    
    protected void doPost(HttpServletRequest request, HttpServletResponse response)
    throws ServletException, IOException {
        
        RequestDispatcher view = null;
        PrintWriter out= response.getWriter();
        dbConn db=new dbConn();
        dateformat d1=new dateformat();
      //  Logger //objLog = Logger.getLogger("ApplicationDO");
        
        try
{
            Connection conn= null;
            conn = db.Connect();
            Statement stmt = conn.createStatement();       
            Statement stmt2 = conn.createStatement();     
            ResultSet rs1=null, rs2=null;
            ArrayList arrDODetails= new ArrayList();            
            String strFlag="invalidSession", strStaffcode="", strQuery="", strFlagDO="false",  strFlagReserve="false";
            String strShift="", strDate="";
            int iHour=0;
            
            // Get session
            HttpSession curSession=request.getSession(false);
            // Check if valid session
            if(curSession==null)
{
                //objLog.error("Invalid session");
                request.setAttribute("flag",strFlag);
                view=request.getRequestDispatcher("sessionError.jsp");
                view.forward(request, response);
            }
            
            else //valid session
            {
                if((String)curSession.getAttribute("userid")==null)
{
                    //objLog.error("Invalid session");
                    request.setAttribute("flag",strFlag);
                    view=request.getRequestDispatcher("sessionError.jsp");
                    view.forward(request, response);
                }
                else
                {
                    //objLog.info("-------Enter Observations by Unscheduled DO------");
                    //get staffcode of logged in person
                    strStaffcode=(String)curSession.getAttribute("userid");
                    //objLog.info("Staffcode of logged in officer: "+strStaffcode);
                                        
                    //check if his details are in dodetails table
                    strQuery="select * from dodetails where empcode='"+strStaffcode+"'";
                    rs1=stmt.executeQuery(strQuery);
                    if (rs1.next())
                    {
                        //objLog.info("Officer in dodetails");
                        strFlagDO="true";
                    }
                    else //not in dodetails
                    {
                        //check if his details are in reservelist table
                        strQuery="select * from reservelist where empcode='"+strStaffcode+"'";
                        rs2=stmt2.executeQuery(strQuery);
                        if (rs2.next())
                        {
                            //objLog.info("Officer in reservelist");
                            strFlagReserve="true";
                            
                            //get his details
                            arrDODetails.add(rs2.getString("empcode"));
                            arrDODetails.add(rs2.getString("empname"));
                            arrDODetails.add(rs2.getString("division"));
                            arrDODetails.add(rs2.getString("designation"));
                            arrDODetails.add(rs2.getString("sex"));
                            arrDODetails.add(rs2.getString("phone"));
                        }
                        rs2.close();
                    }
                    rs1.close();
                    
                    //get current date
                    strQuery="select curdate()";
                    rs1=stmt.executeQuery(strQuery);
                    if (rs1.next())
                    {
                        strDate=d1.datedisplay(rs1.getString(1));
                    }
                    rs1.close();
                    
                    //get shift
                    strQuery="select HOUR(curtime())";
                    rs1=stmt.executeQuery(strQuery);
                    if (rs1.next())
                    {
                        iHour=rs1.getInt(1);
                        //objLog.info("Hour: "+iHour);
                        if (iHour>= 7 && iHour<19)
                        {
                            strShift="FIRST";
                            //objLog.info("Shift: "+strShift);
                        }
                        else
                        {
                            strShift="SECOND";
                            //objLog.info("Shift: "+strShift);
                        }
                    }
                    rs1.close();
                    
                    request.setAttribute("arrDODetails",arrDODetails);
                    request.setAttribute("flagDO",strFlagDO);
                    request.setAttribute("flagReserve",strFlagReserve);
                    request.setAttribute("strDate",strDate);
                    request.setAttribute("strShift",strShift);
                    
                    view=request.getRequestDispatcher("confirmDetails.jsp");
                    view.forward(request, response);
                       
                    }
                }
            }
        
catch(Exception e)
{
    //objLog.error("ERROR : "+e);
    view = request.getRequestDispatcher("Failure.jsp");
    view.forward(request, response);
}
finally
{
    db.close();
}
    }
}
