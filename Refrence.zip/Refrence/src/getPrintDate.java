// Function : get role details from role table
// Author   : Gadha PS, Anju Varghese
// Division : COM/CIG
// Date     : 28/01/2009

import java.io.*;
import java.util.*;
import java.util.Date;
import java.text.*;
import java.lang.String;
import java.sql.*;
import java.net.*;
import javax.servlet.*;
import javax.servlet.http.*;
import org.apache.log4j.Logger;
import dateform.*;

public class getPrintDate extends HttpServlet {
    
    protected void doGet(HttpServletRequest request, HttpServletResponse response)
    throws ServletException, IOException {
        doPost(request,response);
    }
    
    protected void doPost(HttpServletRequest request, HttpServletResponse response)
    throws ServletException, IOException {
        
        RequestDispatcher view = null;
        PrintWriter out= response.getWriter();
        dbConn db=new dbConn();
        dateformat d1=new dateformat();
        //Logger //objLog = Logger.getLogger("ApplicationDO");
        try
{
            Connection conn= null;
            conn = db.Connect();
            Statement stmt = conn.createStatement();
            ResultSet rs1=null;
            String strFlag="invalidSession";
            String strQuery="",strStartDate="",strEndDate="", strScStartdate="", strScEnddate="";
            
            // Get session
            HttpSession curSession=request.getSession(false);
            // Check if valid session
            if(curSession==null)
{
                //objLog.error("Invalid session");
                request.setAttribute("flag",strFlag);
                view=request.getRequestDispatcher("sessionError.jsp");
                view.forward(request, response);
            }
            
            else //valid session
            {
                if((String)curSession.getAttribute("userid")==null)
{
                    //objLog.error("Invalid session");
                    request.setAttribute("flag",strFlag);
                    view=request.getRequestDispatcher("sessionError.jsp");
                    view.forward(request, response);
                }
else
{
                    strQuery="select min(scheduledate), max(scheduledate) from doschedule";
                    rs1=stmt.executeQuery(strQuery);
                    if (rs1.next())
                    {
                        strStartDate=rs1.getString(1);
                        strStartDate=d1.datedisplay(strStartDate);
                        strEndDate=rs1.getString(2);
                        strEndDate=d1.datedisplay(strEndDate);
                    }
                    rs1.close();
                    
                    strQuery="select startdate, enddate from scheduledetails where status='NEW'";
                        rs1=stmt.executeQuery(strQuery);
                        if (rs1.next())
                        {
                            strScStartdate=rs1.getString(1);        
                            strScStartdate=d1.datedisplay(strScStartdate);
                            strScEnddate=rs1.getString(2);
                            strScEnddate=d1.datedisplay(strScEnddate);
                        }
                        rs1.close();
                        
                    request.setAttribute("startdate",strStartDate);     
                    request.setAttribute("enddate",strEndDate); 
                    request.setAttribute("scstartdate",strScStartdate);
                    request.setAttribute("scenddate",strScEnddate);
                    view = request.getRequestDispatcher("printSchedule.jsp");                
                    view.forward(request, response);
}}
        }
catch(Exception e)
{
    //objLog.error("ERROR : "+e);
    view = request.getRequestDispatcher("Failure.jsp");
    view.forward(request, response);
}
finally
{
    db.close();
}
    }
}
