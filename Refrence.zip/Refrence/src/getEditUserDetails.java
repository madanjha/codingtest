// Function : get new user details from sysuser table
// Author   : Gadha PS, Anju Varghese
// Division : COM/CIG
// Date     : 28/01/2009

import java.io.*;
import java.util.*;
import java.util.Date;
import java.text.*;
import java.lang.String;
import java.sql.*;
import java.net.*;
import javax.servlet.*;
import javax.servlet.http.*;
import org.apache.log4j.Logger;

public class getEditUserDetails extends HttpServlet {
    
    protected void doGet(HttpServletRequest request, HttpServletResponse response)
    throws ServletException, IOException {
        doPost(request,response);
    }
    
    protected void doPost(HttpServletRequest request, HttpServletResponse response)
    throws ServletException, IOException {
        
        RequestDispatcher view = null;
        PrintWriter out= response.getWriter();
        dbConn db=new dbConn();
        ArrayList RoleType=new ArrayList();
        ArrayList Staffcode=new ArrayList();
     //   Logger //objLog = Logger.getLogger("ApplicationDO");
        String strQuery="", strType="Edit";
        String strName="", strStaffcode="", strDivision="",strDesg="",strOffPhone="", strRole="", strPos="", strResPhone="", strMobile="";
             
        try
{
            Connection conn= null;
            conn = db.Connect();
            Statement stmt = conn.createStatement();
            ResultSet rs1=null;
            String strFlag="invalidSession";
            
            // Get session
            HttpSession curSession=request.getSession(false);
            // Check if valid session
            if(curSession==null)
{
                //objLog.error("Invalid session");
                request.setAttribute("flag",strFlag);
                view=request.getRequestDispatcher("sessionError.jsp");
                view.forward(request, response);
            }
            
            else //valid session
            {
                if((String)curSession.getAttribute("userid")==null)
{
                    //objLog.error("Invalid session");
                    request.setAttribute("flag",strFlag);
                    view=request.getRequestDispatcher("sessionError.jsp");
                    view.forward(request, response);
                }
                else
                {
                    //get staffcode   
                    strStaffcode= request.getParameter("cboStaffcode");
             
                    //check if staffcode="select"
                    if (strStaffcode.equals("Select")) //reset values
                    {
                        strName="";
                        strDesg="";
                        strDivision="";strOffPhone="";
                        strRole = "Select";strPos="";
                        strResPhone=""; strMobile="";
                    }
                    else
                    {
                        strQuery = "select * from sysuser where empcode='"+strStaffcode+"'";
                        rs1 = stmt.executeQuery(strQuery);
                        while (rs1.next())
                        {
                            strName = rs1.getString("empname");
                            strDesg= rs1.getString("designation");
                            strDivision = rs1.getString("division");
                            strOffPhone = rs1.getString("offphone");
                            strRole = rs1.getString("role");
                            strPos=rs1.getString("position");
                             strResPhone=rs1.getString("resphone");
                              strMobile=rs1.getString("mobile");
                        }
                        rs1.close();
                    }                 
                    
                    strQuery="select distinct empcode from sysuser order by empcode";
                   // //objLog.info(strQuery);
                    rs1=stmt.executeQuery(strQuery);
                    while(rs1.next())
                    {
                        Staffcode.add(rs1.getString(1));                        
                    }
                    rs1.close();
                    
                     strQuery="select distinct role from roletype order by role";
                   // //objLog.info(strQuery);
                    rs1=stmt.executeQuery(strQuery);
                    while(rs1.next())
                    {
                        RoleType.add(rs1.getString(1));                        
                    }
                    rs1.close();
                    
                    request.setAttribute("strStaffcode",strStaffcode); 
                    request.setAttribute("strName",strName);  
                    request.setAttribute("strDivision",strDivision);        
                    request.setAttribute("strDesg",strDesg);         
                    request.setAttribute("strOffPhone",strOffPhone); 
                    request.setAttribute("strResPhone",strResPhone); 
                    request.setAttribute("strMobile",strMobile); 
                    request.setAttribute("strRole",strRole);  
                    request.setAttribute("strPos",strPos);  
                    request.setAttribute("Flag",strType);
                    
                    request.setAttribute("RoleType",RoleType);
                    request.setAttribute("Staffcode",Staffcode);
                    view = request.getRequestDispatcher("editUser.jsp");
                    view.forward(request, response);
                }
            }
        }
catch(Exception e)
{
    //objLog.error("ERROR : "+e);
    view = request.getRequestDispatcher("Failure.jsp");
    view.forward(request, response);
}
finally
{
    db.close();
}
    }
}
