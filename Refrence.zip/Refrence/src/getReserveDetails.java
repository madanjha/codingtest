// Function : get role details from role table
// Author   : Gadha PS, Anju Varghese
// Division : COM/CIG
// Date     : 28/01/2009

import java.io.*;
import java.util.*;
import java.util.Date;
import java.text.*;
import java.lang.String;
import java.sql.*;
import java.net.*;
import javax.servlet.*;
import javax.servlet.http.*;
import org.apache.log4j.Logger;
import dateform.*;

public class getReserveDetails extends HttpServlet {
    
    protected void doGet(HttpServletRequest request, HttpServletResponse response)
    throws ServletException, IOException {
        doPost(request,response);
    }
    
    protected void doPost(HttpServletRequest request, HttpServletResponse response)
    throws ServletException, IOException {
        
        RequestDispatcher view = null;
        PrintWriter out= response.getWriter();
        dbConn db=new dbConn();
        dateformat d1=new dateformat();
       // Logger //objLog = Logger.getLogger("ApplicationDO");
        try
{
            Connection conn= null;
            conn = db.Connect();
            Statement stmt = conn.createStatement();
            ResultSet rs1=null;
            ArrayList arrDODetails= new ArrayList();
            ArrayList arrObservations= new ArrayList();
            String strFlag="invalidSession", strScheduleDate="", strShift="", strFlagDO="false", strTime="", strQuery="", strStaffcode="";
            
            // Get session
            HttpSession curSession=request.getSession(false);
            // Check if valid session
            if(curSession==null)
{
                //objLog.error("Invalid session");
                request.setAttribute("flag",strFlag);
                view=request.getRequestDispatcher("sessionError.jsp");
                view.forward(request, response);
            }
            
            else //valid session
            {
                if((String)curSession.getAttribute("userid")==null)
{
                    //objLog.error("Invalid session");
                    request.setAttribute("flag",strFlag);
                    view=request.getRequestDispatcher("sessionError.jsp");
                    view.forward(request, response);
                }
                else
                {
                     //get staffcode of logged in person
                    strStaffcode=(String)curSession.getAttribute("userid");
                    //objLog.info("Staffcode of logged in officer: "+strStaffcode);
                    
                    //get from dodetails                   
                
                     strQuery="select reservedutydone.empcode, empname, dutydate, reservedutydone.shift from reservedutydone, dodetails where (dutydate=curdate() or ((datediff(curdate(),dutydate)=1) and reservedutydone.shift='SECOND'))and reservedutydone.empcode=dodetails.empcode and reservedutydone.empcode='"+strStaffcode+"'";
                        //objLog.info(strQuery);
                        rs1=stmt.executeQuery(strQuery);                        
                        if (rs1.next())
                        {
                            arrDODetails.add(rs1.getString(1));
                            arrDODetails.add(rs1.getString(2));                            
                            strScheduleDate=rs1.getString(3);
                            strShift=rs1.getString(4);
                            arrDODetails.add(d1.datedisplay(strScheduleDate));   
                            arrDODetails.add(strShift);   
                            strFlagDO="true";                          
                        }
                        rs1.close();

                        if (strFlagDO.equals("false")) //get from reservelist
                        {
                            strQuery="select reservedutydone.empcode, empname, dutydate, reservedutydone.shift from reservedutydone, reservelist where (dutydate=curdate() or ((datediff(curdate(),dutydate)=1) and reservedutydone.shift='SECOND'))and reservedutydone.empcode=reservelist.empcode and reservedutydone.empcode='"+strStaffcode+"'";
                            //objLog.info(strQuery);
                            rs1=stmt.executeQuery(strQuery);                        
                            if (rs1.next())
                            {
                                arrDODetails.add(rs1.getString(1));
                                arrDODetails.add(rs1.getString(2));                            
                                strScheduleDate=rs1.getString(3);
                                strShift=rs1.getString(4);
                                arrDODetails.add(d1.datedisplay(strScheduleDate));   
                                arrDODetails.add(strShift);   
                                strFlagDO="true";                          
                            }
                            rs1.close();
                        }                            
                            
                            //get current time
                            strQuery="select TIME_FORMAT(now(),'%h:%i %p')"; //hh:mm AM/PM
                             rs1=stmt.executeQuery(strQuery);
                            if (rs1.next())
                            {
                                 strTime=rs1.getString(1);
                                 //objLog.info("Time: "+strTime);
                            }
                             rs1.close();                            
                            
                            strQuery="select observations.empcode, slno, empname, observetime, observepriority, observation, actiontaken from observations, dodetails where dutydate='"+strScheduleDate+"' and observations.shift='"+strShift+"' and observations.empcode=dodetails.empcode order by empname";
                            //objLog.info(strQuery);
                            rs1=stmt.executeQuery(strQuery);
                            while (rs1.next())
                            {
                                arrObservations.add(rs1.getString(1));
                                arrObservations.add(rs1.getString(2));
                                arrObservations.add(rs1.getString(3));
                                arrObservations.add(rs1.getString(4));
                                arrObservations.add(rs1.getString(5));
                                arrObservations.add(rs1.getString(6));
                                arrObservations.add(rs1.getString(7));
                            }
                            rs1.close();                            
                            
                             strQuery="select observations.empcode, slno, empname, observetime, observepriority, observation, actiontaken from observations, reservelist where dutydate='"+strScheduleDate+"' and observations.shift='"+strShift+"' and observations.empcode=reservelist.empcode order by empname";
                            //objLog.info(strQuery);
                            rs1=stmt.executeQuery(strQuery);
                            while (rs1.next())
                            {
                                arrObservations.add(rs1.getString(1));
                                arrObservations.add(rs1.getString(2));
                                arrObservations.add(rs1.getString(3));
                                arrObservations.add(rs1.getString(4));
                                arrObservations.add(rs1.getString(5));
                                arrObservations.add(rs1.getString(6));
                                 arrObservations.add(rs1.getString(7));
                            }
                            rs1.close(); 
                             
                              request.setAttribute("strTime",strTime); 
                               request.setAttribute("arrObservations",arrObservations);
                                request.setAttribute("arrDODetails",arrDODetails);
                                view=request.getRequestDispatcher("enterObservation.jsp");
                                view.forward(request, response);
                }
            }
        }
catch(Exception e)
{
    //objLog.error("ERROR : "+e);
    view = request.getRequestDispatcher("Failure.jsp");
    view.forward(request, response);
}
finally
{
    db.close();
}
    }
}
