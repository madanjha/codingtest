// Function : get role details from role table
// Author   : Gadha PS, Anju Varghese
// Division : COM/CIG
// Date     : 28/01/2009

import java.io.*;
import java.util.*;
import java.util.Date;
import java.text.*;
import java.lang.String;
import java.sql.*;
import java.net.*;
import javax.servlet.*;
import javax.servlet.http.*;
import org.apache.log4j.Logger;
import dateform.*;


import java.util.Properties;
import javax.mail.Authenticator;
import javax.mail.Message;
import javax.mail.PasswordAuthentication;
import javax.mail.Session;
import javax.mail.Transport;
import javax.mail.internet.InternetAddress;
import javax.mail.internet.MimeMessage;
import java.io.*;

public class saveRequestDO extends HttpServlet {
    
    protected void doGet(HttpServletRequest request, HttpServletResponse response)
    throws ServletException, IOException {
        doPost(request,response);
    }
   
     class ThePasswordAuthenticator extends Authenticator {
		String user;
		String pw;
		public ThePasswordAuthenticator(String username, String password) {
			super();
			this.user = username;
			this.pw = password;
		}
		public PasswordAuthentication getPasswordAuthentication() {
			return new PasswordAuthentication(user, pw);
		}
    }
     
    protected void doPost(HttpServletRequest request, HttpServletResponse response)
    throws ServletException, IOException {
        
        RequestDispatcher view = null;
        PrintWriter out= response.getWriter();
        dbConn db=new dbConn();
        dateformat d1=new dateformat();
      //  Logger //objLog = Logger.getLogger("ApplicationDO");
        try
{
            Connection conn= null;
            conn = db.Connect();
            Statement stmt = conn.createStatement();
            ResultSet rs1=null;
            String strFlag="invalidSession", strStaffcode="",strExStaffcode="", strScheduledate="", strShift="", strExScheduledate="", strExShift="";
            String strAgree="", strQuery="", strName="", strExMail="", strMail="", mailPath="";
            
            // Get session
            HttpSession curSession=request.getSession(false);
            // Check if valid session
            if(curSession==null)
            {
                //objLog.error("Invalid session");
                request.setAttribute("flag",strFlag);
                view=request.getRequestDispatcher("sessionError.jsp");
                view.forward(request, response);
            }
            
            else //valid session
            {
                if((String)curSession.getAttribute("userid")==null)
                 {
                    //objLog.error("Invalid session");
                    request.setAttribute("flag",strFlag);
                    view=request.getRequestDispatcher("sessionError.jsp");
                    view.forward(request, response);
                }
                else
                {
                       strAgree=request.getParameter("agree");
                       //objLog.info("Agree flag: "+strAgree);
                       strStaffcode=request.getParameter("strStaffcode");
                       strScheduledate=d1.savedate(request.getParameter("strScheduledate"));                    
                       strShift=request.getParameter("strShift");
                       strExScheduledate=d1.savedate(request.getParameter("strExScheduledate"));
                       strExStaffcode=request.getParameter("strExStaffcode");
                       strExShift=request.getParameter("strExShift");
                        
                    // get name of strStaffcode
                        
                        strQuery="select empname from dodetails where empcode='"+strStaffcode+"'";
                        rs1=stmt.executeQuery(strQuery);
                        if (rs1.next())
                        {
                            strName=rs1.getString(1);
                        }
                        rs1.close();
                        
                        strQuery="select email from empemail where scno='"+strStaffcode+"'";
                        rs1=stmt.executeQuery(strQuery);
                        if (rs1.next())
                        {
                            strMail=rs1.getString(1);
                        }
                        rs1.close();
                        
                        strQuery="select email from empemail where scno='"+strExStaffcode+"'";
                        rs1=stmt.executeQuery(strQuery);
                        if (rs1.next())
                        {
                            strExMail=rs1.getString(1);
                        }
                        rs1.close();
                           
                        
                     //if agree='Y', exchange DO, send mail, reset exchangeflag, set confirm flag to 'Y'
                      if (strAgree.equals("Y"))  
                      {
                            //objLog.info("Agrees - Exchange Dates");
                            strQuery = "update doschedule set scheduledate='"+strExScheduledate+"', shift='"+strExShift+"', confirm='Y' where empcode='"+strStaffcode+"' and scheduledate='"+strScheduledate+"' ";
                            stmt.executeUpdate(strQuery);
                            //objLog.info(strQuery);

                            strQuery = "update doschedule set scheduledate='"+strScheduledate+"', shift='"+strShift+"', confirm='Y' where empcode='"+strExStaffcode+"' and scheduledate='"+strExScheduledate+"'";
                            stmt.executeUpdate(strQuery);
                            //objLog.info(strQuery);

                            //reset exchange flag to 0 

                            stmt.executeUpdate("update exchangedo set exchangeflag ='0' where empcode1='"+strStaffcode+"' or empcode2='"+strExStaffcode+"' or empcode2='"+strStaffcode+"' or empcode1='"+strExStaffcode+"'");
                                   
                            //send mail to both
                            
                            strExScheduledate=d1.datedisplay(strExScheduledate);
                            strScheduledate=d1.datedisplay(strScheduledate);
                            
                    // mailPath="http://10.41.6.137:8080/VDOS/dera.do?emailid1="+strExMail+"&name1="+strName+"&dutydate1="+strScheduledate+"&shift1="+strShift+"&emailid2="+strMail+"&dutydate2="+strExScheduledate+"&shift2="+strExShift;
                           
                            ///////////Mail 1 to requested ///START//////////////////////////////////////////
                           ///////  /*NEW CODE*/ /////////////////////                           
                          //////////////////Mail 1 to requested ///START////////////////////////////////////
                         //////////////////////////////////////////////////////    
                            
                         String mailer = "myprogram";
			//comma separated list of recipients.
			//String to = "shiny@lpscv.dos.gov.in";
			String cc = null;
			String bcc = null;
			String from = "doadmin@lpscv.dos.gov.in";
			//String subject = "LPSC Duty Officer System � Request to exchange duty accepted \r\n";
                        String subject = "(TESTING-PLZ IGNORE THIS MAIL)LPSC Duty Officer System �Request to exchange duty accepted .\r\n";
			
                        String body = "Sir/Madam\r\n"+
			"(TESTING -PLEASE IGNORE THIS MAIL) Mr./Ms. "+ strName +"has  agreed to exchange duty with you"+
                        "You are requested to perform DO duty on the date and shift mentioned below :\r\n";
                      
                         body = body + "Schedule date:\r\n"+ strScheduledate;           
                         body = body + "Shift:"+ strShift;
                        
                        String bodyappnd = "To access LPSC Duty officer System(LDOS), click on the link below: \n"+
                                         //"http://10.101.2.153:8080/LPSCDOS/login.jsp \n"+
                                         "http://X/LPSCDOS/login.jsp \n"+
                                         "Please ensure that you have confirmed your duty \n"+
                                         "\n Regards"+
                                         "System Administrator \n"+
                                         "\n This is an auto-generated mail. Do not reply to this mail.";
                        body = body +  bodyappnd;
                      
                        String smtpserver = "lpscv.dos.gov.in";
			String smtpport = "25";
			//my username for smtp.att.yahoo.com was a fully
			//qualified email, like joel@att.com.
			String user = "doadmin";
			//String password = "s1s2i3";
			String password = "lpsc1234";
                        Properties props = new Properties();
			//default to "localhost"
			props.put("mail.smtp.host", smtpserver);
			//default to "25"
			props.put("mail.smtp.port", smtpport);
			//uncomment to turn on debugging output which can be useful.
			//props.put("mail.debug", "true");
			//javax.mail.Session
			
			Session session = null;
			if (user != null && password != null)
                        {
                                    props.put("mail.smtp.auth", "true");
                                    session =Session.getInstance(props,new ThePasswordAuthenticator(user,password));
			}
                    
                         Message msg = new MimeMessage(session);
                         try
                         {
		         
                              //body=body + "Schedule date: " +strExDutydate;
                              //body=body + "Shift : " +strExShift;
                              
                            msg.setFrom(new InternetAddress(from));
                                                
                            msg.setRecipients(Message.RecipientType.TO,InternetAddress.parse(strExMail, false));
                            if (cc != null)
                            msg.setRecipients(Message.RecipientType.CC,InternetAddress.parse(cc, false));
                            if (bcc != null)
                            msg.setRecipients(Message.RecipientType.BCC,InternetAddress.parse(bcc, false));
                            //subject line.
                            msg.setSubject(subject);
                            //set the body of the message, also consider setContent()
                            //for Multipart content
                            msg.setText(body);
                            //the name of your program.
                            msg.setHeader("X-Mailer", mailer);
                            //Date sent from this computer.
                            msg.setSentDate(new Date());
                            // send the message!
                            Transport.send(msg);
                            System.out.println("\nMail was sent successfully.");
                            
                    ///////////Mail 1 to requested ///END//////////////////////////////////////////
                    ///////  /*NEW CODE*/ /////////////////////                           
                   //////////////////Mail 1 to requested ///END////////////////////////////////////
                  //////////////////////////////////////////////////////                
                            
                            //  mailPath="http://10.41.6.137:8080/VDOS/dera.do?emailid1="+strExMail+"&name1="+strName+"&dutydate1="+strScheduledate+"&shift1="+strShift+"&emailid2="+strMail+"&dutydate2="+strExScheduledate+"&shift2="+strExShift;                             
                           
                                ///////////Mail 2 to accepted ///START//////////////////////////////////////////
                    ///////  /*NEW CODE*/ /////////////////////                           
                   //////////////////Mail 2to accepted  ///START////////////////////////////////////
                  ////////////////////////////////////////////////////// 
                             
                            String subject1="(TESTING-PLZ IGNORE THIS MAIL) LPSC Duty Officer System � Intimation of duty  ";
                            String body1 = "Sir/Madam,\r\n"+
			    "You are requested to perform DO duty on the date and shift mentioned below:";                        
                           
                            body1=body1 + "Schedule date:\r\n"+ strExScheduledate;           
                            body1=body1 + "Shift:"+ strExShift+"\n";
                            
                            String bodyappnd1= "To access LPSC Duty Officer System(LDOS), click on the link below:"+
                                               //"http://10.101.2.153:8080/LPSCDOS/login.jsp"+
                                                "http://X:8080/LPSCDOS/login.jsp"+
                                                "\n Please ensure that you have confirmed your duty.\n"+
                                                "\n Regards"+
                                                "\n System Administrator \n"+
                                                "\n NOTE:- This is an auto-generated mail. Do not reply to this mail";
                                              
                            body1=body1 + bodyappnd1;                   

                            msg.setRecipients(Message.RecipientType.TO,InternetAddress.parse(strMail, false));
                            if (cc != null)
                            msg.setRecipients(Message.RecipientType.CC,InternetAddress.parse(cc, false));
                            if (bcc != null)
                            msg.setRecipients(Message.RecipientType.BCC,InternetAddress.parse(bcc, false));
                            //subject line.
                            msg.setSubject(subject1);
                            //set the body of the message, also consider setContent()
                            //for Multipart content
                            msg.setText(body1);
                            //the name of your program.
                            msg.setHeader("X-Mailer", mailer);
                            //Date sent from this computer.
                            msg.setSentDate(new Date());
                            // send the message!
                            Transport.send(msg);
                            System.out.println("\nMail was sent successfully.");
                     
                      }
                      catch (Exception e) 
                      {
			 System.out.println("Error: " + e.getMessage());
		      }
                      ///////////Mail 2 to accepted ///END//////////////////////////////////////////
                    ///////  /*NEW CODE*/ /////////////////////                           
                   //////////////////Mail 2to accepted  ///END////////////////////////////////////
                  //////////////////////////////////////////////////////          
                         
                    /* NEW CODE Modified on 11-01-10 */     
                            
                        /* NEW CODE*/
                          //objLog.info("PATH for sending mail : "+mailPath);
                         //   response.sendRedirect(mailPath);
                            
                      }
                      else //send mail, reset exchangeflag
                      {
                        //reset exchange flag to 0 
                        //objLog.info("Do not agree");
                        stmt.executeUpdate("update exchangedo set exchangeflag ='0' where empcode1='"+strStaffcode+"' or empcode2='"+strExStaffcode+"' or empcode2='"+strStaffcode+"' or empcode1='"+strExStaffcode+"'");

                        //send mail to requested officer
                        strExScheduledate=d1.datedisplay(strExScheduledate);
                       // mailPath="http://10.41.6.137:8080/VDOS/derr.do?emailid="+strExMail+"&name="+strName+"&dutydate="+strExScheduledate+"&shift="+strExShift;
                     
                         /*NEW CODE*/
                    ///////////Mail 1 to requested ///START///////////rejected status ///////////////////////////////
                    ///////  /*NEW CODE*/ /////////////////////                           
                   //////////////////Mail 1 to requested  ///START/////////rejected status///////////////////////////
                  //////////////////////////////////////////////////////                             
                        String mailer = "myprogram";
			//comma separated list of recipients.
			//String to = "shiny@lpscv.dos.gov.in";
			String cc = null;
			String bcc = null;
			String from = "doadmin@lpscv.dos.gov.in";
			String subject = "(Testing-Please ignore this mail)LPSC Duty Officer System �Request to exchange duty denied .\r\n";
                       
			String body = "Sir/Madam\r\n"+
			"Mr./Ms. "+ strName +"has not agreed to exchange duty with you"+
                        "You are requested to perform DO duty on the date and shift mentioned below :\r\n";
                      
                           
                         body=body + "Schedule date:\r\n"+ strExScheduledate;           
                         body=body + "Shift:"+ strExShift;
                                 
                        String bodyappnd="To access LPSC Duty officer System(LDOS), click on the link below: \n"+
                                         //"http://10.101.2.153:8080/LPSCDOS/login.jsp \n"+
                                         "http://X:8080/LPSCDOS/login.jsp \n"+
                                         "Please login to the above system to confirm/exchange your duty. \n"+
                                         "\n Regards"+
                                         "System Administrator \n"+
                                         "\n This is an auto-generated mail. Do not reply to this mail.";
                        body=body +  bodyappnd;
                        String smtpserver = "lpscv.dos.gov.in";
			String smtpport = "25";
			//my username for smtp.att.yahoo.com was a fully
			//qualified email, like joel@att.com.
			String user = "doadmin";
			//String password = "s1s2i3";
			String password = "lpsc1234";
                        Properties props = new Properties();
			//default to "localhost"
			props.put("mail.smtp.host", smtpserver);
			//default to "25"
			props.put("mail.smtp.port", smtpport);
			//uncomment to turn on debugging output which can be useful.
			//props.put("mail.debug", "true");
			//javax.mail.Session
			
			Session session = null;
			if (user != null && password != null)
                        {
                                    props.put("mail.smtp.auth", "true");
                                    session =Session.getInstance(props,new ThePasswordAuthenticator(user,password));
			}
                    
                         Message msg = new MimeMessage(session);
                         try
                         {
		         
                             
                              //body=body + "Schedule date: " +strExDutydate;
                              //body=body + "Shift : " +strExShift;
                              
                            msg.setFrom(new InternetAddress(from));
                                                
                            msg.setRecipients(Message.RecipientType.TO,InternetAddress.parse(strExMail, false));
                            if (cc != null)
                            msg.setRecipients(Message.RecipientType.CC,InternetAddress.parse(cc, false));
                            if (bcc != null)
                            msg.setRecipients(Message.RecipientType.BCC,InternetAddress.parse(bcc, false));
                            //subject line.
                            msg.setSubject(subject);
                            //set the body of the message, also consider setContent()
                            //for Multipart content
                            msg.setText(body);
                            //the name of your program.
                            msg.setHeader("X-Mailer", mailer);
                            //Date sent from this computer.
                            msg.setSentDate(new Date());
                            // send the message!
                            Transport.send(msg);
                            System.out.println("\nMail was sent successfully.");                            
                           
                         //objLog.info("PATH for sending mail : "+mailPath);
                         //   response.sendRedirect(mailPath);
                         }  
                         
                           catch (Exception e) 
                      {
			   System.out.println("Error: " + e.getMessage());
                         
                           //view = request.getRequestDispatcher("requestExchangeDOExptMailLPSC.jsp"); 
                          view = request.getRequestDispatcher("requestExchangeDOMailNotSndLPSC.jsp");
                            view.forward(request, response);
		      }
                       /* NEW CODE*/ 
                    ///////////Mail 1 to requested ///END///////////rejected status ///////////////////////////////
                    ///////  /*NEW CODE*/ /////////////////////                           
                   //////////////////Mail 1 to requested  ///END/////////rejected status///////////////////////////
                  //////////////////////////////////////////////////////     
                         
                      }                        
                        //after sending mail redirect to saveRequestDO.jsp
                        
                        view = request.getRequestDispatcher("saveRequestDO.jsp");                     
                        view.forward(request, response);     
                }
            }
        }
catch(Exception e)
{
    //objLog.error("ERROR : "+e);
    view = request.getRequestDispatcher("Failure.jsp");
    view.forward(request, response);
}
finally
{
    db.close();
}
    }
}
