
/**
* Sample prepared by Joel A. Thompson
* At http://www.rhinosystemsinc.com
* All rights reserved.
*/
import java.util.Date;
import java.util.Properties;
import javax.mail.Authenticator;
import javax.mail.Message;
import javax.mail.PasswordAuthentication;
import javax.mail.Session;
import javax.mail.Transport;
import javax.mail.internet.InternetAddress;
import javax.mail.internet.MimeMessage;
import java.io.*;
import javax.servlet.*;
import javax.servlet.http.*;
// File: com/rhinosystemsinc/tools/SendJavaMail.java
  public class SendJavaMail  extends HttpServlet
   {
	
	/*public static void main(String[] args) {
		SendJavaMail sm = new SendJavaMail();
		sm.send();
	}*/

	 /*
	 * This is a simple inner class that extends javax.mail.Authenticator
	 * used for gathering a username and password.
	 */
	  
	  protected void doGet(HttpServletRequest request, HttpServletResponse response)
	    throws ServletException, IOException {
	        doPost(request,response);
	    }
	    
	class ThePasswordAuthenticator extends Authenticator {
		String user;
		String pw;
		public ThePasswordAuthenticator(String username, String password) {
			super();
			this.user = username;
			this.pw = password;
		}
		public PasswordAuthentication getPasswordAuthentication() {
			return new PasswordAuthentication(user, pw);
		}
	}
		
	 protected void doPost(HttpServletRequest request, HttpServletResponse response)throws ServletException, IOException 
	 
	 {
		 
		 String mailer = "myprogram";
			//comma separated list of recipients.
			String to = "shiny@lpscv.dos.gov.in";
			String cc = "bill@ibm.com,mary@oracle.com";
			String bcc = null;
			String from = "shiny@lpscv.dos.gov.in";
			String subject = "Testing mailing from Java ";
			String body = "This is the body of the test message.\r\n"+
			"Sent on: " + new Date() + "\r\n"+
			"Regards, \r\n" +
			"Joel" ;
			String smtpserver = "lpscv.dos.gov.in";
			String smtpport = "25";
			//my username for smtp.att.yahoo.com was a fully
			//qualified email, like joel@att.com.
			String user = "shiny";
			//String password = "s1s2i3";
			String password = "vssc1234";
			Properties props = new Properties();
			//default to "localhost"
			props.put("mail.smtp.host", smtpserver);
			//default to "25"
			props.put("mail.smtp.port", smtpport);
			//uncomment to turn on debugging output which can be useful.
			//props.put("mail.debug", "true");
			//javax.mail.Session
			
			Session session = null;
			if (user != null && password != null) {
				props.put("mail.smtp.auth", "true");
				session =Session.getInstance(props,new ThePasswordAuthenticator(user,password));
			}
			
			/* else {
			session = Session.getDefaultInstance(props, null);
			}*/
			/*
			* using
			* javax.mail.Message & javax.mail.internet.MimeMessage
			* javax.mail.internet.InternetAddress
			*/
			
			Message msg = new MimeMessage(session);
					
		  try 
		    {
			   msg.setFrom(new InternetAddress(from));
			/*
			* Parse the given comma separated sequence of
			* addresses into an Array of InternetAddress objects
			* Then set as the desired recipient.
			*/
			msg.setRecipients(Message.RecipientType.TO,InternetAddress.parse(to, false));
			if (cc != null)
			msg.setRecipients(Message.RecipientType.CC,InternetAddress.parse(cc, false));
			if (bcc != null)
			msg.setRecipients(Message.RecipientType.BCC,InternetAddress.parse(bcc, false));
			//subject line.
			msg.setSubject(subject);
			//set the body of the message, also consider setContent()
			//for Multipart content
			msg.setText(body);
			//the name of your program.
			msg.setHeader("X-Mailer", mailer);
			//Date sent from this computer.
			msg.setSentDate(new Date());
			// send the message!
			Transport.send(msg);
			System.out.println("\nMail was sent successfully.");
		   } catch (Exception e) {
				System.out.println("Error: " + e.getMessage());
		   	}
	
	 }
	 
	/*	public void send() {
		
	}*/ //public void send() {
} //public class SendJavaMail 