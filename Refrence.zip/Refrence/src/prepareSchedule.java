// Function : get role details from role table
// Author   : Gadha PS, Anju Varghese
// Division : COM/CIG
// Date     : 28/09/2009

import java.io.*;
import java.util.*;
import java.util.Date;
import java.text.*;
import java.lang.String;
import java.sql.*;
import java.net.*;
import javax.servlet.*;
import javax.servlet.http.*;
import org.apache.log4j.Logger;
import dateform.*;

public class prepareSchedule extends HttpServlet {

    protected void doGet(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        doPost(request, response);
    }

    protected void doPost(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException
    {

        RequestDispatcher view = null;
        PrintWriter out = response.getWriter();
        dateformat d1 = new dateformat();
        dbConn db = new dbConn();

       // Logger //objLog = Logger.getLogger("ApplicationDO");
        try {
            Connection conn = null;
            conn = db.Connect();
            Statement stmt = conn.createStatement();
            Statement stmt1 = conn.createStatement();
            ResultSet rs1 = null, rs2 = null;

            ArrayList arFirstShift = new ArrayList(); //empcode,sex,designation
            ArrayList arSecondShift = new ArrayList(); //empcode,designation
            ArrayList arHoliday = new ArrayList(); //holiday
            ArrayList arWeekday = new ArrayList(); //week days
            ArrayList arSchedule = new ArrayList(); //schedule
            ArrayList arMaleFirstShiftNonSC = new ArrayList(); //empcode
            ArrayList arFemaleFirstShiftNonSC = new ArrayList(); //empcode
            ArrayList arMaleFirstShiftSC = new ArrayList(); //empcode
            ArrayList arFemaleFirstShiftSC = new ArrayList(); //empcode
            ArrayList arSecondShiftNonSC = new ArrayList(); //empcode
            ArrayList arSecondShiftSC = new ArrayList(); //empcode

            String strFlag = "invalidSession", prevDate = "", prevShift = "", designation = "", strDesgFlag = "", strSexFlag = "", strAuthError="InvalidUsername";
            String strStartDate1 = "", strStartDate = "", strEndDate1 = "", strEndDate = "", strQuery = "", strStatus = "NEW", days = "", prevshift1 = "", prevshift2 = "";
            String second = "", sex = "", shift = "", strDate = "", strEmpcode = "", strIncDate = "", dayofweek = "", strFlag1 = "true", strCurDate = "";
            int totalfirst = 0, totalsecond = 0, fcount = 0, scount = 0;
            int maxid = 0, firstShiftCount = 0, secondShiftCount = 0, daycount = 0;
            int frs1 = 0, frs2 = 0;

            // Get session
            HttpSession curSession = request.getSession(false);
            // Check if valid session
            if (curSession == null) {
                //objLog.error("Invalid session");
                request.setAttribute("flag", strFlag);
                view = request.getRequestDispatcher("sessionError.jsp");
                view.forward(request, response);
            } else //valid session
            {
                if ((String) curSession.getAttribute("userid") == null) {
                    //objLog.error("Invalid session");
                    request.setAttribute("flag", strFlag);
                    view = request.getRequestDispatcher("sessionError.jsp");
                    view.forward(request, response);
                } else {
                    //objLog.info("--------Prepare Schedule------------");
                    strStartDate1 = request.getParameter("txtStartdate");
                    strStartDate = d1.savedate(strStartDate1);
                    //objLog.info("Start Date: " + strStartDate);
                    strEndDate1 = request.getParameter("txtEnddate");
                    strEndDate = d1.savedate(strEndDate1);
                    //objLog.info("End Date: " + strEndDate);
                    days = request.getParameter("days");
                    daycount = Integer.parseInt(days);
                    daycount += 1;
                    //objLog.info("days: " + daycount);

                    //keep some reserve members

                    totalfirst = (daycount * 2) + 5; //no of officers for first shift
                    //objLog.info("Total first: " + totalfirst);
                    totalsecond = (daycount * 2) + 15; //no of officers for second shift
                    //objLog.info("Total second: " + totalsecond);

                    //prepare schedule only once
                    strQuery = "select * from scheduledetails where startdate='" + strStartDate + "' and enddate='" + strEndDate + "'";
                    rs1 = stmt.executeQuery(strQuery);
                    if (rs1.first()) //schedule already prepared
                    {
                        strFlag1 = "false";
                    }
                    rs1.close();

                    if (strFlag1.equals("true")) {

                        stmt.executeUpdate("update firstshiftdo set scheduled='Y' where empcode in (select empcode from dodetails where excludefromdate between '" + strStartDate + "' and '" + strEndDate + "' or excludetilldate between '" + strStartDate + "' and '" + strEndDate + "' or '" + strStartDate + "' between excludefromdate and excludetilldate)");
                        stmt.executeUpdate("update anyshiftdo set scheduled='Y' where empcode in (select empcode from dodetails where excludefromdate between '" + strStartDate + "' and '" + strEndDate + "' or excludetilldate between '" + strStartDate + "' and '" + strEndDate + "' or '" + strStartDate + "' between excludefromdate and excludetilldate)");

                        strQuery = "select startdate, enddate from scheduledetails where status='PREV'";
                        rs1 = stmt.executeQuery(strQuery);
                        if (rs1.first()) // include those whose exclude tilldate is between second previous start date and end date OR if his excludestartdate is after new schedule enddate
                        {
                            strQuery = "update firstshiftdo set scheduled='N' where scheduled='Y' and empcode in (select empcode from dodetails where excludetilldate between '" + rs1.getString(1) + "' and '" + rs1.getString(2) + "' )";
                            stmt1.executeUpdate(strQuery);
                            //objLog.info(strQuery);

                            strQuery = "update anyshiftdo set scheduled='N' where scheduled='Y' and empcode in (select empcode from dodetails where excludetilldate between '" + rs1.getString(1) + "' and '" + rs1.getString(2) + "' )";
                            stmt1.executeUpdate(strQuery);
                            //objLog.info(strQuery);
                        }
                        rs1.close();

                        //insert in scheduledetails table

                        strQuery = "select max(scheduleno) as maxcode from scheduledetails";
                        rs1 = stmt.executeQuery(strQuery);
                        if (rs1.next()) {
                            maxid = rs1.getInt("maxcode");
                            maxid = maxid + 1;
                        } else {
                            maxid = 1;
                        }
                        rs1.close();

                        strQuery = "update scheduledetails set status='OLD' where status='PREV'";
                        stmt.executeUpdate(strQuery);

                        strQuery = "update scheduledetails set status='PREV' where status='NEW'";
                        stmt.executeUpdate(strQuery);

                        strQuery = "insert into scheduledetails values('" + maxid + "', '" + strStartDate + "',  '" + strEndDate + "',  '" + strStatus + "', 'N')";
                        stmt.executeUpdate(strQuery);
                        strQuery = "select firstshiftdo.empcode, sex,designation from firstshiftdo, dodetails where firstshiftdo.empcode=dodetails.empcode and scheduled='N'  order by prevdutydate asc, empname";
                        rs1 = stmt.executeQuery(strQuery);

                        strQuery = "select anyshiftdo.empcode, prevshift1, prevshift2,sex,designation from anyshiftdo, dodetails where anyshiftdo.empcode=dodetails.empcode and scheduled='N'  order by prevdutydate asc, empname";
                        rs2 = stmt1.executeQuery(strQuery);



                        while (firstShiftCount < totalfirst || secondShiftCount < totalsecond) //repeat until counts match
                        {
                            if (rs1.next() && firstShiftCount < totalfirst) //allot to first shift
                            {

                                arFirstShift.add(rs1.getString(1));    //empcode
                                arFirstShift.add(rs1.getString(2)); //sex
                                arFirstShift.add(rs1.getString("designation")); //designation
                                firstShiftCount += 1;
                                shift = "F"; //next allotment
                            } else {
                                if (shift.equals("over")) {
                                    shift = "S1";
                                }
                            }

                            while (!shift.equals("over")) {
                                if (rs2.next()) {


                                    second = rs2.getString(1);    //empcode
                                    prevshift1 = rs2.getString(2);
                                    prevshift2 = rs2.getString(3);
                                    sex = rs2.getString(4);
                                    designation = rs2.getString("designation");//designation

                                    if (shift.equals("F")) {
                                        if (!prevshift1.equals("FIRST")) //allot first shift if prevshift1<>FIRST
                                        {
                                            arFirstShift.add(second);
                                            arFirstShift.add(sex);
                                            arFirstShift.add(designation);
                                            firstShiftCount += 1;
                                            shift = "S1";

                                        } else //else allot second shift
                                        {
                                            arSecondShift.add(second);
                                            arSecondShift.add(designation);
                                            secondShiftCount += 1;

                                        }
                                    } else {
                                        if (shift.equals("S1")) {
                                            if (!(prevshift1.equals("SECOND") && prevshift2.equals("SECOND"))) {
                                                arSecondShift.add(second); //allot second shift if both prevshifts <> SECOND
                                                arSecondShift.add(designation);
                                                secondShiftCount += 1;
                                                shift = "S2";
                                            } else {
                                                arFirstShift.add(second);     //else allot first shift
                                                arFirstShift.add(sex);
                                                arFirstShift.add(designation);
                                                firstShiftCount += 1;

                                            }
                                        } else {

                                            if (shift.equals("S2")) {
                                                if (!(prevshift1.equals("SECOND") && prevshift2.equals("SECOND"))) {
                                                    arSecondShift.add(second); //allot second shift if both prevshifts <> SECOND
                                                    arSecondShift.add(designation);
                                                    secondShiftCount += 1;
                                                    shift = "over";

                                                } else {
                                                        arFirstShift.add(second);      //else allot first shift
                                                        arFirstShift.add(sex);
                                                        arFirstShift.add(designation);
                                                        firstShiftCount += 1;

                                                }

                                            }
                                        }
                                    }
                                } else {
                                    frs2 = 1; //anyshift empty
                                    break;
                                }
                            }
                            //objLog.info("Second shift count: " + secondShiftCount);

                            if (frs2 == 1) //anyshift is empty
                            {
                                break;
                            }
                        }
                        rs1.close();
                        rs2.close();

                        //get holiday dates from table
                        strQuery = "select holidaydate from holiday where holidaydate between '" + strStartDate + "' and '" + strEndDate + "' order by holidaydate";
                        rs1 = stmt.executeQuery(strQuery);

                        while (rs1.next()) {
                            arHoliday.add(rs1.getString(1));
                        }
                        rs1.close();

                        Iterator FirstShiftIterator = arFirstShift.iterator();
                        Iterator SecondShiftIterator = arSecondShift.iterator();

                        //seperate sc and non sc in second shift array

                        while (SecondShiftIterator.hasNext()) {
                            strEmpcode = (String) SecondShiftIterator.next();
                            designation = (String) SecondShiftIterator.next();
                            if (designation.equals("SCI/ENG.SC")) {
                                arSecondShiftSC.add(strEmpcode);
                            } else {
                                arSecondShiftNonSC.add(strEmpcode);
                            }
                        }


                        //separate male & female officers from firstshift array

                            while (FirstShiftIterator.hasNext()) {
                            strEmpcode = (String) FirstShiftIterator.next();
                            sex = (String) FirstShiftIterator.next();
                            designation = (String) FirstShiftIterator.next();
                            if (sex.equals("F")) //add female to female array list
                            {
                                if (designation.equals("SCI/ENG.SC")) {
                                    arFemaleFirstShiftSC.add(strEmpcode);
                                } else {
                                     arFemaleFirstShiftNonSC.add(strEmpcode);
                                }

                            } else {
                                if (designation.equals("SCI/ENG.SC")) {
                                    arMaleFirstShiftSC.add(strEmpcode);
                                } else {
                                    arMaleFirstShiftNonSC.add(strEmpcode);
                                }

                            }
                        }

                        Iterator MaleFirstShiftIteratorNonSC = arMaleFirstShiftNonSC.iterator();
                        Iterator MaleFirstShiftIteratorSC = arMaleFirstShiftSC.iterator();
                        Iterator FemaleFirstShiftIteratorNonSC = arFemaleFirstShiftNonSC.iterator();
                        Iterator FemaleFirstShiftIteratorSC = arFemaleFirstShiftSC.iterator();
                        Iterator SecondShiftIteratorNonSC = arSecondShiftNonSC.iterator();
                        Iterator SecondShiftIteratorSC = arSecondShiftSC.iterator();


                        //get saturdays & sundays between start & end dates
                        // int com = 0;
                        strIncDate = strStartDate;
                        while (d1.compareDate(strIncDate, strEndDate) < 1) {
                            //   com = d1.compareDate(strIncDate, strEndDate);
                            strQuery = "select dayofweek('" + strIncDate + "')";
                            rs1 = stmt.executeQuery(strQuery);
                            if (rs1.next()) {
                                dayofweek = rs1.getString(1);
                            }
                            rs1.close();
                            //if holiday put 2 male officers in both the shifts (one SC and one non-SC)
                            if (dayofweek.equals("1") || dayofweek.equals("7") || arHoliday.contains(strIncDate) == true) //saturday or sunday or holiday
                            {
                                fcount = 0;
                                scount = 0;
                                strDesgFlag = "SC";//can take a sc officer next
                                while (fcount < 2) {

                                    //pick male first officer to put in first shift on holidays
                                    if (MaleFirstShiftIteratorSC.hasNext() && strDesgFlag.equals("SC")) {

                                        strEmpcode = (String) MaleFirstShiftIteratorSC.next();
                                        strDesgFlag = "non-SC";//should take a non  sc officer next
                                    } else if (MaleFirstShiftIteratorNonSC.hasNext()) {

                                        strEmpcode = (String) MaleFirstShiftIteratorNonSC.next();
                                        strDesgFlag = "SC";//can take a sc officer next
                                    } //male first list is empty take from male second list
                                    else if (SecondShiftIteratorSC.hasNext() && strDesgFlag.equals("SC")) {

                                        strEmpcode = (String) SecondShiftIteratorSC.next();
                                        strDesgFlag = "non-SC";//should take a non  sc officer next
                                    } else if (SecondShiftIteratorNonSC.hasNext()) {

                                        strEmpcode = (String) SecondShiftIteratorNonSC.next();
                                        strDesgFlag = "SC";//can take a sc officer next
                                    }

                                    //insert into doschedule  with empcode, dutydate and shift
                                    strQuery = "insert into doschedule values ('" + strEmpcode + "','" + strIncDate + "', 'FIRST', '" + maxid + "', '0000-00-00 00:00:00','N', 'N', '.') ";
                                    stmt.executeUpdate(strQuery);
                                    fcount += 1;
                                    //set scheduled=Y
                                    stmt.executeUpdate("update firstshiftdo set scheduled='Y' where empcode='" + strEmpcode + "'");
                                    stmt.executeUpdate("update anyshiftdo set scheduled='Y' where empcode='" + strEmpcode + "'");

                                }

                                strDesgFlag = "SC";//can take a sc officer next
                                while (scount < 2) //allot second shift officers on holidays
                                {
                                    if (SecondShiftIteratorSC.hasNext() && strDesgFlag.equals("SC")) {

                                        strEmpcode = (String) SecondShiftIteratorSC.next();
                                        strDesgFlag = "non-SC";//should take a non  sc officer next
                                    } else if (SecondShiftIteratorNonSC.hasNext()) {

                                        strEmpcode = (String) SecondShiftIteratorNonSC.next();
                                        strDesgFlag = "SC";//can take a sc officer next
                                    } else if (MaleFirstShiftIteratorSC.hasNext() && strDesgFlag.equals("SC")) {

                                        strEmpcode = (String) MaleFirstShiftIteratorSC.next();
                                        strDesgFlag = "non-SC";//should take a non  sc officer next
                                    }else if (MaleFirstShiftIteratorNonSC.hasNext()) {

                                        strEmpcode = (String) MaleFirstShiftIteratorNonSC.next();
                                        strDesgFlag = "SC";//can take a sc officer next
                                    }  

                                    strQuery = "insert into doschedule values ('" + strEmpcode + "','" + strIncDate + "', 'SECOND', '" + maxid + "', '0000-00-00 00:00:00','N', 'N', '.') ";
                                    stmt.executeUpdate(strQuery);
                                    scount += 1;
                                    stmt.executeUpdate("update firstshiftdo set scheduled='Y' where empcode='" + strEmpcode + "'");
                                    stmt.executeUpdate("update anyshiftdo set scheduled='Y' where empcode='" + strEmpcode + "'");

                                }//end of if loop for holidays scheduling
                            } else //add week days to arraylist
                            {
                                arWeekday.add(strIncDate);
                            }

                            //increment date
                            strQuery = "select DATE_ADD('" + strIncDate + "',INTERVAL 1 DAY)";
                            rs2 = stmt1.executeQuery(strQuery);
                            if (rs2.next()) {
                                strIncDate = rs2.getString(1);
                                //objLog.info("Inc Date: " + strIncDate);
                            }
                            rs2.close();
                        }

                        Iterator WeekdayIterator = arWeekday.iterator();

                        //allot officers on weekdays
                        if (!arWeekday.isEmpty()) {
                            strSexFlag = "F";//can take a female officer next
                            strDesgFlag = "SC";//can take a sc officer next
                            while (WeekdayIterator.hasNext()) {

                                strDate = (String) WeekdayIterator.next();
                                fcount = 0;
                                scount = 0;
                                
                                while (fcount < 2) {

                                    if (FemaleFirstShiftIteratorSC.hasNext() && strSexFlag.equals("F") && strDesgFlag.equals("SC")) //take one officer from SC female list only if earlier one was non-sc male officer
                                    {
                                        strEmpcode = (String) FemaleFirstShiftIteratorSC.next();
                                        strSexFlag = "M"; //should take a male officer next
                                        strDesgFlag = "non-SC";//should take a non  sc officer next

                                    } else if (MaleFirstShiftIteratorSC.hasNext() && strDesgFlag.equals("SC")) {
                                        strEmpcode = (String) MaleFirstShiftIteratorSC.next();
                                        strSexFlag = "F"; //can take a female officer next
                                        strDesgFlag = "non-SC";//should take a non  sc officer next

                                    } else if (FemaleFirstShiftIteratorNonSC.hasNext() && strSexFlag.equals("F")) //take one officer from non-SC female list
                                    {
                                        strEmpcode = (String) FemaleFirstShiftIteratorNonSC.next();
                                        strSexFlag = "M"; //should take a male officer next
                                        strDesgFlag = "SC";//can take a sc officer next

                                    } else if (MaleFirstShiftIteratorNonSC.hasNext()) {

                                        strEmpcode = (String) MaleFirstShiftIteratorNonSC.next();
                                        strSexFlag = "F"; //can take a female officer next
                                        strDesgFlag = "SC";//can take a sc officer next
                                    } else if (SecondShiftIteratorSC.hasNext() && strDesgFlag.equals("SC")) {

                                        strEmpcode = (String) SecondShiftIteratorSC.next();
                                        strSexFlag = "F"; //can take a female officer next
                                        strDesgFlag = "non-SC";//should take a non  sc officer next
                                    } else if (SecondShiftIteratorNonSC.hasNext()) {

                                        strEmpcode = (String) SecondShiftIteratorNonSC.next();
                                        strSexFlag = "F"; //can take a female officer next
                                        strDesgFlag = "SC";//can take a sc officer next
                                    }


                                    strQuery = "insert into doschedule values ('" + strEmpcode + "','" + strDate + "', 'FIRST', '" + maxid + "', '0000-00-00 00:00:00','N', 'N', '.') ";
                                    stmt.executeUpdate(strQuery);
                                    fcount += 1;
                                    //set scheduled=Y
                                    stmt.executeUpdate("update firstshiftdo set scheduled='Y' where empcode='" + strEmpcode + "'");
                                    stmt.executeUpdate("update anyshiftdo set scheduled='Y' where empcode='" + strEmpcode + "'");

                                }

                                strDesgFlag = "SC";//can take a sc officer next

                                while (scount < 2) //allot second shift
                                {
                                    //pick first officer to put in second shift on week days

                                    if (SecondShiftIteratorSC.hasNext() && strDesgFlag.equals("SC")) {

                                        strEmpcode = (String) SecondShiftIteratorSC.next();
                                        strDesgFlag = "non-SC";//should take a non  sc officer next
                                    } else if (SecondShiftIteratorNonSC.hasNext()) {

                                        strEmpcode = (String) SecondShiftIteratorNonSC.next();
                                        strDesgFlag = "SC";//can take a sc officer next
                                    } else if (MaleFirstShiftIteratorSC.hasNext() && strDesgFlag.equals("SC")) {

                                        strEmpcode = (String) MaleFirstShiftIteratorSC.next();
                                        strDesgFlag = "non-SC";//should take a non  sc officer next
                                    } else if (MaleFirstShiftIteratorNonSC.hasNext()) {

                                        strEmpcode = (String) MaleFirstShiftIteratorNonSC.next();
                                        strDesgFlag = "SC";//can take a sc officer next
                                    }

                                    strQuery = "insert into doschedule values ('" + strEmpcode + "','" + strDate + "', 'SECOND', '" + maxid + "', '0000-00-00 00:00:00','N', 'N', '.') ";
                                    stmt.executeUpdate(strQuery);
                                    scount += 1;
                                    //set scheduled=Y
                                    stmt.executeUpdate("update firstshiftdo set scheduled='Y' where empcode='" + strEmpcode + "'");
                                    stmt.executeUpdate("update anyshiftdo set scheduled='Y' where empcode='" + strEmpcode + "'");

                                }
                            }
                        }
                    }

                    //select schedule list
                    strQuery = "SELECT scheduledate,dayofweek(scheduledate),a.shift,empname,a.empcode,division,sex,designation,sittingphone,resphone,mobile ";
                    strQuery = strQuery + "FROM doschedule a, doaddress b, dodetails c where (a.scheduledate between '" + strStartDate + "' and '" + strEndDate + "') and ";
                    strQuery = strQuery + "a.empcode=b.empcode  and a.empcode=c.empcode order by scheduledate, a.shift,empname";
                    rs1 = stmt.executeQuery(strQuery);

                    //objLog.info(strQuery);

                    while (rs1.next()) {


                        arSchedule.add(d1.datedisplay(rs1.getString(1)));
                        arSchedule.add(rs1.getString(2));
                        arSchedule.add(rs1.getString(3));
                        arSchedule.add(rs1.getString(4));
                        arSchedule.add(rs1.getString(5));
                        arSchedule.add(rs1.getString(6));
                        arSchedule.add(rs1.getString(7));
                        arSchedule.add(rs1.getString(8));
                        arSchedule.add(rs1.getString(9));
                        arSchedule.add(rs1.getString(10));
                        arSchedule.add(rs1.getString(11));

                    }
                    rs1.close();


                    request.setAttribute("StartDate", strStartDate1);
                    request.setAttribute("EndDate", strEndDate1);
                    request.setAttribute("arSchedule", arSchedule);
                    view = request.getRequestDispatcher("viewSchedule.jsp");
                    view.forward(request, response);
                }
            }
        } catch (Exception e) {
            //objLog.error("ERROR : " + e);
            view = request.getRequestDispatcher("Failure.jsp");
            view.forward(request, response);
        } finally {
            db.close();
        }
    }
}
