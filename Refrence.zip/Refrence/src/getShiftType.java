// Function : get shift details from shift table
// Author   : Gadha PS, Anju Varghese
// Division : COM/CIG
// Date     : 28/01/2009

import java.io.*;
import java.util.*;
import java.util.Date;
import java.text.*;
import java.lang.String;
import java.sql.*;
import java.net.*;
import javax.servlet.*;
import javax.servlet.http.*;
import org.apache.log4j.Logger;

public class getShiftType extends HttpServlet {
    
    protected void doGet(HttpServletRequest request, HttpServletResponse response)
    throws ServletException, IOException {
        doPost(request,response);
    }
    
    protected void doPost(HttpServletRequest request, HttpServletResponse response)
    throws ServletException, IOException {
        
        RequestDispatcher view = null;
        PrintWriter out= response.getWriter();
        dbConn db=new dbConn();
        ArrayList ShiftType=new ArrayList();
       // Logger //objLog = Logger.getLogger("ApplicationDO");
        try
        {
            Connection conn= null;
            conn = db.Connect();
            Statement stmt = conn.createStatement();
            ResultSet rs1=null;
            String strFlag="invalidSession";
            String strQuery;
            
            // Get session
            HttpSession curSession=request.getSession(false);
            // Check if valid session
            if(curSession==null)
            {
                //objLog.error("Invalid session");
                request.setAttribute("flag",strFlag);
                view=request.getRequestDispatcher("sessionError.jsp");
                view.forward(request, response);
            }
            
            else //valid session
            {
                if((String)curSession.getAttribute("userid")==null)
                {
                    //objLog.error("Invalid session");
                    request.setAttribute("flag",strFlag);
                    view=request.getRequestDispatcher("sessionError.jsp");
                    view.forward(request, response);
                }
                else
                {
                    strQuery="select * from shifttype order by shift_id";
                    //objLog.info(strQuery);
                    rs1=stmt.executeQuery(strQuery);
                    while(rs1.next())
                    {
                        ShiftType.add(rs1.getString(1));
                        ShiftType.add(rs1.getString(2));
                        ShiftType.add(rs1.getString(3));
                        ShiftType.add(rs1.getString(4));
                    }
                    rs1.close();
                    
                    request.setAttribute("ShiftType",ShiftType);
                    view = request.getRequestDispatcher("addShift.jsp");
                    view.forward(request, response);
                }
            }
        }
        catch(Exception e)
        {
            //objLog.error("ERROR : "+e);
            view = request.getRequestDispatcher("Failure.jsp");
            view.forward(request, response);
        }
        finally
        {
            db.close();            
        }
    }    
}
