// Function : get role details from role table
// Author   : Gadha PS, Anju Varghese
// Division : COM/CIG
// Date     : 28/01/2009

import java.io.*;
import java.util.*;
import java.util.Date;
import java.text.*;
import java.lang.String;
import java.sql.*;
import java.net.*;
import javax.servlet.*;
import javax.servlet.http.*;
import org.apache.log4j.Logger;
import dateform.*;

public class saveDOReserve extends HttpServlet {

    protected void doGet(HttpServletRequest request, HttpServletResponse response)
    throws ServletException, IOException {
        doPost(request,response);
    }

    protected void doPost(HttpServletRequest request, HttpServletResponse response)
    throws ServletException, IOException {

        RequestDispatcher view = null;
        PrintWriter out= response.getWriter();
        dbConn db=new dbConn();
        dateformat d1=new dateformat();
       // Logger //objLog = Logger.getLogger("ApplicationDO");
        try
{
            Connection conn= null;
            conn = db.Connect();
            Statement stmt = conn.createStatement();
            ResultSet rs1=null;
            String strFlag="invalidSession";
            String strStaffcode="", strQuery="", strFlagDO="false",  strFlagReserve="false",strLoginDateTime="";
            String strShift="", strDutyDate="", strName="", strDivision="", strDesgn="", strSex="", strPhone="";

            // Get session
            HttpSession curSession=request.getSession(false);
            // Check if valid session
            if(curSession==null)
{
                //objLog.error("Invalid session");
                request.setAttribute("flag",strFlag);
                view=request.getRequestDispatcher("sessionError.jsp");
                view.forward(request, response);
            }

            else //valid session
            {
                if((String)curSession.getAttribute("userid")==null)
{
                    //objLog.error("Invalid session");
                    request.setAttribute("flag",strFlag);
                    view=request.getRequestDispatcher("sessionError.jsp");
                    view.forward(request, response);
                }
                else
                {
                     //get staffcode of logged in person
                  //  strStaffcode=(String)curSession.getAttribute("userid");
               //     //objLog.info("Staffcode of logged in officer: "+strStaffcode);

                    strStaffcode=request.getParameter("txtStaffcode");
                    strStaffcode=strStaffcode.toUpperCase();
                    strShift=request.getParameter("cboShift");
                    strDutyDate=d1.savedate(request.getParameter("txtDutydate"));
                    strName=request.getParameter("txtName");
                    strDivision=request.getParameter("txtDivision");
                    strDesgn=request.getParameter("txtDesgn");
                    strSex=request.getParameter("cboSex");
                    strPhone=request.getParameter("txtPhone");
                   // strFlagDO=request.getParameter("flagDO");
                	strFlagReserve=request.getParameter("flagReserve");              

                        strLoginDateTime=strDutyDate+" 07:00:00";

                   strQuery="insert into reservedutydone values('"+strStaffcode+"','"+strDutyDate+"', '"+strShift+"','"+strLoginDateTime+"')";
                    //objLog.info(strQuery);
                    stmt.executeUpdate(strQuery);
                        
                    if (strFlagReserve.equals("true"))
                    {
                        strQuery="insert into reservelist values('"+strStaffcode+"','"+strName+"', '"+strDivision+"','"+strDesgn+"','"+strSex+"','"+strPhone+"' )";
                        //objLog.info(strQuery);
                        stmt.executeUpdate(strQuery);
                    }                    
                   
                        //update anyshift/firstshiftdo
                      strQuery="update firstshiftdo set prevshift2=prevshift1, prevshift1='"+strShift+"', scheduled='N', prevdutydate='"+strDutyDate+"' where empcode='"+strStaffcode+"'";
                      //objLog.info(strQuery);
                      stmt.executeUpdate(strQuery);
                      
                      strQuery="update anyshiftdo set prevshift2=prevshift1, prevshift1='"+strShift+"', scheduled='N', prevdutydate='"+strDutyDate+"' where empcode='"+strStaffcode+"'";
                      //objLog.info(strQuery);
                      stmt.executeUpdate(strQuery);
                                         
                      //update dodetails
                      if (strShift.equals("FIRST"))
                      {
                        strQuery="update dodetails set nooffirstshift=nooffirstshift+1 where empcode='"+strStaffcode+"'";
                      }
                      else
                      {
                          strQuery="update dodetails set noofsecondshift=noofsecondshift+1 where empcode='"+strStaffcode+"'";
                      }
                      stmt.executeUpdate(strQuery);                   
                 

                    view=request.getRequestDispatcher("markReserveDO.jsp");
                     view.forward(request, response);
                }
            }
        }
catch(Exception e)
{
    //objLog.error("ERROR : "+e);
    view = request.getRequestDispatcher("Failure.jsp");
    view.forward(request, response);
}
finally
{
    db.close();
}
    }
}
