// Function : edit holiday
// Author   : Gadha PS, Anju Varghese
// Division : COM/CIG
// Date     : 28/01/2009

import java.io.*;
import java.util.*;
import java.util.Date;
import java.text.*;
import java.lang.String;
import java.sql.*;
import java.net.*;
import javax.servlet.*;
import javax.servlet.http.*;
import org.apache.log4j.Logger;
import dateform.*;

public class editHoliday extends HttpServlet {
    
    protected void doGet(HttpServletRequest request, HttpServletResponse response)
    throws ServletException, IOException {
        doPost(request,response);
    }
    
    protected void doPost(HttpServletRequest request, HttpServletResponse response)
    throws ServletException, IOException {
        
        RequestDispatcher view = null;
        PrintWriter out= response.getWriter();
        dbConn db=new dbConn();
        dateformat d1=new dateformat();
     //   Logger //objLog = Logger.getLogger("ApplicationDO");
        try
{
            Connection conn= null;
            conn = db.Connect();
            Statement stmt = conn.createStatement();
            ResultSet rs1=null;
            String strFlag="invalidSession",strDate="",strHoliday="", strQuery="", strYear="";
            
            // Get session
            HttpSession curSession=request.getSession(false);
            // Check if valid session
            if(curSession==null)
{
                //objLog.error("Invalid session");
                request.setAttribute("flag",strFlag);
                view=request.getRequestDispatcher("sessionError.jsp");
                view.forward(request, response);
            }
            
            else //valid session
            {
                if((String)curSession.getAttribute("userid")==null)
{
                    //objLog.error("Invalid session");
                    request.setAttribute("flag",strFlag);
                    view=request.getRequestDispatcher("sessionError.jsp");
                    view.forward(request, response);
                }
                else
                {
                    strDate = request.getParameter("txtDate");
                strDate = d1.savedate(strDate);
                strHoliday = request.getParameter("txtHoliday");
                int hol_id = Integer.parseInt(request.getParameter("Hol_id"));
                strYear=request.getParameter("Year");
                
                strQuery = "select * from holiday where holidaydate = '"+strDate+"' and holidayname='"+strHoliday+"'";
                rs1 = stmt.executeQuery(strQuery);
                if (rs1.next())
                {
                    view=request.getRequestDispatcher("duplicateError.jsp");
                    view.forward(request, response);
                }
                else
                {                                      
                    strQuery = "update holiday set holidayname='"+strHoliday+"', holidaydate= '"+strDate+"' where holiday_id='"+hol_id+"'";
                    int success = stmt.executeUpdate(strQuery);
                    
                    request.setAttribute("strYear", strYear);
                    view=request.getRequestDispatcher("getHoliday.do?link=new");
                    view.forward(request, response);
                    
                }
            }
            }
        }
catch(Exception e)
{
    //objLog.error("ERROR : "+e);
    view = request.getRequestDispatcher("Failure.jsp");
    view.forward(request, response);
}
finally
{
    db.close();
}
    }
}
