// Function : get role details from role table
// Author   : Gadha PS, Anju Varghese
// Division : COM/CIG
// Date     : 28/01/2009

import java.io.*;
import java.util.*;
import java.util.Date;
import java.text.*;
import java.lang.String;
import java.sql.*;
import java.net.*;
import javax.servlet.*;
import javax.servlet.http.*;
import org.apache.log4j.Logger;
import dateform.*;

public class getHoliday extends HttpServlet {
    
    protected void doGet(HttpServletRequest request, HttpServletResponse response)
    throws ServletException, IOException {
        doPost(request,response);
    }
    
    protected void doPost(HttpServletRequest request, HttpServletResponse response)
    throws ServletException, IOException {
        
        RequestDispatcher view = null;
        PrintWriter out= response.getWriter();
        dbConn db=new dbConn();
        dateformat d1=new dateformat();
     //   Logger //objLog = Logger.getLogger("ApplicationDO");
        try
{
            Connection conn= null;
            conn = db.Connect();
            Statement stmt = conn.createStatement();
            ResultSet rs1=null;
            ArrayList Holiday=new ArrayList();
            String strFlag="invalidSession", strYear="", strQuery="",strYearFlag="";
            
            // Get session
            HttpSession curSession=request.getSession(false);
            // Check if valid session
            if(curSession==null)
{
                //objLog.error("Invalid session");
                request.setAttribute("flag",strFlag);
                view=request.getRequestDispatcher("sessionError.jsp");
                view.forward(request, response);
            }
            
            else //valid session
            {
                if((String)curSession.getAttribute("userid")==null)
{
                    //objLog.error("Invalid session");
                    request.setAttribute("flag",strFlag);
                    view=request.getRequestDispatcher("sessionError.jsp");
                    view.forward(request, response);
                }
                else
                {
                    strYearFlag=request.getParameter("link");
                    if(strYearFlag.equals("edit"))
                    {
                        strYear=request.getParameter("cboYear");
                    }
                    else
                    {
                    strYear=(String)request.getAttribute("strYear");
                    }
                    //objLog.info("Year in getHol: "+strYear);
                    
                    strQuery="select * from holiday where year(holidaydate)='"+strYear+"' order by holidaydate ";                   
                    rs1=stmt.executeQuery(strQuery);
                    while(rs1.next())
                    {
                        Holiday.add(rs1.getString(1));                       
                        Holiday.add(rs1.getString(2));
                         Holiday.add(d1.datedisplay(rs1.getString(3)));
                    }
                    rs1.close();
                    
                    request.setAttribute("Year",strYear);
                    request.setAttribute("Holiday",Holiday);
                    view = request.getRequestDispatcher("addHoliday.jsp");
                    view.forward(request, response);
                }
            }
        }
catch(Exception e)
{
    //objLog.error("ERROR : "+e);
    view = request.getRequestDispatcher("Failure.jsp");
    view.forward(request, response);
}
finally
{
    db.close();
}
    }
}
