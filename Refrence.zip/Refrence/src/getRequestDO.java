// Function : get role details from role table
// Author   : Gadha PS, Anju Varghese
// Division : COM/CIG
// Date     : 28/01/2009

import java.io.*;
import java.util.*;
import java.util.Date;
import java.text.*;
import java.lang.String;
import java.sql.*;
import java.net.*;
import javax.servlet.*;
import javax.servlet.http.*;
import org.apache.log4j.Logger;
import dateform.*;

public class getRequestDO extends HttpServlet {
    
    protected void doGet(HttpServletRequest request, HttpServletResponse response)
    throws ServletException, IOException {
        doPost(request,response);
    }
    
    protected void doPost(HttpServletRequest request, HttpServletResponse response)
    throws ServletException, IOException {
        
        RequestDispatcher view = null;
        PrintWriter out= response.getWriter();
        dbConn db=new dbConn();
        dateformat d1=new dateformat();
       // Logger //objLog = Logger.getLogger("ApplicationDO");
        try
{
            Connection conn= null;
            conn = db.Connect();
            Statement stmt = conn.createStatement();
            ResultSet rs1=null;
            ArrayList arExDetails=new ArrayList();
            String strFlag="invalidSession", strStartdate="", strEnddate="", strStaffcode="", strScheduledate="", strExStaffcode="", strQuery="";
            String strShift="";
            
            // Get session
            HttpSession curSession=request.getSession(false);
            // Check if valid session
            if(curSession==null)
{
                //objLog.error("Invalid session");
                request.setAttribute("flag",strFlag);
                view=request.getRequestDispatcher("sessionError.jsp");
                view.forward(request, response);
            }
            
            else //valid session
            {
                if((String)curSession.getAttribute("userid")==null)
{
                    //objLog.error("Invalid session");
                    request.setAttribute("flag",strFlag);
                    view=request.getRequestDispatcher("sessionError.jsp");
                    view.forward(request, response);
                }
                else
                {
                    strStartdate=request.getParameter("sdate");
                    strEnddate=request.getParameter("edate");
                   strStartdate=d1.savedate(strStartdate);
                   strEnddate=d1.savedate(strEnddate);
                    strStaffcode=(String)curSession.getAttribute("userid");
                    strScheduledate=request.getParameter("scdate");
                    strShift=request.getParameter("shift");
                    
                    
                    strQuery="SELECT scheduledate,a.shift,empname,a.empcode,designation,division FROM doschedule a, dodetails b where a.empcode=b.empcode and a.empcode in (select empcode1 from exchangedo where empcode2='"+strStaffcode+"' and exchangeflag='1' and scheduledate between '"+strStartdate+"' and '"+strEnddate+"') and scheduledate between '"+strStartdate+"' and '"+strEnddate+"' ";
                   //objLog.info(strQuery);
                    rs1=stmt.executeQuery(strQuery);
                    if (rs1.next())
                    {
                        arExDetails.add(d1.datedisplay(rs1.getString(1)));
                        arExDetails.add(rs1.getString(2));
                        arExDetails.add(rs1.getString(3));
                        arExDetails.add(rs1.getString(4));
                        arExDetails.add(rs1.getString(5));
                        arExDetails.add(rs1.getString(6));
                    }
                    rs1.close();
                    
                    request.setAttribute("arExDetails",arExDetails);
                    request.setAttribute("strStaffcode",strStaffcode);
                    request.setAttribute("strScheduledate",strScheduledate);
                    request.setAttribute("strShift",strShift);
                     view = request.getRequestDispatcher("requestDODetails.jsp");                
                    view.forward(request, response);
                    
                }
            }
        }
catch(Exception e)
{
    //objLog.error("ERROR : "+e);
    view = request.getRequestDispatcher("Failure.jsp");
    view.forward(request, response);
}
finally
{
    db.close();
}
    }
}
