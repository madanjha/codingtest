// Function : get role details from role table
// Author   : Gadha PS, Anju Varghese
// Division : COM/CIG
// Date     : 28/01/2009

import java.io.*;
import java.util.*;
import java.util.Date;
import java.text.*;
import java.lang.String;
import java.sql.*;
import java.net.*;
import javax.servlet.*;
import javax.servlet.http.*;
import org.apache.log4j.Logger;
import dateform.*;

public class getObservationDO extends HttpServlet {
    
    protected void doGet(HttpServletRequest request, HttpServletResponse response)
    throws ServletException, IOException {
        doPost(request,response);
    }
    
    protected void doPost(HttpServletRequest request, HttpServletResponse response)
    throws ServletException, IOException {
        
        RequestDispatcher view = null;
        PrintWriter out= response.getWriter();
        dbConn db=new dbConn();
        dateformat d1=new dateformat();
      //  Logger //objLog = Logger.getLogger("ApplicationDO");
        try
{
            Connection conn= null;
            conn = db.Connect();
            Statement stmt = conn.createStatement();
             Statement stmt2 = conn.createStatement();
            ResultSet rs1=null, rs2=null;
            String strFlag="invalidSession", strDutyDate="", strShift="", strListFlag="true", strQuery="",strDutyDate1="", strEmpcode="",strDutyFlag="false", strUserid="";
             ArrayList arrObservations= new ArrayList();
            
            // Get session
            HttpSession curSession=request.getSession(false);
            // Check if valid session
            if(curSession==null)
{
                //objLog.error("Invalid session");
                request.setAttribute("flag",strFlag);
                view=request.getRequestDispatcher("sessionError.jsp");
                view.forward(request, response);
            }
            
            else //valid session
            {
                if((String)curSession.getAttribute("userid")==null)
{ 
                    //objLog.error("Invalid session");
                    request.setAttribute("flag",strFlag);
                    view=request.getRequestDispatcher("sessionError.jsp");
                    view.forward(request, response);
                }
                else
                {
                    strUserid=(String)curSession.getAttribute("userid");
                    
                    strDutyDate1=request.getParameter("txtDutyDate");
                    strDutyDate=d1.savedate(strDutyDate1);
                    strShift=request.getParameter("cboShift");
                    
                    //set flag to true if DO has done duty on the selected date
                    
                    strQuery="select empcode from doschedule where scheduledate='"+strDutyDate+"' and shift='"+strShift+"' and logindatetime<>'0000-00-00 00:00:00'";
                     rs1=stmt.executeQuery(strQuery);
                    while(rs1.next())
                    {
                         if (rs1.getString(1).equals(strUserid))
                         {
                             strDutyFlag ="true";
                         }
                    }
                     rs1.close();
                     
                      strQuery="select empcode from reservedutydone where dutydate='"+strDutyDate+"' and shift='"+strShift+"'";
                     rs1=stmt.executeQuery(strQuery);
                    while(rs1.next())
                    {
                         if (rs1.getString(1).equals(strUserid))
                         {
                             strDutyFlag ="true";
                         }
                    }
                     rs1.close();
                    
                    strQuery="select distinct empcode from observations where dutydate='"+strDutyDate+"' and shift='"+strShift+"' order by empcode";
                    //objLog.info(strQuery);
                    rs1=stmt.executeQuery(strQuery);
                    while(rs1.next())
                    {
                        strEmpcode=rs1.getString(1);
                        
                         strQuery="select * from dodetails where empcode='"+strEmpcode+"' ";
                         rs2=stmt2.executeQuery(strQuery);
                         if (rs2.next())
                         {
                             
                             strQuery="select observations.empcode, slno, observetime, empname, observepriority, observation,actionpriority,actionreqd,status,actiontaken  from observations, dodetails where dutydate='"+strDutyDate+"' and observations.shift='"+strShift+"' and observations.empcode=dodetails.empcode and observations.empcode='"+strEmpcode+"' order by observetime";
                         }
                         else
                         {
                            
                             strQuery="select observations.empcode, slno, observetime, empname, observepriority, observation,actionpriority,actionreqd,status,actiontaken  from observations, reservelist where dutydate='"+strDutyDate+"' and observations.shift='"+strShift+"' and observations.empcode=reservelist.empcode and observations.empcode='"+strEmpcode+"' order by observetime";
                         }
                        rs2.close();
                        
                          //objLog.info(strQuery);
                            rs2=stmt2.executeQuery(strQuery);
                            while (rs2.next())
                            {   
                                arrObservations.add(rs2.getString(1));
                                arrObservations.add(rs2.getString(2));
                                arrObservations.add(rs2.getString(3));
                                arrObservations.add(rs2.getString(4));
                                arrObservations.add(rs2.getString(5));
                                arrObservations.add(rs2.getString(6));
                                arrObservations.add(rs2.getString(7));
                                arrObservations.add(rs2.getString(8));
                                arrObservations.add(rs2.getString(9));
                                arrObservations.add(rs2.getString(10));                        
                            } 
                            rs2.close();
                    }
                                                   
                    rs1.close();
                    
                    request.setAttribute("arrObservations",arrObservations);
                    request.setAttribute("listFlag",strListFlag);
                    request.setAttribute("dutyFlag",strDutyFlag);
                    request.setAttribute("shift",strShift);
                    request.setAttribute("dutydate",strDutyDate1);                    
                    view=request.getRequestDispatcher("viewObservation.jsp");
                    view.forward(request, response);
                }
            }
        }
catch(Exception e)
{
    //objLog.error("ERROR : "+e);
    view = request.getRequestDispatcher("Failure.jsp");
    view.forward(request, response);
}
finally
{
    db.close();
}
    }
}
