// Function : get role details from role table
// Author   : Gadha PS, Anju Varghese
// Division : COM/CIG
// Date     : 28/01/2009

import java.io.*;
import java.util.*;
import java.util.Date;
import java.text.*;
import java.lang.String;
import java.sql.*;
import java.net.*;
import javax.servlet.*;
import javax.servlet.http.*;
import org.apache.log4j.Logger;
import dateform.*;
  
public class saveExemptDetails extends HttpServlet {
    
    protected void doGet(HttpServletRequest request, HttpServletResponse response)
    throws ServletException, IOException {
        doPost(request,response);
    }
    
    protected void doPost(HttpServletRequest request, HttpServletResponse response)
    throws ServletException, IOException {
        
        RequestDispatcher view = null;
        PrintWriter out= response.getWriter();
        dbConn db=new dbConn();
        dateformat d1=new dateformat();
       // Logger //objLog = Logger.getLogger("ApplicationDO");
        try
{
            Connection conn= null;
            conn = db.Connect();
            Statement stmt = conn.createStatement();
            ResultSet rs1=null;
            String strFlag="invalidSession", strStaffcode="", strExclude="N", strExcludePer="Y",strExcludeFromDate="0001-01-01", strExcludeDate="0001-01-01", strShift="ANY";
            String strQuery="",strEmpShift="", strEmpElig="", strEmpExDate="", strEmpRemarks="", strReason="", strCurdate="", strRemarks="", strEmpFrDate="", strSex="";
            // Get session
            HttpSession curSession=request.getSession(false);
            // Check if valid session
            if(curSession==null)
{
                //objLog.error("Invalid session");
                request.setAttribute("flag",strFlag);
                view=request.getRequestDispatcher("sessionError.jsp");
                view.forward(request, response);
            }
            
            else //valid session
            {
                if((String)curSession.getAttribute("userid")==null)
{
                    //objLog.error("Invalid session");
                    request.setAttribute("flag",strFlag);
                    view=request.getRequestDispatcher("sessionError.jsp");
                    view.forward(request, response);
                }
                else
                {
                    //objLog.info("-----Exempt DO-------");
                    strStaffcode=request.getParameter("txtStaffcode");
                    strReason=request.getParameter("txtReason");
                    strSex=request.getParameter("sex");
                    //objLog.info("staffcode: "+strStaffcode);
                    
                    //get old values from table
                    strQuery="select shift, eligibility, excludefromdate,excludetilldate, remarks, curdate() from dodetails where empcode='"+strStaffcode+"'";
                    rs1=stmt.executeQuery(strQuery);
                    if(rs1.next())
                    {
                        strEmpShift=rs1.getString(1);
                        strEmpElig=rs1.getString(2);
                        strEmpFrDate=rs1.getString(3);
                        strEmpExDate=rs1.getString(4);
                         //objLog.info("Prev Details: "+strEmpShift+","+strEmpElig+","+strEmpFrDate+","+strEmpExDate);
                         strEmpRemarks=rs1.getString(5);
                         strCurdate=rs1.getString(6);
                    }
                    rs1.close();
                    
                    if (request.getParameter("chkExcludeDate")!=null)
                    {
                        strExclude = "Y";         
                        strExcludeFromDate=request.getParameter("txtExcludeFromDate");      
                        strExcludeFromDate=d1.savedate(strExcludeFromDate);
                        strExcludeDate=request.getParameter("txtExcludeDate");      
                        strExcludeDate=d1.savedate(strExcludeDate);
                    }
                    
                     //objLog.info("Exclude flag : "+strExclude);
                    //objLog.info("Exclude date : "+strExcludeDate);
                    
                    if (!strExcludeDate.equals(strEmpExDate) || !strExcludeFromDate.equals(strEmpFrDate)) //if not same
                    {
                        strQuery="update dodetails set excludetilldate='"+strExcludeDate+"', excludefromdate='"+strExcludeFromDate+"' where empcode='"+strStaffcode+"'";
                        //objLog.info(strQuery);
                        stmt.executeUpdate(strQuery);
                        
                        if (strExclude.equals("Y"))  //now checked
                        {
                            //set scheduled='Y' if date>=curdate
                          //  strQuery="update anyshiftdo set scheduled='Y' where empcode='"+strStaffcode+"' and datediff('"+strExcludeDate+"',curdate())>=0";
                            strQuery="update anyshiftdo set scheduled='Y' where empcode='"+strStaffcode+"' and curdate() between '"+strExcludeFromDate+"' and '"+strExcludeDate+"'";
                            //objLog.info(strQuery);
                            stmt.executeUpdate(strQuery);
                          //  strQuery="update firstshiftdo set scheduled='Y' where empcode='"+strStaffcode+"' and datediff('"+strExcludeDate+"',curdate())>=0";
                            strQuery="update firstshiftdo set scheduled='Y' where empcode='"+strStaffcode+"' and curdate() between '"+strExcludeFromDate+"' and '"+strExcludeDate+"'";
                            //objLog.info(strQuery);
                            stmt.executeUpdate(strQuery);
                        }
                        else //now unchecked
                        {
                            //set scheduled='N'
                            strQuery="update anyshiftdo set scheduled='N' where empcode='"+strStaffcode+"'";
                            //objLog.info(strQuery);
                            stmt.executeUpdate(strQuery);
                            strQuery="update firstshiftdo set scheduled='N' where empcode='"+strStaffcode+"'";
                            //objLog.info(strQuery);
                            stmt.executeUpdate(strQuery);
                        }
                    }
                                       
                    if (request.getParameter("chkExcludePer")!=null)
                    {
                        strExcludePer="N"; //eligibility
                        //objLog.info("Exclude Permanently : "+strExcludePer);
                    }
                    
                    if (!strExcludePer.equals(strEmpElig)) //not same
                    {
                        strQuery="update dodetails set eligibility='"+strExcludePer+"' where empcode='"+strStaffcode+"'";
                        //objLog.info(strQuery);
                        stmt.executeUpdate(strQuery);
                        
                        if (strExcludePer.equals("N")) //eligibility set to N
                        {
                            //delete from anyshiftdo/firstshiftdo
                            strQuery="delete from anyshiftdo where empcode='"+strStaffcode+"'";
                            //objLog.info(strQuery);
                            stmt.executeUpdate(strQuery);
                            strQuery="delete from firstshiftdo where empcode='"+strStaffcode+"'";
                            //objLog.info(strQuery);
                            stmt.executeUpdate(strQuery);
                        }
                        else //eligibility set to Y
                        { //add to anyshiftdo/firstshiftdo
                            
                            if (strEmpShift.equals("FIRST"))
                            {
                                strQuery="insert into firstshiftdo values('"+strStaffcode+"','','','0000-00-00','N')";
                                //objLog.info(strQuery);
                                stmt.executeUpdate(strQuery);
                            }
                            else
                            {
                                strQuery="insert into anyshiftdo values('"+strStaffcode+"','','','0000-00-00','N')";
                                //objLog.info(strQuery);
                                stmt.executeUpdate(strQuery);
                            }
                            
                        }
                    }
                         
                    if (strSex.equals("F"))
                    {
                        strShift="FIRST";
                    }
                    else
                    {
                    if (request.getParameter("chkFirstShift")!=null) 
                    {
                        strShift="FIRST";
                        //objLog.info("SHIFT : "+strShift);
                    }     
                    }
                    if (!strEmpShift.equals(strShift))
                    {
                        strQuery="update dodetails set shift='"+strShift+"' where empcode='"+strStaffcode+"'";
                        //objLog.info(strQuery);
                        stmt.executeUpdate(strQuery);
                        
                        if (strShift.equals("FIRST"))
                        {
                            //take details from anyshiftdo and insert into firstshiftdo. delete from anyshiftdo
                            strQuery="insert into firstshiftdo select * from anyshiftdo where empcode='"+strStaffcode+"'";
                            //objLog.info(strQuery);
                            stmt.executeUpdate(strQuery);
                            
                            strQuery="delete from anyshiftdo where empcode='"+strStaffcode+"'";
                            //objLog.info(strQuery);
                            stmt.executeUpdate(strQuery);
                        }
                        else
                        {
                             //take details from firstshiftdo and insert into anyshiftdo. delete from firstshiftdo
                            strQuery="insert into anyshiftdo select * from firstshiftdo where empcode='"+strStaffcode+"'";
                            //objLog.info(strQuery);
                            stmt.executeUpdate(strQuery);
                            
                            strQuery="delete from firstshiftdo where empcode='"+strStaffcode+"'";
                            //objLog.info(strQuery);
                            stmt.executeUpdate(strQuery);
                        }
                    }
                    
                    //append reason to remarks field
                                        
                    strRemarks="On "+d1.datedisplay(strCurdate)+":<br>Exclude DO from date "+d1.datedisplay(strExcludeFromDate)+" till date "+d1.datedisplay(strExcludeDate)+"<br>Eligibility: "+strExcludePer+"<br>Shift Allotted: "+strShift+"<br>Reason: "+strReason;
                    if (!strEmpRemarks.equals(""))
                    {
                        strRemarks=strRemarks+"<br><br>";
                    }
                    //objLog.info(strRemarks);
                    strRemarks=strRemarks+strEmpRemarks;
                    
                    stmt.executeUpdate("update dodetails set remarks='"+strRemarks+"' where empcode='"+strStaffcode+"' ");
                    
                    view = request.getRequestDispatcher("exemptedDO.jsp");
                     view.forward(request, response);
                }
            }
        }
catch(Exception e)
{
    //objLog.error("ERROR : "+e);
    view = request.getRequestDispatcher("Failure.jsp");
    view.forward(request, response);
}
finally
{
    db.close();
}
    }
}
