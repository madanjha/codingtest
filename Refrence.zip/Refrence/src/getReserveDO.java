// Function : get role details from role table
// Author   : Gadha PS, Anju Varghese
// Division : COM/CIG
// Date     : 28/01/2009

import java.io.*;
import java.util.*;
import java.util.Date;
import java.text.*;
import java.lang.String;
import java.sql.*;
import java.net.*;
import javax.servlet.*;
import javax.servlet.http.*;
import org.apache.log4j.Logger;
import dateform.*;

public class getReserveDO extends HttpServlet {

    protected void doGet(HttpServletRequest request, HttpServletResponse response)
    throws ServletException, IOException {
        doPost(request,response);
    }

    protected void doPost(HttpServletRequest request, HttpServletResponse response)
    throws ServletException, IOException {

        RequestDispatcher view = null;
        PrintWriter out= response.getWriter();
        dbConn db=new dbConn();
        dateformat d1=new dateformat();
       // Logger //objLog = Logger.getLogger("ApplicationDO");

        try
{
            Connection conn= null;
            conn = db.Connect();
            Statement stmt = conn.createStatement();
            ResultSet rs1=null;
            ArrayList arrDODetails= new ArrayList();
            ArrayList arrObservations= new ArrayList();
            String strFlag="invalidSession", strStaffcode="", strQuery="", strFlagDO="false", strFlagReserve="false",strFlagDutydone="false";
            String strScheduleDate="",strShift="";
            int dutydone=0;
            // Get session
            HttpSession curSession=request.getSession(false);
            // Check if valid session
            if(curSession==null)
	{
                //objLog.error("Invalid session");
                request.setAttribute("flag",strFlag);
                view=request.getRequestDispatcher("sessionError.jsp");
                view.forward(request, response);
            }

            else //valid session
            {
                if((String)curSession.getAttribute("userid")==null)
	{
                    //objLog.error("Invalid session");
                    request.setAttribute("flag",strFlag);
                    view=request.getRequestDispatcher("sessionError.jsp");
                    view.forward(request, response);
                }
                else
                {
                    strStaffcode=request.getParameter("txtStaffcode");
                    strScheduleDate=request.getParameter("txtDutydate");
                    strScheduleDate=d1.savedate(strScheduleDate);
                    strShift=request.getParameter("cboShift");
                    //objLog.info("Staffcode of logged in officer: "+strStaffcode);
                    
                    //check if scno in doschedule or reservedutydone tables
                    
                    strQuery="select * from doschedule where empcode='"+strStaffcode+"' and scheduledate='"+strScheduleDate+"' and shift='"+strShift+"' ";
                    rs1=stmt.executeQuery(strQuery);
                    if (rs1.next())
                    {      
                        strFlagDutydone="true";//he is scheduled to do duty on that date and shift so please do mark attendance option
                    } 
                    rs1.close();    
                    
                    strQuery="select * from reservedutydone where empcode='"+strStaffcode+"' and dutydate='"+strScheduleDate+"' and shift='"+strShift+"' ";
                    rs1=stmt.executeQuery(strQuery);
                    if (rs1.next())
                    {      
                        strFlagDutydone="true";//his details present in reservedutydone table for that date and shift
                    } 
                    rs1.close();
                    
                    strQuery="select count(*) from doschedule where scheduledate='"+strScheduleDate+"' and shift='"+strShift+"' and logindatetime<>'0000-00-00 00:00:00'";
                    rs1=stmt.executeQuery(strQuery);
                    if (rs1.next())
                    {     
                        dutydone=rs1.getInt(1);
                    } 
                    rs1.close();
                     strQuery="select count(*) from reservedutydone where dutydate='"+strScheduleDate+"' and shift='"+strShift+"'";
                    rs1=stmt.executeQuery(strQuery);
                    if (rs1.next())
                    {     
                        dutydone = dutydone + rs1.getInt(1);
                    } 
                    rs1.close();
                    if(dutydone==2)
                    {
                         strFlagDutydone="over";//he has already recorded his duty
                    }
                    
                    if (strFlagDutydone.equals("true") || strFlagDutydone.equals("over"))
                    {                         
                        request.setAttribute("flagDutydone",strFlagDutydone);
                        view=request.getRequestDispatcher("reserveDutydone.jsp");
                        view.forward(request, response);
                    }
                    else
                    {
                                            
                        strQuery="select empname,division,designation,sex,sittingphone from dodetails ,doaddress where doaddress.empcode=dodetails.empcode and dodetails.empcode='"+strStaffcode+"'";
                        //objLog.info(strQuery);
                        rs1=stmt.executeQuery(strQuery);
                        if (rs1.next())
                        {
                          arrDODetails.add(rs1.getString(1));  ////objLog.info(rs1.getString(2));
                          arrDODetails.add(rs1.getString(2));   //   //objLog.info(rs1.getString(3));
                           arrDODetails.add(rs1.getString(3));  ////objLog.info(rs1.getString(4));
                           arrDODetails.add(rs1.getString(4));  //   //objLog.info(rs1.getString(5));
                           arrDODetails.add(rs1.getString(5));
                           strFlagDO="true";
                            //objLog.info(" DO in dodetails");
                        }
                        rs1.close();
                             //objLog.info(strFlagDO);
                        if (strFlagDO.equals("false"))
                        {       //objLog.info(" DO in reserve");
                            strQuery="select * from reservelist where empcode='"+strStaffcode+"' ";
                            rs1=stmt.executeQuery(strQuery);
                            if (rs1.next())
                            {
                                arrDODetails.add(rs1.getString(2)); ////objLog.info(rs1.getString(2));
                         	   arrDODetails.add(rs1.getString(3));     // //objLog.info(rs1.getString(3));
                                arrDODetails.add(rs1.getString(4));  ////objLog.info(rs1.getString(4));
                                arrDODetails.add(rs1.getString(5));    // //objLog.info(rs1.getString(5));
                               arrDODetails.add(rs1.getString(6));    // //objLog.info(rs1.getString(6));
                                strFlagReserve="true";
                            }
    		 rs1.close();
		}                        
                   
                     
 		   request.setAttribute("arrDODetails",arrDODetails);
		// request.setAttribute("flagDO",strFlagDO);
		// request.setAttribute("flagReserve",strFlagReserve);
		 request.setAttribute("flagLoad","edit");
                request.setAttribute("shift",strShift);
                request.setAttribute("dutydate",d1.datedisplay(strScheduleDate));
                request.setAttribute("staffcode",strStaffcode);
                 
                view=request.getRequestDispatcher("markReserveDO.jsp");
                view.forward(request, response);
                    }
                        }

}
}

catch(Exception e)
{
    //objLog.error("ERROR : "+e);
    view = request.getRequestDispatcher("Failure.jsp");
    view.forward(request, response);
}
finally
{
    db.close();
}
    }
}
