/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
// Function : get new user details from sysuser table
// Author   : Gadha PS, Anju Varghese
// Division : COM/CIG
// Date     : 28/01/2009

import java.io.*;
import java.util.*;
import java.util.Date;
import java.text.*;
import java.lang.String;
import java.sql.*;
import java.net.*;
import javax.servlet.*;
import javax.servlet.http.*;
import org.apache.log4j.Logger;
import dateform.*;

public class saveWIC extends HttpServlet {

    protected void doGet(HttpServletRequest request, HttpServletResponse response)
    throws ServletException, IOException {
        doPost(request,response);
    }

    protected void doPost(HttpServletRequest request, HttpServletResponse response)
    throws ServletException, IOException {

        RequestDispatcher view = null;
        PrintWriter out= response.getWriter();
        dbConn db=new dbConn();

     //   Logger //objLog = Logger.getLogger("ApplicationDO");
        String strQuery="",strScheduledate="",strScheduleFromdate="",strScheduleTodate="",strScheduleFromdateNew="",strScheduleTodateNew="";
        String strEmpcodeNew="";
        try
{
            Connection conn= null;
            conn = db.Connect();
	  dateformat d1=new dateformat();

            Statement stmt = conn.createStatement();
           Statement stmt2 = conn.createStatement();
              Statement stmt3 = conn.createStatement();
            ResultSet rs1=null,rs2=null;
            String strFlag="invalidSession",strEmpcode="";
            //ArrayList arrWIC=new ArrayList();

            // Get session
            HttpSession curSession=request.getSession(false);
            // Check if valid session
            if(curSession==null)
            {
                //objLog.error("Invalid session");
                request.setAttribute("flag",strFlag);
                view=request.getRequestDispatcher("sessionError.jsp");
                view.forward(request, response);
            }

            else //valid session
            {
           strScheduledate=request.getParameter("scheduledate");
           strEmpcodeNew=request.getParameter("cbowicname");
       
           strQuery="select * from wicdetails where schedulefromdate='"+d1.savedate(strScheduledate)+"'";
           //objLog.info(strQuery);
           rs1=stmt.executeQuery(strQuery);
             if(rs1.next())
             {
               strEmpcode=rs1.getString(1);
               strScheduleFromdate=rs1.getString(2);
               strScheduleTodate=rs1.getString(3);
             }
           rs1.close();

           //objLog.info(strEmpcode+strScheduleFromdate+strScheduleTodate);

          /*  strQuery="select * from wicdetails where empcode='"+strEmpcodeNew+"'";
           //objLog.info(strQuery);
            rs1=stmt.executeQuery(strQuery);
            if(rs1.next())
            {
              strScheduleFromdateNew=rs1.getString(2);
               strScheduleTodateNew=rs1.getString(3);
            }
           rs1.close();*/

       /*    strQuery="update wicdetails set schedulefromdate='"+strScheduleFromdate+"', scheduletodate='"+ strScheduleTodate+"' where empcode='"+strEmpcodeNew+"' and schedulefromdate='"+strScheduleFromdateNew+"'";
           //objLog.info(strQuery);
           stmt.executeUpdate(strQuery);

            strQuery="update wicdetails set schedulefromdate='"+strScheduleFromdateNew+"',scheduletodate='"+ strScheduleTodateNew+"' where empcode='"+strEmpcode+"' and schedulefromdate='"+strScheduleFromdate+"'";
            //objLog.info(strQuery);
            stmt.executeUpdate(strQuery);*/

		strQuery="insert into wicdetails values('"+strEmpcodeNew+"','"+strScheduleFromdate+"','"+ strScheduleTodate+"' )";
                //objLog.info(strQuery);
            stmt.executeUpdate(strQuery);


strQuery="delete from wicdetails where empcode='"+strEmpcode+"' and schedulefromdate='"+strScheduleFromdate+"'";
                //objLog.info(strQuery);
            stmt.executeUpdate(strQuery);



            view=request.getRequestDispatcher("getAllWIC.do");
            view.forward(request, response);
            }
        }
catch(Exception e)
{
    //objLog.error("ERROR : "+e);
    view = request.getRequestDispatcher("Failure.jsp");
    view.forward(request, response);
}
finally
{
    db.close();
}
}
}
