// Function : get role details from role table
// Author   : Gadha PS, Anju Varghese
// Division : COM/CIG
// Date     : 28/01/2009

import java.io.*;
import java.util.*;
import java.util.Date;
import java.text.*;
import java.lang.String;
import java.sql.*;
import java.net.*;
import javax.servlet.*;
import javax.servlet.http.*;
import org.apache.log4j.Logger;

public class getNewHolidayYear extends HttpServlet {
    
    protected void doGet(HttpServletRequest request, HttpServletResponse response)
    throws ServletException, IOException {
        doPost(request,response);
    }
    
    protected void doPost(HttpServletRequest request, HttpServletResponse response)
    throws ServletException, IOException {
        
        RequestDispatcher view = null;
        PrintWriter out= response.getWriter();
        dbConn db=new dbConn();
      //  Logger //objLog = Logger.getLogger("ApplicationDO");
        try
{
            Connection conn= null;
            conn = db.Connect();
            Statement stmt = conn.createStatement();
            ResultSet rs1=null;
            String strFlag="invalidSession", strQuery="", strYear="", strFlag1="true";
            int maxyear=0, curyear=0, dispyear=0;
            
            // Get session
            HttpSession curSession=request.getSession(false);
            // Check if valid session
            if(curSession==null)
{
                //objLog.error("Invalid session");
                request.setAttribute("flag",strFlag);
                view=request.getRequestDispatcher("sessionError.jsp");
                view.forward(request, response);
            }
            
            else //valid session
            {
                if((String)curSession.getAttribute("userid")==null)
{
                    //objLog.error("Invalid session");
                    request.setAttribute("flag",strFlag);
                    view=request.getRequestDispatcher("sessionError.jsp");
                    view.forward(request, response);
                }
                else
                {
                    //check if holidays created for any year in table. If not, show page to enter holidays for current year
                    //If holidays already present for current year & not for next year, display 'generate list' page to generate holidays from existing one
                    //If holidays already created for current & next years, show page form editing next year holidays(ie last created)
                   
                    strQuery = "select year(max(holidaydate)) as maxyear from holiday";
                    rs1 = stmt.executeQuery(strQuery);
                    if (rs1.next())
                    {
                        maxyear = rs1.getInt("maxyear");      
                        //objLog.info("Max Year: "+maxyear);
                    }                                           
                    rs1.close();
                    
                    strQuery="select year(curdate())";
                    rs1 = stmt.executeQuery(strQuery);
                    if (rs1.next())
                    {
                        curyear = rs1.getInt(1);      
                        //objLog.info("Current Year: "+curyear);
                    }
                 
                    rs1.close();
                    
                    if (maxyear==0)
                    {
                       // //objLog.info("here");
                        dispyear=curyear;
                        strFlag1="false";
                    }
                    else
                    {
                        if (maxyear <= curyear)
                        {
                            dispyear = maxyear+1;
                            strFlag1="true";
                        }
                        else
                        {
                            dispyear = maxyear;
                            strFlag1="false";
                        }
                    }
                    
                    strYear=new Integer(dispyear).toString();     
                    //objLog.info("Display Year: "+strYear);
                }
                
                request.setAttribute("strYear",strYear);
              //  request.setAttribute("strFlag",strFlag1);
                
                if (strFlag1.equals("true"))
                {
                    view = request.getRequestDispatcher("createHolidayList.jsp");
                }
                else
                {
                    view = request.getRequestDispatcher("getHoliday.do?link=new");
                }
                view.forward(request, response);
            }
        }
catch(Exception e)
{
    //objLog.error("ERROR : "+e);
    view = request.getRequestDispatcher("Failure.jsp");
    view.forward(request, response);
}
finally
{
    db.close();
}
    }
}
