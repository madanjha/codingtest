// Function : get role details from role table
// Author   : Gadha PS, Anju Varghese
// Division : COM/CIG
// Date     : 28/01/2009

import java.io.*;
import java.util.*;
import java.util.Date;
import java.text.*;
import java.lang.String;
import java.sql.*;
import java.net.*;
import javax.servlet.*;
import javax.servlet.http.*;
import org.apache.log4j.Logger;
import dateform.*;

public class getExcludeStaffcode extends HttpServlet {
    
    protected void doGet(HttpServletRequest request, HttpServletResponse response)
    throws ServletException, IOException {
        doPost(request,response);
    }
    
    protected void doPost(HttpServletRequest request, HttpServletResponse response)
    throws ServletException, IOException {
        
        RequestDispatcher view = null;
        PrintWriter out= response.getWriter();
        dbConn db=new dbConn();
        dateformat d1=new dateformat();
      //  Logger //objLog = Logger.getLogger("ApplicationDO");
        try
{
            Connection conn= null;
            conn = db.Connect();
            Statement stmt = conn.createStatement();
            ResultSet rs1=null;
            String strFlag="invalidSession", strCurDate="", strSex="", strDivision="", strShiftType="", dayofweek="",txtExStaffcode="", strShiftPer="", strEligPer="";
            String strShift="",strDutydate="",strName="",strQuery="",strStartdate="",strEnddate="", strStaffcode="",strDutydate1="", strLink="";
            ArrayList arEmpcode=new ArrayList(); //empcode of same shift officers
            int holFlag=0;
            
            String strExName="",strExStaffcode="",strExDutydate="",strExShift="",strExSex="",strType="Load", strExDivision="", strExDesgn="", strSel="combo",strTextEmpElig="true", strSecElig="true";
            
            // Get session
            HttpSession curSession=request.getSession(false);
            // Check if valid session
            if(curSession==null)
{
                //objLog.error("Invalid session");
                request.setAttribute("flag",strFlag);
                view=request.getRequestDispatcher("sessionError.jsp");
                view.forward(request, response);
            }
            
            else //valid session
            {
                if((String)curSession.getAttribute("userid")==null)
                {
                    //objLog.error("Invalid session");
                    request.setAttribute("flag",strFlag);
                    view=request.getRequestDispatcher("sessionError.jsp");
                    view.forward(request, response);
                }
                 else
                {
                    strStaffcode=request.getParameter("strStaffcode");
                    strShift=request.getParameter("newShift");
                    strDutydate=request.getParameter("newDate");
                    strDutydate1=d1.savedate(strDutydate);
                    strName=request.getParameter("strName");
                    strSex=request.getParameter("strSex");
                    strDivision=request.getParameter("strDivision");
                    strStartdate=request.getParameter("strStartDate");
                    strStartdate=d1.savedate(strStartdate);
                    strEnddate=request.getParameter("strEndDate");
                    strEnddate=d1.savedate(strEnddate);
                       
                    //get selected staffcode from textbox
                    txtExStaffcode=request.getParameter("txtStaffcode");
                    //get selected staffcode from combo
                     strExStaffcode= request.getParameter("cboStaffcode");
                     
                     //objLog.info("cbo staff code "+strExStaffcode);                  
                      //objLog.info("txt staff code "+txtExStaffcode);
                      
                       strLink=request.getParameter("link");
                     //objLog.info("Link: "+strLink);
                     
                     if(txtExStaffcode!=null)
                     {
                        strExStaffcode=txtExStaffcode;
                        strExStaffcode=strExStaffcode.toUpperCase();
                       // strQuery="select * from doschedule where scheduledate>=curdate() and empcode='"+strExStaffcode+"'";
                        
                        //check if he can be allotted to second shift
                        strQuery="select shift, eligibility from dodetails where empcode='"+strExStaffcode+"'";
                        rs1=stmt.executeQuery(strQuery);
                        if(rs1.next())
                        {
                            strShiftPer=rs1.getString(1);
                            strEligPer =rs1.getString(2);
                        }
                        rs1.close();
                        
                        if (strShift.equals("SECOND") && strShiftPer.equals("FIRST"))
                        {
                            strSecElig="false";
                        }
                        
                        //check if he is in coming schedule
                        strQuery="select * from anyshiftdo where scheduled='Y' and empcode='"+strExStaffcode+"'";
                        //objLog.info(strQuery);
                        rs1=stmt.executeQuery(strQuery);
                        if(rs1.next())
                        {
                            strTextEmpElig="false";
                        }
                        rs1.close();
                        
                        strQuery="select * from firstshiftdo where scheduled='Y' and empcode='"+strExStaffcode+"'";
                        //objLog.info(strQuery);
                        rs1=stmt.executeQuery(strQuery);
                        if(rs1.next())
                        {
                            strTextEmpElig="false";
                        }
                        rs1.close();
                        strSel="text";
                     }
                     
                     //update schedule status=Y if current date is between excludefromdate and  excludetilldate
                          stmt.executeUpdate("update firstshiftdo set scheduled='Y' where empcode in (select empcode from dodetails where curdate() between excludefromdate and excludetilldate)");
                        stmt.executeUpdate("update anyshiftdo set scheduled='Y' where empcode in (select empcode from dodetails where curdate() between excludefromdate and excludetilldate)");  
                            
                                           
                      //objLog.info("Selection: "+strSel);
                      
                     //get shift from dodetails
                     strQuery="select shift from dodetails where empcode='"+strStaffcode+"'";
                     rs1=stmt.executeQuery(strQuery);
                     if (rs1.first())
                     {
                         strShiftType=rs1.getString(1);
                     }
                     
                     //if sex=F show only staffcodes in first shift, omit holidays
                     strSex=strSex.trim();
                     strShift=strShift.trim();
                  /*   if (strSex.equals("F"))
                     {
                         strQuery="select distinct empcode from doschedule,holiday where !(scheduledate='"+strDutydate1+"' and shift='"+strShift+"') and scheduledate between'"+strStartdate+"' and '"+strEnddate+"' and ";
                         strQuery=strQuery+"dayofweek(scheduledate)<>1 and dayofweek(scheduledate)<>7 and scheduledate not in (select holidaydate from holiday) and shift='FIRST' and scheduledate >= curdate() order by empcode";
                     }
                     else if (strSex.equals("M") && strShiftType.equals("FIRST")) //show only staffcodes in first shift
                     {
                         strQuery="select empcode from doschedule where !(scheduledate='"+strDutydate1+"' and shift='"+strShift+"') and scheduledate between'"+strStartdate+"' and '"+strEnddate+"' and shift='FIRST' and scheduledate >= curdate() order by empcode";
                     }
                     else if (strShift.equals("SECOND"))
                     {                       
                         //if shift='SECOND' show only staffcodes where sex='M' and shift='ANY' in dodetails
                         strQuery="select a.empcode from doschedule a, dodetails b where !(scheduledate='"+strDutydate1+"' and a.shift='"+strShift+"') and scheduledate between'"+strStartdate+"' and '"+strEnddate+"' and a.empcode=b.empcode and sex='M' and b.shift='ANY' and scheduledate >= curdate() order by empcode";
                     }
                     else
                     {
                         strQuery="select empcode from doschedule where !(scheduledate='"+strDutydate1+"' and shift='"+strShift+"') and  scheduledate between'"+strStartdate+"' and '"+strEnddate+"' and scheduledate >= curdate() order by empcode";   
                     }          */
                     
                     //check if holiday
                     strQuery = "select dayofweek('"+strDutydate1+"')";
                     rs1=stmt.executeQuery(strQuery);
                     if (rs1.next())
                     {
                         dayofweek=rs1.getString(1);
                     }
                     rs1.close();
                     
                     if (dayofweek.equals("1") || dayofweek.equals("7"))
                     {
                         holFlag=1;
                     }
                     
                     strQuery="select * from holiday where holidaydate='"+strDutydate1+"'";
                     rs1=stmt.executeQuery(strQuery);
                     if (rs1.first())
                     {
                         holFlag=1;
                     }
                     rs1.close();
                     
                    //if shift='SECOND' or holiday date, take from anyshiftdo limit by 6                   
                     if (strShift.equals("SECOND") ||  holFlag==1)
                     {
                         strQuery="select distinct empcode from anyshiftdo where scheduled='N' and prevshift1<>'SECOND' and empcode not in (select empcode from doschedule where scheduleno in (select max(scheduleno) from doschedule where empcode='"+strStaffcode+"')) order by prevdutydate asc limit 10";
                         rs1=stmt.executeQuery(strQuery);
                         //objLog.info(strQuery);
                          while (rs1.next()) 
                        {                           
                               arEmpcode.add(rs1.getString(1));                               
                        }
                        rs1.close();
                     }
                     else
                     {
                         if (strShift.equals("FIRST")) //take 5 from firstshiftdo and 5 from anyshiftdo
                         {
                             strQuery = "select distinct empcode from anyshiftdo where scheduled='N' and prevshift1<>'FIRST' and empcode not in (select empcode from doschedule where scheduleno in (select max(scheduleno) from doschedule where empcode='"+strStaffcode+"')) order by prevdutydate asc ,empcode limit 5";
                             rs1=stmt.executeQuery(strQuery);
                             //objLog.info(strQuery);
                              while (rs1.next()) 
                            {                           
                                   arEmpcode.add(rs1.getString(1));                                
                            }
                            rs1.close();
                            
                            strQuery = "select distinct empcode from firstshiftdo where scheduled='N' and empcode not in (select empcode from doschedule where scheduleno in (select max(scheduleno) from doschedule where empcode='"+strStaffcode+"')) order by prevdutydate asc ,empcode limit 5";
                             rs1=stmt.executeQuery(strQuery);
                             //objLog.info(strQuery);
                              while (rs1.next()) 
                            {                           
                                   arEmpcode.add(rs1.getString(1));                               
                            }
                            rs1.close();
                          }                         
                     }                   
                  
                   
                    
                    if (strExStaffcode != null)
                    {
                        //check if staffcode="select"
                        if (strExStaffcode.equals("Select")) //reset values
                        { //objLog.info(strExStaffcode+"--");
                            strExName="";
                            strExDutydate="";
                            strExShift="";
                            strExSex="";
                            strExDivision="";
                        }
                        else
                        {
                           strQuery = "SELECT empname,sex,division,designation FROM dodetails where empcode='"+strExStaffcode+"'";
                            rs1=stmt.executeQuery(strQuery);
                            //objLog.info("strQuery inside exchaage details java "+strQuery);
                            while (rs1.next())
                            {                               
                                strExName = rs1.getString(1);
                               strExSex = rs1.getString(2);
                               strExDivision = rs1.getString(3);
                               strExDesgn=rs1.getString(4);
                            }
                            rs1.close();

                        } 
                        strType="Edit";
                        
                    }
                    
                    //get current date
                    
                  /*  strQuery = "select curdate()";
                    rs1=stmt.executeQuery(strQuery);
                    if (rs1.next())
                    {
                        strCurDate=rs1.getString(1);
                    }
                    rs1.close();*/
                    
                    strStartdate = d1.datedisplay(strStartdate);                    
                    strEnddate = d1.datedisplay(strEnddate);
                    
                    //objLog.info("Staffcode: "+strExStaffcode);
                    //objLog.info("strTextEmpElig: "+strTextEmpElig);
                    
                    request.setAttribute("StartDate",strStartdate);
                    request.setAttribute("EndDate",strEnddate);
                    request.setAttribute("Shift",strShift);
                    request.setAttribute("Name",strName);
                    request.setAttribute("Sex",strSex);
                    request.setAttribute("Division",strDivision);
                    request.setAttribute("Staffcode",strStaffcode);
                    request.setAttribute("Dutydate",strDutydate);
                    request.setAttribute("arEmpcode", arEmpcode);
                 //   request.setAttribute("Curdate", strCurDate);                    
                    
                     request.setAttribute("ExStaffcode",strExStaffcode); 
                    request.setAttribute("ExName",strExName);  
                    request.setAttribute("ExSex",strExSex);        
                    request.setAttribute("ExDivision",strExDivision);                    
                    request.setAttribute("ExDesgn",strExDesgn);
                    request.setAttribute("Flag",strType);
                    request.setAttribute("Sel",strSel);
                     request.setAttribute("link",strLink);
                   request.setAttribute("strTextEmpElig",strTextEmpElig);   
                   request.setAttribute("strEligPer",strEligPer);   
                   request.setAttribute("strSecElig",strSecElig);   
                    view = request.getRequestDispatcher("excludeDO.jsp");                
                    view.forward(request, response);
                   
                 }
            }
        }
catch(Exception e)
{
    //objLog.error("ERROR : "+e);
    view = request.getRequestDispatcher("Failure.jsp");
    view.forward(request, response);
}
finally
{
    db.close();
}
    }
}
