// Function : add new holiday
// Author   : Gadha PS, Anju Varghese
// Division : COM/CIG
// Date     : 28/01/2009

import java.io.*;
import java.util.*;
import java.util.Date;
import java.text.*;
import java.lang.String;
import java.sql.*;
import java.net.*;
import javax.servlet.*;
import javax.servlet.http.*;
import org.apache.log4j.Logger;
import dateform.*;

public class saveHoliday extends HttpServlet {
    
    protected void doGet(HttpServletRequest request, HttpServletResponse response)
    throws ServletException, IOException {
        doPost(request,response);
    }
    
    protected void doPost(HttpServletRequest request, HttpServletResponse response)
    throws ServletException, IOException {
        
        RequestDispatcher view = null;
        PrintWriter out= response.getWriter();
        dbConn db=new dbConn();
        dateformat d1=new dateformat();
       // Logger //objLog = Logger.getLogger("ApplicationDO");
        try
{
            Connection conn= null;
            conn = db.Connect();
            Statement stmt = conn.createStatement();
            ResultSet rs1=null;
            String strFlag="invalidSession";
            String strDate="", strHoliday="", strYear="", strQuery="";
            int maxid=0;
            
            // Get session
            HttpSession curSession=request.getSession(false);
            // Check if valid session
            if(curSession==null)
{
                //objLog.error("Invalid session");
                request.setAttribute("flag",strFlag);
                view=request.getRequestDispatcher("sessionError.jsp");
                view.forward(request, response);
            }
            
            else //valid session
            {
                if((String)curSession.getAttribute("userid")==null)
{
                    //objLog.error("Invalid session");
                    request.setAttribute("flag",strFlag);
                    view=request.getRequestDispatcher("sessionError.jsp");
                    view.forward(request, response);
                }
            else
            {
                strDate = request.getParameter("txtDate");
                strDate = d1.savedate(strDate);
                strHoliday = request.getParameter("txtHoliday");
                strYear = request.getParameter("strYear");
                //objLog.info("Year in save: "+strYear);
                
                strQuery = "select * from holiday where holidaydate = '"+strDate+"'";
                rs1 = stmt.executeQuery(strQuery);
                if (rs1.next())
                {
                    view=request.getRequestDispatcher("duplicateError.jsp");
                    view.forward(request, response);
                }
                else
                {                   
                   
                    strQuery = "select max(holiday_id) as maxcode from holiday";
                    rs1 = stmt.executeQuery(strQuery);
                    if (rs1.next())
                    {
                        maxid = rs1.getInt("maxcode");     
                        maxid = maxid+1;
                    }
                    else
                    {
                        maxid = 1;
                    }
                    rs1.close();
                    
                    strQuery = "insert into holiday values('"+maxid+"', '"+strHoliday+"', '"+strDate+"')";
                    int success = stmt.executeUpdate(strQuery);
                    
                     request.setAttribute("strYear", strYear);
                    view=request.getRequestDispatcher("getHoliday.do?link=new");
                    view.forward(request, response);
                    
                }
            }
            }
        }
catch(Exception e)
{
    //objLog.error("ERROR : "+e);
    view = request.getRequestDispatcher("Failure.jsp");
    view.forward(request, response);
}
finally
{
    db.close();
}
    }
}
