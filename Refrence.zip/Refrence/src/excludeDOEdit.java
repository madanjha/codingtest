// Function : get role details from role table
// Author   : Gadha PS, Anju Varghese
// Division : COM/CIG
// Date     : 28/01/2009

import java.io.*;
import java.util.*;
import java.util.Date;
import java.text.*;
import java.lang.String;
import java.sql.*;
import java.net.*;
import javax.servlet.*;
import javax.servlet.http.*;
import org.apache.log4j.Logger;
import dateform.*;


import java.util.Properties;
import javax.mail.Authenticator;
import javax.mail.Message;
import javax.mail.PasswordAuthentication;
import javax.mail.Session;
import javax.mail.Transport;
import javax.mail.internet.InternetAddress;
import javax.mail.internet.MimeMessage;
import java.io.*;
public class excludeDOEdit extends HttpServlet {
    
    protected void doGet(HttpServletRequest request, HttpServletResponse response)
    throws ServletException, IOException {
        doPost(request,response);
    }
    
     class ThePasswordAuthenticator extends Authenticator {
		String user;
		String pw;
		public ThePasswordAuthenticator(String username, String password) {
			super();
			this.user = username;
			this.pw = password;
		}
		public PasswordAuthentication getPasswordAuthentication() {
			return new PasswordAuthentication(user, pw);
		}
    }
    protected void doPost(HttpServletRequest request, HttpServletResponse response)
    throws ServletException, IOException {
        
        RequestDispatcher view = null;
        PrintWriter out= response.getWriter();
        dbConn db=new dbConn();
        dateformat d1=new dateformat();
      //  Logger //objLog = Logger.getLogger("ApplicationDO");
        try
{
            Connection conn= null;
            conn = db.Connect();
            Statement stmt = conn.createStatement();
            ResultSet rs1=null;
            String strFlag="invalidSession";
            ArrayList arSchedule=new ArrayList(); //schedule
            String strShift="",strDutydate="", strQuery="", strStaffcode="", strStartDate="", strEndDate="",strMail="", strExMail="";                  
            String strExStaffcode="",strExSex="", strPath="",strStartDate1="", strEndDate1="", txtExStaffcode="", mailPath="";
            
            // Get session
            HttpSession curSession=request.getSession(false);
            // Check if valid session
            if(curSession==null)
{
                //objLog.error("Invalid session");
                request.setAttribute("flag",strFlag);
                view=request.getRequestDispatcher("sessionError.jsp");
                view.forward(request, response);
            }
            
            else //valid session
            {
                if((String)curSession.getAttribute("userid")==null)
                {
                    //objLog.error("Invalid session");
                    request.setAttribute("flag",strFlag);
                    view=request.getRequestDispatcher("sessionError.jsp");
                    view.forward(request, response);
                }
                else
                {
                    strPath= request.getParameter("path");
                    //objLog.info("Path: "+strPath);
                    
                    strStartDate1=request.getParameter("strStartDate");
                    strStartDate=d1.savedate(strStartDate1);
                    strEndDate1=request.getParameter("strEndDate");  
                    strEndDate=d1.savedate(strEndDate1);
                    
                    if (strPath.equals("exclude"))
                    {
                    
                    strStaffcode=request.getParameter("strStaffcode");
                    strShift=request.getParameter("newShift");
                    strDutydate=request.getParameter("newDate");  
                    strDutydate=d1.savedate(strDutydate);
                   
                    strExStaffcode=request.getParameter("cboStaffcode");
                    strExSex=request.getParameter("txtSex");             
                     
                    //get selected staffcode from textbox
                    txtExStaffcode=request.getParameter("txtStaffcode");
                    
                    if(txtExStaffcode!=null)
                     {
                        strExStaffcode=txtExStaffcode;     
                        strExStaffcode=strExStaffcode.toUpperCase();
                     }
                    //objLog.info("Staffcode: "+strExStaffcode);
                    
                   //check if female is allotted to second shift
                    
                    if (strShift.equals("SECOND") && (strExSex.equals("F")))
                    {
                        view = request.getRequestDispatcher("errorLadyInSecond.jsp");                
                        view.forward(request, response);
                    }
                    else
                    {
                        strQuery = "update doschedule set empcode='"+strExStaffcode+"', confirm='N' where scheduledate='"+strDutydate+"' and empcode='"+strStaffcode+"' ";
                        stmt.executeUpdate(strQuery);
                        //objLog.info(strQuery);
                        
                        //set scheduled=Y for newly allotted officer
                        stmt.executeUpdate("update firstshiftdo set scheduled='Y' where empcode='"+strExStaffcode+"'");
                        stmt.executeUpdate("update anyshiftdo set scheduled='Y' where empcode='"+strExStaffcode+"'");
                        
                         //set scheduled=N for excluded officer
                        stmt.executeUpdate("update firstshiftdo set scheduled='N' where empcode='"+strStaffcode+"'");
                        stmt.executeUpdate("update anyshiftdo set scheduled='N' where empcode='"+strStaffcode+"'");
                        
                        //reset exchange flag to 0
                    
                    stmt.executeUpdate("update exchangedo set exchangeflag ='0' where empcode1='"+strStaffcode+"' or empcode2='"+strStaffcode+"'");
                    
                    strQuery="select email from empemail where scno='"+strStaffcode+"'";
                    rs1=stmt.executeQuery(strQuery);
                    if (rs1.next())
                    {
                        strMail=rs1.getString(1);
                    }
                    else
                    {
                        strMail="NO_EMAIL";
                    }
                    rs1.close();

                    strQuery="select email from empemail where scno='"+strExStaffcode+"'";
                    rs1=stmt.executeQuery(strQuery);
                    if (rs1.next())
                    {
                        strExMail=rs1.getString(1);
                    }
                    else
                    {
                        strExMail="NO_EMAIL";
                    }
                    rs1.close();
                                      
                   
                    //send mail to both
                    strDutydate=d1.datedisplay(strDutydate);
                    //mailPath="http://10.41.6.137:8080/VDOS/aox.do?emailid1="+strExMail+"&dutydate="+strDutydate+"&shift="+strShift+"&emailid2="+strMail;
                    
                    /* NEW CODE strStartDate */
                    ///////////////// START /////////////////////////////
                    //////////////////To allotted Officer///////////////////////////
                    ///////////////////////////////////////////////////////////////
                  
                         String mailer = "myprogram";
			//comma separated list of recipients.
			//String to = "shiny@lpscv.dos.gov.in";
			String cc = null;
			String bcc = null;
			String from = "doadmin@lpscv.dos.gov.in";
			String subject = "(TESTING---Please Ignore this mail)LPSC Duty Officer System � Intimation of duty \r\n";
                        String subject1= "(TESTING---Please Ignore this mail) LPSC Duty Officer System � Exemption from duty (Testing---Please Ignore this mail)\r\n";
			String body =   "Sir/Madam\r\n"+
                                        " (TESTING---PLEASE IGNORE THIS MAIL ) Duty Officer(DO) System started functioning in LPSC from 09-02-2010 onwards, \r\n"+
                                        "having two shifts on round-the-clock basis, FIRST shift from 0700 hrs to 1900 hrs and SECOND shift from 1900 hrs to 0700 hrs\r\n"+
                                        "You are requested to perform DO duty on the date and shift mentioned below:";       
                        
                          
                         body=body + "Schedule date:\r\n"+ strDutydate;           
                         body=body + "Shift:"+ strShift+"\n"+
                                     "To access LPSC Duty officer System(LDOS) click on the link below:"+ 
                                     //"http://10.101.2.153:8080/LPSCDOS/login.jsp \n"+
                                     " http://X/LPSCDOS/login.jsp \n"+
                                     "In case of unavoidable excuses, please ensure exchange of duty with other officers listed in the roster. Please login to the above system to confirm/exchange your duty.\n"+
                                     "Regards \n"+
                                     "System Administrator \n"+
                                     "NOTE :- This is an auto-generated mail.Do not reply to this mail";
                        
                      
                        
                        String smtpserver = "lpscv.dos.gov.in";
			String smtpport = "25";
			//my username for smtp.att.yahoo.com was a fully
			//qualified email, like joel@att.com.
			String user = "doadmin";
			//String password = "s1s2i3";
			String password = "lpsc1234";
                        Properties props = new Properties();
			//default to "localhost"
			props.put("mail.smtp.host", smtpserver);
			//default to "25"
			props.put("mail.smtp.port", smtpport);
			//uncomment to turn on debugging output which can be useful.
			//props.put("mail.debug", "true");
			//javax.mail.Session
			
			Session session = null;
			if (user != null && password != null)
                        {
                                    props.put("mail.smtp.auth", "true");
                                    session =Session.getInstance(props,new ThePasswordAuthenticator(user,password));
			}
                    
                         Message msg = new MimeMessage(session);
                         try
                         {
		         
                             
                              //body=body + "Schedule date: " +strExDutydate;
                              //body=body + "Shift : " +strExShift;
                              
                            msg.setFrom(new InternetAddress(from));
                                                
                            msg.setRecipients(Message.RecipientType.TO,InternetAddress.parse(strExMail, false));
                            if (cc != null)
                            msg.setRecipients(Message.RecipientType.CC,InternetAddress.parse(cc, false));
                            if (bcc != null)
                            msg.setRecipients(Message.RecipientType.BCC,InternetAddress.parse(bcc, false));
                            //subject line.
                            msg.setSubject(subject);
                            //set the body of the message, also consider setContent()
                            //for Multipart content
                            msg.setText(body);
                            //the name of your program.
                            msg.setHeader("X-Mailer", mailer);
                            //Date sent from this computer.
                            msg.setSentDate(new Date());
                            // send the message!
                            Transport.send(msg);
                            System.out.println("\nMail was sent successfully.");
                            
                     ///////////////// END /////////////////////////////
                    //////////////////To allotted Officer///////////////////////////
                    ///////////////////////////////////////////////////////////////
                           //  mailPath="http://10.41.6.137:8080/VDOS/dera.do?emailid1="+strExMail+"&name1="+strName+"&dutydate1="+strScheduledate+"&shift1="+strShift+"&emailid2="+strMail+"&dutydate2="+strExScheduledate+"&shift2="+strExShift;
                             
                           
                         ///////////////// START /////////////////////////////
                        //////////////////To Excluded Officer///////////////////////////
                        ///////////////////////////////////////////////////////////////    
                            
                             String body1 = "Sir/Madam\r\n"+
			     "You have been exempted from DO duty, scheduled on "+ strDutydate +". Revised duty schedule will be intimated later."+
                             "To access LPSC Duty officer System(LDOS) click on the link below:"+  
                             " http://X/LPSCDOS/login.jsp \n"+ 
                              "Regards \n"+
                             "System  Administrator \n"+
                              "NOTE : This is an auto-generated mail.Do not reply to this mail";       
                                     
                        
                           
                            //body1=body1 + "Schedule date:\r\n"+ strExScheduledate;           
                            //body1=body1 + "Shift:"+ strExShift+"\n"+"NOTE :- This is an auto-generated mail. Do not reply to this mail";
                           // body1=body1 +"\n"+"<br>"+"Regards"+"\n"+"System Administrator";

 
                            msg.setRecipients(Message.RecipientType.TO,InternetAddress.parse(strMail, false));
                            if (cc != null)
                            msg.setRecipients(Message.RecipientType.CC,InternetAddress.parse(cc, false));
                            if (bcc != null)
                            msg.setRecipients(Message.RecipientType.BCC,InternetAddress.parse(bcc, false));
                            //subject line.
                            msg.setSubject(subject1);
                            //set the body of the message, also consider setContent()
                            //for Multipart content
                            msg.setText(body1);
                            //the name of your program.
                            msg.setHeader("X-Mailer", mailer);
                            //Date sent from this computer.
                            msg.setSentDate(new Date());
                            // send the message!
                            Transport.send(msg);
                            System.out.println("\nMail was sent successfully.");
                 
                      }
                      catch (Exception e) 
                      {
			  System.out.println("Error: " + e.getMessage());
                          //view = request.getRequestDispatcher("requestExchangeDOExptMailLPSC.jsp"); 
                          view = request.getRequestDispatcher("requestExchangeDOMailNotSndLPSC.jsp");
                          view.forward(request, response);
		      }
                         
                   ///////////////// END /////////////////////////////
                        //////////////////To Excluded Officer///////////////////////////
                        ///////////////////////////////////////////////////////////////     
                    
                    /*NEW CODE*/
                    
                    
                   //objLog.info("PATH for sending mail : "+mailPath);
                  //response.sendRedirect(mailPath);
                        
                    //redirect to exchangeMailsent.jsp
                     view = request.getRequestDispatcher("exchangeMailsent.jsp");                
                     view.forward(request, response);
                    
                        
                   }
                    }
                    else
                    {
                     view = request.getRequestDispatcher("getScheduleEdit.do");                
                    view.forward(request, response);
                    
                    }
                 }
            }
        }
catch(Exception e)
{
    //objLog.error("ERROR : "+e);
    view = request.getRequestDispatcher("Failure.jsp");
    view.forward(request, response);
}
finally
{
    db.close();
}
    }
}
