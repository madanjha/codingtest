// Function : get role details from role table
// Author   : Gadha PS, Anju Varghese
// Division : COM/CIG
// Date     : 28/01/2009

import java.io.*;
import java.util.*;
import java.util.Date;
import java.text.*;
import java.lang.String;
import java.sql.*;
import java.net.*;
import javax.servlet.*;
import javax.servlet.http.*;
import org.apache.log4j.Logger;
import dateform.*;

public class getProfile extends HttpServlet {
    
    protected void doGet(HttpServletRequest request, HttpServletResponse response)
    throws ServletException, IOException {
        doPost(request,response);
    }
    
    protected void doPost(HttpServletRequest request, HttpServletResponse response)
    throws ServletException, IOException {
        
        RequestDispatcher view = null;
        PrintWriter out= response.getWriter();
        dbConn db=new dbConn();
        dateformat d1=new dateformat();
      //  Logger //objLog = Logger.getLogger("ApplicationDO");
        try
{
            Connection conn= null;
            conn = db.Connect();
            Statement stmt = conn.createStatement();
            ResultSet rs1=null;
            String strFlag="invalidSession";
            String strStaffcode="",strQuery="", strRoleFlag="", strLink="";
            ArrayList arrProfile=new ArrayList();
            
            // Get session
            HttpSession curSession=request.getSession(false);
            // Check if valid session
            if(curSession==null)
{
                //objLog.error("Invalid session");
                request.setAttribute("flag",strFlag);
                view=request.getRequestDispatcher("sessionError.jsp");
                view.forward(request, response);
            }
            
            else //valid session
            {
                if((String)curSession.getAttribute("userid")==null)
{
                    //objLog.error("Invalid session");
                    request.setAttribute("flag",strFlag);
                    view=request.getRequestDispatcher("sessionError.jsp");
                    view.forward(request, response);
                }
                else
                {
                    strRoleFlag=request.getParameter("roleflag");
                    strLink=request.getParameter("link");
                    
                    if (strRoleFlag.equals("DO"))
                    {                    
                        strStaffcode=(String)curSession.getAttribute("userid");
                    }
                    else
                    {
                        strStaffcode=request.getParameter("txtStaffcode1");
                    }
                    strQuery="select empname,division, designation, sex, housenumber,housename,streetname,placename,cityname,district, pincode, state,resphone,mobile,boardingpt,sittingplace,sittingroomno,sittingphone from dodetails,doaddress where dodetails.empcode=doaddress.empcode and dodetails.empcode='"+strStaffcode+"'";
                    rs1=stmt.executeQuery(strQuery);
                    if(rs1.next())
                    {
                        arrProfile.add(rs1.getString(1));
                        arrProfile.add(rs1.getString(2));
                        arrProfile.add(rs1.getString(3));
                        arrProfile.add(rs1.getString(4));
                        arrProfile.add(rs1.getString(5));
                        arrProfile.add(rs1.getString(6));
                        arrProfile.add(rs1.getString(7));
                        arrProfile.add(rs1.getString(8));
                        arrProfile.add(rs1.getString(9));
                        arrProfile.add(rs1.getString(10));
                        arrProfile.add(rs1.getString(11));
                        arrProfile.add(rs1.getString(12));
                        arrProfile.add(rs1.getString(13));
                        arrProfile.add(rs1.getString(14)); 
                        arrProfile.add(rs1.getString(15));
                        arrProfile.add(rs1.getString(16));
                        arrProfile.add(rs1.getString(17));
                        arrProfile.add(rs1.getString(18));                     
                                                
                    }
                    rs1.close();
                    
                    //get email id
                    strQuery="select email from empemail where scno='"+strStaffcode+"'";
                    rs1=stmt.executeQuery(strQuery);
                    if (rs1.next())
                    {
                        //arrProfile.add(rs1.getString(1));
                        request.setAttribute("email", rs1.getString(1));
                    }
                    else
                    {
                       // arrProfile.add("NIL");
                        request.setAttribute("email","NIL");
                    }
                    rs1.close();
                    
                    
                    request.setAttribute("staffcode",strStaffcode);
                   request.setAttribute("arrProfile",arrProfile);
                   
                   if (strRoleFlag.equals("DO"))
                   {
                        view = request.getRequestDispatcher("editProfileDO.jsp");
                   }
                   else
                   {     
                       if (strLink.equals("edit"))
                       {
                            view = request.getRequestDispatcher("editProfileAO.jsp");
                       }
                       else
                       {
                           view = request.getRequestDispatcher("viewProfileAO.jsp");
                       }
                   }
                   view.forward(request, response);
                }
            }
        }
catch(Exception e)
{
    //objLog.error("ERROR : "+e);
    view = request.getRequestDispatcher("Failure.jsp");
    view.forward(request, response);
}
finally
{
    db.close();
}
    }
}
