// Function : get role details from role table
// Author   : Gadha PS, Anju Varghese
// Division : COM/CIG
// Date     : 28/01/2009

import java.io.*;
import java.util.*;
import java.util.Date;
import java.text.*;
import java.lang.String;
import java.sql.*;
import java.net.*;
import javax.servlet.*;
import javax.servlet.http.*;
import org.apache.log4j.Logger;
import dateform.*;

public class createHolidayList extends HttpServlet {
    
    protected void doGet(HttpServletRequest request, HttpServletResponse response)
    throws ServletException, IOException {
        doPost(request,response);
    }
    
    protected void doPost(HttpServletRequest request, HttpServletResponse response)
    throws ServletException, IOException {
        
        RequestDispatcher view = null;
        PrintWriter out= response.getWriter();
        dbConn db=new dbConn();
        dateformat d1=new dateformat();
     //   Logger //objLog = Logger.getLogger("ApplicationDO");
        try
{
            Connection conn= null;
            conn = db.Connect();
            Statement stmt = conn.createStatement();
            Statement stmt2 = conn.createStatement();
            ArrayList Holiday=new ArrayList();
            ResultSet rs1=null;
            String strFlag="invalidSession", strYear="", strQuery="", strHolDate="", strHolYear="", strHolRem="";
            String strHoliday="";
            int iHolYear=0, Hol_id=0;
            
            // Get session
            HttpSession curSession=request.getSession(false);
            // Check if valid session
            if(curSession==null)
{
                //objLog.error("Invalid session");
                request.setAttribute("flag",strFlag);
                view=request.getRequestDispatcher("sessionError.jsp");
                view.forward(request, response);
            }
            
            else //valid session
            {
                if((String)curSession.getAttribute("userid")==null)
{
                    //objLog.error("Invalid session");
                    request.setAttribute("flag",strFlag);
                    view=request.getRequestDispatcher("sessionError.jsp");
                    view.forward(request, response);
                }
                else
                {
                    strYear = request.getParameter("txtYear");
                    int iYear=Integer.parseInt(strYear);
                    iYear = iYear-1;
                    
                    strQuery = "select max(holiday_id) as maxcode from holiday";
                    rs1 = stmt.executeQuery(strQuery);
                    if (rs1.next())
                    {
                        Hol_id = rs1.getInt("maxcode");     
                        Hol_id = Hol_id+1;
                    }
                    else
                    {
                        Hol_id = 1;
                    }
                    rs1.close();
                    
                    strQuery="select * from holiday where year(holidaydate)='"+iYear+"'";
                    rs1=stmt.executeQuery(strQuery);
                    while(rs1.next())
                    {                       
                        strHoliday = rs1.getString(2);
                                              
                        //add one to year
                        strHolDate = rs1.getString(3);
                        strHolYear = strHolDate.substring(0,4);
                        strHolRem = strHolDate.substring(4,10);
                        iHolYear = Integer.parseInt(strHolYear);
                        iHolYear+=1;
                        strHolYear= new Integer(iHolYear).toString();
                        strHolDate = strHolYear+strHolRem;                                             
                         
                        Holiday.add(new Integer(Hol_id).toString());                      
                        Holiday.add(strHoliday);
                         Holiday.add(d1.datedisplay(strHolDate));
                         
                         strQuery = "insert into holiday values('"+Hol_id+"', '"+strHoliday+"', '"+strHolDate+"')";
                         stmt2.executeUpdate(strQuery);                        
                         
                         Hol_id+=1;
                    }
                    rs1.close();
                    
                    request.setAttribute("Year",strYear);
                    request.setAttribute("Holiday",Holiday);
                    view = request.getRequestDispatcher("addHoliday.jsp");
                    view.forward(request, response);

                }
            }
        }
catch(Exception e)
{
    //objLog.error("ERROR : "+e);
    view = request.getRequestDispatcher("Failure.jsp");
    view.forward(request, response);
}
finally
{
    db.close();
}
    }
}
