
import java.sql.*;

public class dbConn
{     
    private Connection conn = null;
   
    public dbConn() 
    {
        try 
		{
                  Class.forName("com.mysql.jdbc.Driver");
	          String db_user = "root";       //Username in mysql
	          String db_pass = "root"; //Password for the user in mysql
	          String url="jdbc:mysql://127.0.0.1:3306/lpscdutyofficer"; 
	      
	          conn = DriverManager.getConnection(url,db_user,db_pass);
      	}
        catch (ClassNotFoundException e) 
	{
		System.err.println("ConnectionBean: driver unavailable");
		conn = null;
	}
	catch (SQLException e)
	 {
		System.err.println("ConnectionBean: driver not loaded");
		conn= null;
	}
    }
    
    public Connection Connect()
    {       
        return conn;
    }
    
    public void close()
	{
	try 
	{
		conn.close();
	}
	catch (SQLException e) 
	{	
            System.err.println("ConnectionBean: driver not loaded");
	    conn = null; 
	}
	}

	public  void main(String args[]) 
	{
		Connection conn = Connect();

		if (conn == null) 
		{
			System.out.println("null\n");
		} 
		else 
		{
			System.out.println("Success\n");
		}
	}

    
}
