// Function : get role details from role table
// Author   : Gadha PS, Anju Varghese
// Division : COM/CIG
// Date     : 28/01/2009

import java.io.*;
import java.util.*;
import java.util.Date;
import java.text.*;
import java.lang.String;
import java.sql.*;
import java.net.*;
import javax.servlet.*;
import javax.servlet.http.*;
import org.apache.log4j.Logger;
import dateform.*;

public class getExchangeStaffcode extends HttpServlet {
    
    protected void doGet(HttpServletRequest request, HttpServletResponse response)
    throws ServletException, IOException {
        doPost(request,response);
    }
    
    protected void doPost(HttpServletRequest request, HttpServletResponse response)
    throws ServletException, IOException {
        
        RequestDispatcher view = null;
        PrintWriter out= response.getWriter();
        dbConn db=new dbConn();
        dateformat d1=new dateformat();
     //   Logger //objLog = Logger.getLogger("ApplicationDO");
        try
{
            Connection conn= null;
            conn = db.Connect();
            Statement stmt = conn.createStatement();
            ResultSet rs1=null;
            String strFlag="invalidSession", strCurDate="", strSex="", strDivision="", strShiftType="", strRoleFlag="";
            String strShift="",strDutydate="",strName="",strQuery="",strStartdate="",strEnddate="", strStaffcode="",strDutydate1="";
            ArrayList arEmpcode=new ArrayList(); //empcode of same shift officers
            
            String strExName="",strExStaffcode="",strExDutydate="",strExShift="",strExSex="",strType="Load", strExDivision="", strLink="",strHoliFlag="";
            int strHolvalue=0;
            // Get session
            HttpSession curSession=request.getSession(false);
            // Check if valid session
            if(curSession==null)
{
                //objLog.error("Invalid session");
                request.setAttribute("flag",strFlag);
                view=request.getRequestDispatcher("sessionError.jsp");
                view.forward(request, response);
            }
            
            else //valid session
            {
                if((String)curSession.getAttribute("userid")==null)
                {
                    //objLog.error("Invalid session");
                    request.setAttribute("flag",strFlag);
                    view=request.getRequestDispatcher("sessionError.jsp");
                    view.forward(request, response);
                }
                 else
                {
                    strStaffcode=request.getParameter("strStaffcode");
                    strShift=request.getParameter("newShift");
                    strDutydate=request.getParameter("newDate");
                    strDutydate1=d1.savedate(strDutydate);
                    strName=request.getParameter("strName");
                    strSex=request.getParameter("strSex");
                    strDivision=request.getParameter("strDivision");
                   
                    strStartdate=request.getParameter("strStartDate");
                    strStartdate=d1.savedate(strStartdate);
                    strEnddate=request.getParameter("strEndDate");
                     strEnddate=d1.savedate(strEnddate);
                    
                     //get selected staffcode from combo
                     strExStaffcode= request.getParameter("cboStaffcode");
                     //objLog.info("cbo staff code "+strExStaffcode);
                     
                     //get shift from dodetails
                     strQuery="select shift from dodetails where empcode='"+strStaffcode+"'";
                     rs1=stmt.executeQuery(strQuery);
                     if (rs1.first())
                     {
                         strShiftType=rs1.getString(1);
                         //objLog.info("Shift: "+strShiftType);
                     }
                     rs1.close();
                     
                     //check if date selected is a holiday
                     strQuery="select dayofweek('"+strDutydate1+"')";
                     //objLog.info(strQuery);
                     rs1=stmt.executeQuery(strQuery);
                     if(rs1.first())
                     {  strHolvalue=rs1.getInt(1);
                        if(strHolvalue==1 || strHolvalue==7)
                        {
                            strHoliFlag="true";
                        }
                        else
                        {
                              strHoliFlag="false";
                        }
                     }
                     rs1.close();
                      //objLog.info("holiday flag: "+strHoliFlag+strHolvalue);
                      
                     strQuery="select * from holiday where holidaydate='"+strDutydate1+"'";
                       //objLog.info(strQuery);
                      rs1=stmt.executeQuery(strQuery);
                     if(rs1.first())
                     {  
                            strHoliFlag="true";
                        
                     }                  
                     rs1.close();                     
                         //objLog.info("holiday flag: "+strHoliFlag+strHolvalue);
                         
                     strRoleFlag=request.getParameter("roleflag");
                     //objLog.info("Role of user logged: "+strRoleFlag);
                     
                     strLink=request.getParameter("link");
                     //objLog.info("Link: "+strLink);
                     
                     //if sex=F show only staffcodes in first shift, omit holidays
                     strSex=strSex.trim();
                     strShift=strShift.trim();
                     if (strSex.equals("F"))
                     {
                         //for AO, allow exchange of officers upto & including current date
                         //for DO, current date not allowed 
                         
                         
                        strQuery="select empcode,empname from dodetails where empcode in(select distinct empcode from doschedule where !(scheduledate='"+strDutydate1+"' and shift='"+strShift+"') and scheduledate between'"+strStartdate+"' and '"+strEnddate+"' and ";
                       strQuery=strQuery+"dayofweek(scheduledate)<>1 and dayofweek(scheduledate)<>7 and scheduledate not in (select holidaydate from holiday) and shift='FIRST' and scheduledate >= curdate() ";
                         
                         //for DO, for listing in combo, list only those officers whose exchange flag is not set to 1
                         
                          if (strRoleFlag.equals("DO"))
                         {
                             strQuery=strQuery+" and empcode not in (select empcode1 from exchangedo where exchangeflag='1') and empcode not in (select empcode2 from exchangedo where exchangeflag='1') and scheduledate > curdate()";
                         }
                     }
                     else if (strSex.equals("M") && strShiftType.equals("FIRST")) //show only staffcodes in first shift
                     {
                         if (strHoliFlag.equals("false")) //not holiday
                         {
                         strQuery="select empcode,empname from dodetails where empcode in(select distinct empcode from doschedule a where !(scheduledate='"+strDutydate1+"' and shift='"+strShift+"') and scheduledate between'"+strStartdate+"' and '"+strEnddate+"' and shift='FIRST' and scheduledate >= curdate()";
                         }
                         else //holiday, exclude ladies
                         {
                             strQuery="select empcode,empname from dodetails where empcode in(select distinct a.empcode from doschedule a, dodetails b where !(scheduledate='"+strDutydate1+"' and a.shift='"+strShift+"') and scheduledate between'"+strStartdate+"' and '"+strEnddate+"' and a.empcode=b.empcode and a.shift='FIRST' and sex<>'F' and scheduledate >= curdate()";
                         }
                         if (strRoleFlag.equals("DO"))
                         {
                             strQuery=strQuery+" and a.empcode not in (select empcode1 from exchangedo where exchangeflag='1') and a.empcode not in (select empcode2 from exchangedo where exchangeflag='1') and scheduledate > curdate()";
                         }
                     }
                     else if (strShift.equals("SECOND"))
                     {                       
                         //if shift='SECOND' show only staffcodes where sex='M' and shift='ANY' in dodetails
                         strQuery="select empcode,empname from dodetails where empcode in(select distinct a.empcode from doschedule a, dodetails b where !(scheduledate='"+strDutydate1+"' and a.shift='"+strShift+"') and scheduledate between'"+strStartdate+"' and '"+strEnddate+"' and a.empcode=b.empcode and sex='M' and b.shift='ANY' and scheduledate >= curdate()";
                         if (strRoleFlag.equals("DO"))
                         {
                             strQuery=strQuery+" and a.empcode not in (select empcode1 from exchangedo where exchangeflag='1') and a.empcode not in (select empcode2 from exchangedo where exchangeflag='1') and scheduledate > curdate()";
                         }
                     }
                     else
                     {
                         if (strHoliFlag.equals("false")) //not holiday
                         {
                            strQuery="select empcode,empname from dodetails where empcode in(select distinct empcode from doschedule a where !(scheduledate='"+strDutydate1+"' and shift='"+strShift+"') and  scheduledate between'"+strStartdate+"' and '"+strEnddate+"' and scheduledate >= curdate()";   
                         }
                         else//holiday, exclude ladies
                         {
                             strQuery="select empcode,empname from dodetails where empcode in(select distinct a.empcode from doschedule a, dodetails b where !(scheduledate='"+strDutydate1+"' and a.shift='"+strShift+"') and  scheduledate between'"+strStartdate+"' and '"+strEnddate+"' and a.empcode=b.empcode and sex<>'F' and scheduledate >= curdate()";   
                         }
                          if (strRoleFlag.equals("DO"))
                         {
                             strQuery=strQuery+" and a.empcode not in (select empcode1 from exchangedo where exchangeflag='1') and a.empcode not in (select empcode2 from exchangedo where exchangeflag='1') and scheduledate > curdate()";
                         }
                     }   
                     
                       strQuery=strQuery+" order by empcode)";                
                     
                    //objLog.info("strQuery in exchange staffcode "+strQuery);
                    rs1=stmt.executeQuery(strQuery);
                    while (rs1.next()) //schedule already prepared
                    {
                        if (!strStaffcode.equals(rs1.getString(1))) //exclude selected staffcode
                        {
                           arEmpcode.add(rs1.getString(1));   
                           arEmpcode.add(rs1.getString(2)); 
                        }
                    }
                    rs1.close();
                    
                    if (strExStaffcode != null)
                    {
                        //check if staffcode="select"
                        if (strExStaffcode.equals("Select")) //reset values
                        {
                            strExName="";
                            strExDutydate="";
                            strExShift="";
                            strExSex="";
                            strExDivision="";
                        }
                        else
                        {
                           strQuery = "SELECT scheduledate,a.shift,empname,sex,division FROM doschedule a, dodetails b where a.empcode='"+strExStaffcode+"' and b.empcode='"+strExStaffcode+"'";
                            rs1=stmt.executeQuery(strQuery);
                            //objLog.info("strQuery inside exchaage details java "+strQuery);
                            while (rs1.next())
                            {
                                strExDutydate= d1.datedisplay(rs1.getString(1));
                                strExShift = rs1.getString(2);
                                strExName = rs1.getString(3);
                               strExSex = rs1.getString(4);
                               strExDivision = rs1.getString(5);
                            }
                            rs1.close();

                        } 
                        strType="Edit";
                        
                    }
                    
                    //get current date
                    
                  /*  strQuery = "select curdate()";
                    rs1=stmt.executeQuery(strQuery);
                    if (rs1.next())
                    {
                        strCurDate=rs1.getString(1);
                    }
                    rs1.close();*/
                    
                    strStartdate = d1.datedisplay(strStartdate);                    
                    strEnddate = d1.datedisplay(strEnddate);
                    
                    request.setAttribute("StartDate",strStartdate);
                    request.setAttribute("EndDate",strEnddate);
                    request.setAttribute("Shift",strShift);
                    request.setAttribute("Name",strName);
                    request.setAttribute("Sex",strSex);
                    request.setAttribute("Division",strDivision);
                    request.setAttribute("Staffcode",strStaffcode);
                    request.setAttribute("Dutydate",strDutydate);
                    request.setAttribute("arEmpcode", arEmpcode);
                 //   request.setAttribute("Curdate", strCurDate);
                    
                    request.setAttribute("ExDutydate",strExDutydate); 
                    request.setAttribute("ExStaffcode",strExStaffcode); 
                    request.setAttribute("ExName",strExName);  
                    request.setAttribute("ExSex",strExSex);        
                    request.setAttribute("ExDivision",strExDivision); 
                    request.setAttribute("ExShift",strExShift);     
                    request.setAttribute("Flag",strType);
                    request.setAttribute("roleflag",strRoleFlag);
                    request.setAttribute("link",strLink);
                    
                    view = request.getRequestDispatcher("exchangeDO.jsp");                
                    view.forward(request, response);
                   
                 }
            }
        }
catch(Exception e)
{
    //objLog.error("ERROR : "+e);
    view = request.getRequestDispatcher("Failure.jsp");
    view.forward(request, response);
}
finally
{
    db.close();
}
    }
}
