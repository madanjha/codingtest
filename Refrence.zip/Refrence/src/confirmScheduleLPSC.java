// Function : get role details from role table
// Author   : Gadha PS, Anju Varghese
// Division : COM/CIG
// Date     : 28/01/2009

import java.io.*;
import java.util.*;
import java.util.Date;
import java.text.*;
import java.lang.String;
import java.sql.*;
import java.net.*;
import javax.servlet.*;
import javax.servlet.http.*;
import org.apache.log4j.Logger;
import dateform.*;


import java.util.Properties;
import javax.mail.Authenticator;
import javax.mail.Message;
import javax.mail.PasswordAuthentication;
import javax.mail.Session;
import javax.mail.Transport;
import javax.mail.internet.InternetAddress;
import javax.mail.internet.MimeMessage;
import java.io.*;


public class confirmScheduleLPSC extends HttpServlet {
    
    protected void doGet(HttpServletRequest request, HttpServletResponse response)
    throws ServletException, IOException {
        doPost(request,response);
    }
    
    
    class ThePasswordAuthenticator extends Authenticator {
		String user;
		String pw;
		public ThePasswordAuthenticator(String username, String password) {
			super();
			this.user = username;
			this.pw = password;
		}
		public PasswordAuthentication getPasswordAuthentication() {
			return new PasswordAuthentication(user, pw);
		}
    }
    
    protected void doPost(HttpServletRequest request, HttpServletResponse response)
    throws ServletException, IOException {
        
        RequestDispatcher view = null;
        PrintWriter out= response.getWriter();
        dbConn db=new dbConn();
        dateformat d1=new dateformat();
      //  Logger //objLog = Logger.getLogger("ApplicationDO");
        try
{
            Connection conn= null;
            conn = db.Connect();
            Statement stmt = conn.createStatement();
            ResultSet rs1=null;
            ResultSet rs2=null;
            //String strFlag="invalidSession", sid="", strQuery="", mailPath="";
            String strFlag="invalidSession", strQuery="", mailPath="", strQueryDelete="",strQuerySelect="",strQueryupdate="",strQueryupdate1="";
            String sid="1";
            String strEmpcode="", strDate="", strShift="", strEmail="";
            
            // Get session
            HttpSession curSession=request.getSession(false);
            // Check if valid session
            if(curSession==null)
{
                //objLog.error("Invalid session");
                request.setAttribute("flag",strFlag);
                view=request.getRequestDispatcher("sessionError.jsp");
                view.forward(request, response);
            }
            
            else //valid session
            {
                if((String)curSession.getAttribute("userid")==null)
{
                    //objLog.error("Invalid session");
                    request.setAttribute("flag",strFlag);
                    view=request.getRequestDispatcher("sessionError.jsp");
                    view.forward(request, response);
                }
                else
                {
                    //update confirm in scheduledetails to Y
                    // to be done after sending all mails...from mail server
                //    stmt.executeUpdate("update scheduledetails set confirm='Y' where status='NEW'");                    
                  
                   
                    //get maximum sid
                    
                    
                    strQuery="select max(scheduleno) from scheduledetails";
                    rs1=stmt.executeQuery(strQuery);
                    if (rs1.next())
                    {
                        sid=rs1.getString(1);
                        //objLog.info("Schedule id to pass to mail: "+sid);
                    }
                    rs1.close();
                    
                   
                    //send mail to all DOs
                    //pass scheduleid as sid	
                    //mailPath="http://10.41.6.137:8080/VDOS/dsi.do?sid="+sid;
   		    //objLog.info("PATH for sending mail : "+mailPath);			
		    //response.sendRedirect(mailPath);			
                    //redirect to mailsent.jsp
                    //view=request.getRequestDispatcher("mailsent.jsp");
                    //view.forward(request, response);
                    
                  //NEW CODE
                   
                  /*   strQueryDelete="delete from  empemail";
                    stmt.executeQuery(strQueryDelete);
                    //strQuery="insert into empemail(select employeecode,'','',intramailid from tab_empcontactdetails where employeecode in(select empcode from migratedemplist))";
                    rs1=stmt.executeQuery(strQuery);
                    if (rs1.next())
                    {
                       
                         sid=rs1.getString(1);
                        
                        //objLog.info("Schedule id to pass to mail: "+sid);
                    }
                    rs1.close(); 
                   */
                    
                    
                        String mailer = "myprogram";
			//comma separated list of recipients.
			//String to = "shiny@lpscv.dos.gov.in";
			String cc = "bill@ibm.com,mary@oracle.com";
			String bcc = null;
			String from = "shiny@lpscv.dos.gov.in";
			String subject = "Testing mailing from Java";
			String body = "VSSC Duty Officer System � Intimation of duty.\r\n"+
			"Sent on: " + new Date() + "\r\n";
                        
                       // "Schedule date:: " + strDate + "\r\n"+
                        //"Shift: " + strShift + "\r\n"+
			//"Regards, \r\n" +
			//"Joel" ;
                                
			String smtpserver = "lpscv.dos.gov.in";
			String smtpport = "25";
			//my username for smtp.att.yahoo.com was a fully
			//qualified email, like joel@att.com.
			String user = "shiny";
			//String password = "s1s2i3";
			String password = "vssc1234";
                        
                        
                        
                        
                        
			Properties props = new Properties();
			//default to "localhost"
			props.put("mail.smtp.host", smtpserver);
			//default to "25"
			props.put("mail.smtp.port", smtpport);
			//uncomment to turn on debugging output which can be useful.
			//props.put("mail.debug", "true");
			//javax.mail.Session
			
			Session session = null;
			if (user != null && password != null) {
				props.put("mail.smtp.auth", "true");
				session =Session.getInstance(props,new ThePasswordAuthenticator(user,password));
			}
                    
			/* else {
			session = Session.getDefaultInstance(props, null);
			}*/
			/*
			* using
			* javax.mail.Message & javax.mail.internet.MimeMessage
			* javax.mail.internet.InternetAddress
			*/
			
                        
                       try 
		    {  
                        strQuerySelect="select empcode,scheduledate,shift,email from doschedule dos,empemail empe where dos.empcode=empe.scno and dos.scheduleno="+sid;
                                               
                        rs2=stmt.executeQuery(strQuerySelect);
                        while(rs2.next())
                        {
                       
                                 strEmpcode=rs2.getString(1);
                                 strDate=rs2.getString(2);
                                 strShift=rs2.getString(3);
                                 strEmail=rs2.getString(4);
                                 
                                 body=body + "Schedule date: " +strDate;
                                 body=body + "Shift : " +strShift;
                        
                        //objLog.info("Schedule id to pass to mail: "+sid);
                                 //if((strEmpcode.equals("nil"))
                      // if(!(strEmail.equals("nil")))
                       
                      //{
			 Message msg = new MimeMessage(session);
		         msg.setFrom(new InternetAddress(from));
                        
			/*
			* Parse the given comma separated sequence of
			* addresses into an Array of InternetAddress objects
			* Then set as the desired recipient.
			*/
                        
			msg.setRecipients(Message.RecipientType.TO,InternetAddress.parse(strEmail, false));
			if (cc != null)
			msg.setRecipients(Message.RecipientType.CC,InternetAddress.parse(cc, false));
			if (bcc != null)
			msg.setRecipients(Message.RecipientType.BCC,InternetAddress.parse(bcc, false));
			//subject line.
			msg.setSubject(subject);
			//set the body of the message, also consider setContent()
			//for Multipart content
			msg.setText(body);
			//the name of your program.
			msg.setHeader("X-Mailer", mailer);
			//Date sent from this computer.
			msg.setSentDate(new Date());
			// send the message!
			Transport.send(msg);
			System.out.println("\nMail was sent successfully.");
                        
                        
                       // strQuery = "update doschedule set scheduledate='"+strDutydate+"', shift='"+strShift+"' where empcode='"+strExStaffcode+"' and scheduledate='"+strExDutydate+"'";
                        //stmt.executeUpdate(strQuery);
                        
                        
                        
                        //}// if(!(strEmpcode.equals("nil")))
                                 
                        }//while
                        rs2.close();
                        
                         // strQueryupdate = "update doschedule  set ismailsent='Y' where scheduleno="+sid;
                          //stmt.executeUpdate(strQueryupdate);
                        
                        // strQueryupdate1 = "update scheduledetails set confirm='Y' where scheduleno="+sid;
                        // stmt.executeUpdate(strQueryupdate1);
		   } 
                       catch (Exception e) {
				System.out.println("Error: " + e.getMessage());
		   	}
                //NEW CODE
                    
                    
                }
            }
        }
catch(Exception e)
{
    //objLog.error("ERROR : "+e);
    view = request.getRequestDispatcher("Failure.jsp");
    view.forward(request, response);
}
finally
{
    db.close();
}
    }
}
