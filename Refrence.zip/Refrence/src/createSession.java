// Function : get role details from role table
// Author   : Gadha PS, Anju Varghese
// Division : COM/CIG
// Date     : 28/01/2009

import java.io.*;
import java.util.*;
import java.util.Date;
import java.text.*;
import java.lang.String;
import java.sql.*;
import java.net.*;
import javax.servlet.*;
import javax.servlet.http.*;
import org.apache.log4j.Logger;

public class createSession extends HttpServlet {
    
    protected void doGet(HttpServletRequest request, HttpServletResponse response)
    throws ServletException, IOException {
        doPost(request,response);
    }
    
    protected void doPost(HttpServletRequest request, HttpServletResponse response)
    throws ServletException, IOException {
        
        
        HttpSession session = request.getSession(true);   
        RequestDispatcher view = null;
        PrintWriter out= response.getWriter();
        dbConn db=new dbConn();
       // Logger //objLog = Logger.getLogger("ApplicationDO");
        try
        {
            Connection conn= null;
            conn = db.Connect();
            Statement stmt = conn.createStatement();
            Statement stmtauth = conn.createStatement();
            Statement stmt2 = conn.createStatement();
            ResultSet rs1=null, rs2=null,rsauth=null;          
            String strQuery="", strIpAddr="", strFlagIp="false", strLoginDateTime="", strScheduledate="", strShift="", strStaffcode="", strRole="",authQry="";
            String strloginAuthflag="invalidID";
            String strPasswd="";
            
            //get userid
       /*   String strUser=request.getParameter("var");  //last 7 characters represent userid
          //objLog.info("Var passed : "+strUser);
          //retrive userid
           int len=strUser.length();
          //objLog.info("Length : "+len);
          strUser = strUser.substring(len-7,len);
          strUser=strUser.toUpperCase();
          //objLog.info("User id : "+strUser); */  //Uncomment this when authentication is ready
            
            
            
            
             String strUser=request.getParameter("txtUserID");            //comment this when authentication is ready
             strUser=strUser.toUpperCase();
                        
             String strPassword=request.getParameter("txtPassword"); 
             
            // String authQry="select * from authentication where empcode="+strUser +"and passwd="+strPassword;
            // rsauth=stmt.executeQuery(authQry);
            //strUser=strUser.toUpperCase();
             
             //authQry="select passwd from authentication where empcode='"+strUser+"'";
             
             
              authQry="select distinct username,password from authentication where username='"+strUser +"' and password='"+strPassword+"'"; 
             
              
             //authQry="select distinct username,password from tab_vsscmislogin where username='"+strUser +"' and password='"+strPassword+"'"; 
              //authQry="select distinct(*) from authentication where empcode='"+strUser +"' and passwd='"+strPassword+"'"; 
              rsauth=stmtauth.executeQuery(authQry);
             
            /*  if(rsauth.next())
              {
               
                 strPasswd=rsauth.getString("passwd");
                           
              }*/
              //rsauth.close();  
             
              //if(strPasswd.equals(strPassword))
               if(rsauth.next())
               {
                
                session.setAttribute("userid",strUser); 
                strStaffcode=strUser;
                strQuery="select now()";
                rs1=stmt.executeQuery(strQuery);
                if(rs1.first())
                {
                     strLoginDateTime=rs1.getString(1);
                     //objLog.info("Login Time: "+strLoginDateTime);
                     strLoginDateTime=strLoginDateTime.substring(0,19);
                     //objLog.info("Login Time: "+strLoginDateTime);
                }
                rs1.close();

            //set role of user
            strQuery="select role from sysuser where empcode='"+strUser+"'";
            rs1=stmt.executeQuery(strQuery);
            if (rs1.next())
            {
                strRole=rs1.getString("role");
               // //objLog.info("Role of user: "+strRole);
               // session.setAttribute("role",strRole);  
            }
            else
            {
                strRole="DO";
            }
            rs1.close();
                       
             //objLog.info("Role of user: "+strRole);
            session.setAttribute("role",strRole); 
            
            if (strRole.equals("DO") || strRole.equals("SA"))
            {
            
                // check if he is logged in from permitted machine
                strIpAddr=request.getRemoteAddr();
                //objLog.info("IP: "+strIpAddr);
                    
                strQuery="select * from doipaddress where ipaddress='"+strIpAddr+"'";
                rs2=stmt2.executeQuery(strQuery);
                if (rs2.next())
                {
                     strFlagIp = "true";
                     //objLog.info("Valid IP");
                }
                rs2.close();
                
                
                 if (strFlagIp.equals("true")) //valid IP
                {                    
                    //check if scheduled DO (handle increment in curdate when time exceeds 12pm)
                    //first shift DO can enter observations on that day(24 hrs)
                    //second shift DO can enter observations on that day & next day(24 hrs)

                    strQuery="select logindatetime, scheduledate, shift from doschedule where (scheduledate=curdate() or ((datediff(curdate(),scheduledate)=1) and doschedule.shift='SECOND')) and doschedule.empcode='"+strStaffcode+"'";
                    //objLog.info(strQuery);
                    rs2=stmt2.executeQuery(strQuery);                        
                    if (rs2.next())
                    {
                        //check if he has already logged in before
                        if (rs2.getString(1).equals("0000-00-00 00:00:00"))
                        {
                             //objLog.info("First log in");
                             strScheduledate=rs2.getString(2);
                             strShift=rs2.getString(3);
                             //update login time
                             stmt.executeUpdate("update doschedule set logindatetime='"+strLoginDateTime+"' where empcode='"+strStaffcode+"' and scheduledate='"+strScheduledate+"' and shift='"+strShift+"'");
                             //objLog.info(strQuery);
                            
                             //update anyshift/firstshiftdo
                              strQuery="update firstshiftdo set prevshift2=prevshift1, prevshift1='"+strShift+"', scheduled='N', prevdutydate='"+strScheduledate+"' where empcode='"+strStaffcode+"'";
                              //objLog.info(strQuery);
                              stmt.executeUpdate(strQuery);
                              strQuery="update anyshiftdo set prevshift2=prevshift1, prevshift1='"+strShift+"', scheduled='N', prevdutydate='"+strScheduledate+"' where empcode='"+strStaffcode+"'";
                              //objLog.info(strQuery);
                              stmt.executeUpdate(strQuery);
                              
                              //update dodetails
                             
                              if (strShift.equals("FIRST"))
                              {
                                 strQuery="update dodetails set nooffirstshift=nooffirstshift+1 where empcode='"+strStaffcode+"'";
                              }
                              else
                              {
                                  strQuery="update dodetails set noofsecondshift=noofsecondshift+1 where empcode='"+strStaffcode+"'";
                              }                     
                              stmt.executeUpdate(strQuery);   
                              
                               //update scheduled status to N if logindatetime is null for previous day's DOs                    
                    
                //       stmt.executeUpdate("update anyshiftdo set scheduled='N' where empcode in (select empcode from doschedule where (datediff(curdate(),scheduledate)=1 or datediff(curdate(),scheduledate)=2 or datediff(curdate(),scheduledate)=3) and logindatetime='0000-00-00 00:00:00' )");
               //        stmt.executeUpdate("update firstshiftdo set scheduled='N' where empcode in (select empcode from doschedule where (datediff(curdate(),scheduledate)=1 or datediff(curdate(),scheduledate)=2 or datediff(curdate(),scheduledate)=3) and logindatetime='0000-00-00 00:00:00')");
                            
                         //     stmt.executeUpdate("update anyshiftdo set scheduled='N' where empcode in (select empcode from doschedule where scheduledate<curdate() and logindatetime='0000-00-00 00:00:00')");
                           //   stmt.executeUpdate("update firstshiftdo set scheduled='N' where empcode in (select empcode from doschedule where scheduledate<curdate() and logindatetime='0000-00-00 00:00:00')");
                              
                      /*OLD QRY          
                      stmt.executeUpdate("update anyshiftdo set scheduled='N' where empcode in (select empcode from doschedule where (datediff(curdate(),scheduledate)=1 or datediff(curdate(),scheduledate)=2 or datediff(curdate(),scheduledate)=3) and logindatetime='0000-00-00 00:00:00' and empcode not in (select empcode from doschedule where scheduleno in (select scheduleno from scheduledetails where startdate>=curdate()))");
                      stmt.executeUpdate("update firstshiftdo set scheduled='N' where empcode in (select empcode from doschedule where (datediff(curdate(),scheduledate)=1 or datediff(curdate(),scheduledate)=2 or datediff(curdate(),scheduledate)=3) and logindatetime='0000-00-00 00:00:00' and empcode not in (select empcode from doschedule where scheduleno in (select scheduleno from scheduledetails where startdate>=curdate()))");
                      */      
                         stmt.executeUpdate("update anyshiftdo set scheduled='N' where empcode in (select empcode from doschedule where (datediff(curdate(),scheduledate)=1 or datediff(curdate(),scheduledate)=2 or datediff(curdate(),scheduledate)=3) and logindatetime='0000-00-00 00:00:00') and empcode not in (select empcode from doschedule where scheduleno in (select scheduleno from scheduledetails where startdate>=curdate()))");
                         stmt.executeUpdate("update firstshiftdo set scheduled='N' where empcode in (select empcode from doschedule where (datediff(curdate(),scheduledate)=1 or datediff(curdate(),scheduledate)=2 or datediff(curdate(),scheduledate)=3) and logindatetime='0000-00-00 00:00:00') and empcode not in (select empcode from doschedule where scheduleno in (select scheduleno from scheduledetails where startdate>=curdate()))");
                      
                      
                        
                               
                        //update exchangeflag to 0 for scheduledate<curdate
                        
                        stmt.executeUpdate("update exchangedo set exchangeflag='0' where scheduledate<=curdate() or empcode1='"+strStaffcode+"' or empcode2='"+strStaffcode+"'");
                        
                        }
                    }
                    rs2.close();
            }                            
            }
             
            response.sendRedirect("Home.jsp?id="+strRole);
        
            
        }//if(strPasswd))
            else
              {
                 
               //request.setAttribute("loginAuthflag",strloginAuthflag);
               view = request.getRequestDispatcher("loginfailed.jsp");
               view.forward(request, response);
                  
              }
           
    }//try
      
  catch(Exception e)
  {
      //objLog.error("ERROR : "+e);
      view = request.getRequestDispatcher("Failure.jsp");
      view.forward(request, response);
  }
finally
{
     db.close();
}
    }
}
