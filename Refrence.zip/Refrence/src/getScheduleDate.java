// Function : get role details from role table
// Author   : Gadha PS, Anju Varghese
// Division : COM/CIG
// Date     : 28/01/2009

import java.io.*;
import java.util.*;
import java.util.Date;
import java.text.*;
import java.lang.String;
import java.sql.*;
import java.net.*;
import javax.servlet.*;
import javax.servlet.http.*;
import org.apache.log4j.Logger;
 import dateform.*;

public class getScheduleDate extends HttpServlet {
    
    protected void doGet(HttpServletRequest request, HttpServletResponse response)
    throws ServletException, IOException {
        doPost(request,response);
    }
    
    protected void doPost(HttpServletRequest request, HttpServletResponse response)
    throws ServletException, IOException {
        
        RequestDispatcher view = null;
        PrintWriter out= response.getWriter();
        dbConn db=new dbConn();
         dateformat d1=new dateformat();
     //   Logger //objLog = Logger.getLogger("ApplicationDO");
       
        try
{
            Connection conn= null;
            Connection mysqlconn = null;
            conn = db.Connect();
            Statement stmt = conn.createStatement();
            ResultSet rs1=null;
            ResultSet myrs=null;
            String strFlag="invalidSession";
            String strFlag1="", strStartDate="", strQuery="", strCurDate="";
            
            // Get session
            HttpSession curSession=request.getSession(false);
            // Check if valid session
            if(curSession==null)
{
                //objLog.error("Invalid session");
                request.setAttribute("flag",strFlag);
                view=request.getRequestDispatcher("sessionError.jsp");
                view.forward(request, response);
            }
            
            else //valid session
            {
                if((String)curSession.getAttribute("userid")==null)
{
                    //objLog.error("Invalid session");
                    request.setAttribute("flag",strFlag);
                    view=request.getRequestDispatcher("sessionError.jsp");
                    view.forward(request, response);
                }
                else
                {
                                       
                    strQuery = "select DATE_ADD(max(enddate),INTERVAL 1 DAY) as startdate from scheduledetails";
                    rs1 = stmt.executeQuery(strQuery);
                    if (rs1.next())
                    {   
                        strFlag1="true";
                        strStartDate = rs1.getString(1);    
                        //objLog.info("Start Date: "+strStartDate);
                    }       
                      if (strStartDate==null)
                    {
                        strFlag1="false";
                    }
                      else
                      {
                        strStartDate=d1.datedisplay(strStartDate);
                      }
                    rs1.close();
                    
                     //get current date
                    
                    strQuery = "select curdate()";
                    rs1=stmt.executeQuery(strQuery);
                    if (rs1.next())
                    {
                        strCurDate=d1.datedisplay(rs1.getString(1));
                        //objLog.info("Cur Date: "+strCurDate);
                    }
                    rs1.close();
                    
                    //migrate email details from 10.41.6.254
                 /*   try
                    {
                        stmt.executeUpdate("delete from empemail");

                        Class.forName("com.mysql.jdbc.Driver");
                        String db_user = "root";       //Username in mysql
                        String db_pass = ""; //Password for the user in mysql
                        String url="jdbc:mysql://10.41.6.254/email";   
                        mysqlconn =DriverManager.getConnection(url,db_user,db_pass);
                        Statement mystmt = mysqlconn.createStatement();

                        strQuery="select * from garudanew";
                        myrs=mystmt.executeQuery(strQuery);
                        while(myrs.next())
                        {
                            stmt.executeUpdate("insert into empemail values('"+myrs.getString(1)+"', '"+myrs.getString(2)+"', '"+myrs.getString(3)+"', '"+myrs.getString(4)+"') ");
                        }
                        myrs.close();
                        
                        mysqlconn.close();
                    }
                    catch(Exception e)
                    {
                        //objLog.error("ERROR : "+e);
                    }
                    finally
                    {*/

                    request.setAttribute("Curdate", strCurDate);                  
                    
                     request.setAttribute("strFlag",strFlag1);
                     request.setAttribute("strStartDate",strStartDate);
                     view = request.getRequestDispatcher("prepareSchedule.jsp");                
                    view.forward(request, response);
                   // }
                    
                }
            }
        }
catch(Exception e)
{
    //objLog.error("ERROR : "+e);
    view = request.getRequestDispatcher("Failure.jsp");
    view.forward(request, response);
}
finally
{
    db.close();
}
    }
}
