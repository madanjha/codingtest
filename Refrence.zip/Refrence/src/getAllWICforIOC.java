/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
// Function : get new user details from sysuser table
// Author   : Gadha PS, Anju Varghese
// Division : COM/CIG
// Date     : 28/01/2009

import java.io.*;
import java.util.*;
import java.util.Date;
import java.text.*;
import java.lang.String;
import java.sql.*;
import java.net.*;
import javax.servlet.*;
import javax.servlet.http.*;
import org.apache.log4j.Logger;
import dateform.*;
public class getAllWICforIOC extends HttpServlet {

    protected void doGet(HttpServletRequest request, HttpServletResponse response)
    throws ServletException, IOException {
        doPost(request,response);
    }

    protected void doPost(HttpServletRequest request, HttpServletResponse response)
    throws ServletException, IOException {

        RequestDispatcher view = null;
        PrintWriter out= response.getWriter();
        dbConn db=new dbConn();
         dateformat d1=new dateformat();
     //   Logger //objLog = Logger.getLogger("ApplicationDO");
        String strQuery="",newWIC="";
        try
        {
            Connection conn= null;
            conn = db.Connect();
            Statement stmt = conn.createStatement();
            Statement stmt2 = conn.createStatement();
            Statement stmt3 = conn.createStatement();
            ResultSet rs1=null,rs2=null,rs3=null;
            String strFlag="invalidSession";
            ArrayList arrWIC=new ArrayList();
            String strStartdate="",strEnddate="",strStartdateView="";
        

            // Get session
            HttpSession curSession=request.getSession(false);
            // Check if valid session
            if(curSession==null)
            {
                //objLog.error("Invalid session");
                request.setAttribute("flag",strFlag);
                view=request.getRequestDispatcher("sessionError.jsp");
                view.forward(request, response);
            }

            else //valid session
            {
              
                strQuery="select startdate, enddate from scheduledetails where status='NEW'";
                //objLog.info(strQuery);
                rs1=stmt.executeQuery(strQuery);
                if(rs1.first())
                {
            		strStartdateView=rs1.getString(1);
                    strEnddate=rs1.getString(2);
                }
                rs1.close();

                 strQuery="select startdate from scheduledetails where status='PREV'";
                //objLog.info(strQuery);
                rs1=stmt.executeQuery(strQuery);
                if(rs1.first())
                {
                    strStartdateView=rs1.getString(1);
                 //   strEnddate=rs1.getString(2);
                }
                rs1.close();

            

//objLog.info("here2342323");
//objLog.info("strStartdateView "+strStartdateView);
strQuery="select empcode,schedulefromdate,scheduletodate from wicdetails where scheduletodate between '"+strStartdateView+"' and '"+strEnddate+"' or schedulefromdate between '"+strStartdateView+"' and '"+strEnddate+"' and datediff(scheduletodate,'1000-01-01')!=0 order by schedulefromdate";

                        //objLog.info(strQuery);
                        rs2=stmt.executeQuery(strQuery);
                        while(rs2.next())
                        {
                          strQuery="select empname,division from sysuser where empcode='"+rs2.getString("empcode")+"'";
                            //objLog.info(strQuery);
                            rs3=stmt3.executeQuery(strQuery);
                           if(rs3.next())
                           {
                           
                              arrWIC.add(rs3.getString("empname"));
                              arrWIC.add(rs3.getString("division"));
                              arrWIC.add(d1.datedisplay(rs2.getString("schedulefromdate")));
                              arrWIC.add(d1.datedisplay(rs2.getString("scheduletodate")));
                           }
                         rs3.close();
                        }

                        rs2.close();


                 request.setAttribute("arrWIC",arrWIC);
                view=request.getRequestDispatcher("viewWICforIOC.jsp");
                view.forward(request, response);
   }}
catch(Exception e)
{
    //objLog.error("ERROR : "+e);
    view = request.getRequestDispatcher("Failure.jsp");
    view.forward(request, response);
}
finally
{
    db.close();
}
}
}
