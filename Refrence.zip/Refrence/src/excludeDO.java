// Function : get role details from role table
// Author   : Gadha PS, Anju Varghese
// Division : COM/CIG
// Date     : 28/01/2009

import java.io.*;
import java.util.*;
import java.util.Date;
import java.text.*;
import java.lang.String;
import java.sql.*;
import java.net.*;
import javax.servlet.*;
import javax.servlet.http.*;
import org.apache.log4j.Logger;
import dateform.*;

public class excludeDO extends HttpServlet {
    
    protected void doGet(HttpServletRequest request, HttpServletResponse response)
    throws ServletException, IOException {
        doPost(request,response);
    }
    
    protected void doPost(HttpServletRequest request, HttpServletResponse response)
    throws ServletException, IOException {
        
        RequestDispatcher view = null;
        PrintWriter out= response.getWriter();
        dbConn db=new dbConn();
        dateformat d1=new dateformat();
       // Logger //objLog = Logger.getLogger("ApplicationDO");
        try
{
            Connection conn= null;
            conn = db.Connect();
            Statement stmt = conn.createStatement();
            ResultSet rs1=null;
            String strFlag="invalidSession";
            ArrayList arSchedule=new ArrayList(); //schedule
            String strShift="",strDutydate="", strQuery="", strStaffcode="", strStartDate="", strEndDate="";           
            String strExStaffcode="",strExSex="", strPath="",strStartDate1="", strEndDate1="", txtExStaffcode="";
            
            // Get session
            HttpSession curSession=request.getSession(false);
            // Check if valid session
            if(curSession==null)
{
                //objLog.error("Invalid session");
                request.setAttribute("flag",strFlag);
                view=request.getRequestDispatcher("sessionError.jsp");
                view.forward(request, response);
            }
            
            else //valid session
            {
                if((String)curSession.getAttribute("userid")==null)
                {
                    //objLog.error("Invalid session");
                    request.setAttribute("flag",strFlag);
                    view=request.getRequestDispatcher("sessionError.jsp");
                    view.forward(request, response);
                }
                 else
                {
                    strPath= request.getParameter("path");
                    //objLog.info("Path: "+strPath);
                    
                    strStartDate1=request.getParameter("strStartDate");
                    strStartDate=d1.savedate(strStartDate1);
                    strEndDate1=request.getParameter("strEndDate");  
                    strEndDate=d1.savedate(strEndDate1);
                    
                    if (strPath.equals("exclude"))
                    {
                    
                    strStaffcode=request.getParameter("strStaffcode");
                    strShift=request.getParameter("newShift");
                    strDutydate=request.getParameter("newDate");  
                    strDutydate=d1.savedate(strDutydate);
                   
                    strExStaffcode=request.getParameter("cboStaffcode");
                    strExSex=request.getParameter("txtSex");             
                     
                    //get selected staffcode from textbox
                    txtExStaffcode=request.getParameter("txtStaffcode");
                    
                    if(txtExStaffcode!=null)
                     {
                        strExStaffcode=txtExStaffcode;     
                        strExStaffcode=strExStaffcode.toUpperCase();
                     }
                    //objLog.info("Staffcode: "+strExStaffcode);
                    
                   //check if female is allotted to second shift
                    
                    if (strShift.equals("SECOND") && (strExSex.equals("F")))
                    {
                        view = request.getRequestDispatcher("errorLadyInSecond.jsp");                
                        view.forward(request, response);
                    }
                    else
                    {
                        strQuery = "update doschedule set empcode='"+strExStaffcode+"' where scheduledate='"+strDutydate+"' and empcode='"+strStaffcode+"' ";
                        stmt.executeUpdate(strQuery);
                        //objLog.info(strQuery);
                        
                        //set scheduled=Y for newly allotted officer
                        stmt.executeUpdate("update firstshiftdo set scheduled='Y' where empcode='"+strExStaffcode+"'");
                        stmt.executeUpdate("update anyshiftdo set scheduled='Y' where empcode='"+strExStaffcode+"'");
                        
                         //set scheduled=N for excluded officer
                        stmt.executeUpdate("update firstshiftdo set scheduled='N' where empcode='"+strStaffcode+"'");
                        stmt.executeUpdate("update anyshiftdo set scheduled='N' where empcode='"+strStaffcode+"'");
                        
                        //reset exchange flag to 0
                    
                    stmt.executeUpdate("update exchangedo set exchangeflag ='0' where empcode1='"+strStaffcode+"' or empcode2='"+strStaffcode+"'");
                    
                                                            
                   //select schedule list
                    strQuery = "SELECT scheduledate,dayofweek(scheduledate),a.shift,empname,a.empcode,division,sex,designation,sittingphone,resphone,mobile ";
                    strQuery = strQuery + "FROM doschedule a, doaddress b, dodetails c where (a.scheduledate between '"+strStartDate+"' and '"+strEndDate+"') and ";
                    strQuery = strQuery + "a.empcode=b.empcode  and a.empcode=c.empcode order by scheduledate, a.shift,empname";
                    rs1=stmt.executeQuery(strQuery);
                        
                    //objLog.info(strQuery);

                    while (rs1.next())
                    {                       

                        arSchedule.add(d1.datedisplay(rs1.getString(1)));
                        arSchedule.add(rs1.getString(2));
                        arSchedule.add(rs1.getString(3));
                        arSchedule.add(rs1.getString(4));
                        arSchedule.add(rs1.getString(5));
                        arSchedule.add(rs1.getString(6));
                        arSchedule.add(rs1.getString(7));
                        arSchedule.add(rs1.getString(8));
                        arSchedule.add(rs1.getString(9));
                        arSchedule.add(rs1.getString(10));
                        arSchedule.add(rs1.getString(11));
                       
                    }
                    rs1.close();


                    request.setAttribute("StartDate",strStartDate1);
                     request.setAttribute("EndDate",strEndDate1);
                      request.setAttribute("arSchedule",arSchedule);
                     view = request.getRequestDispatcher("viewSchedule.jsp");                
                    view.forward(request, response);
                    }
                    }
                    else
                    {
                        //select schedule list
                    strQuery = "SELECT scheduledate,dayofweek(scheduledate),a.shift,empname,a.empcode,division,sex,designation,sittingphone,resphone,mobile ";
                    strQuery = strQuery + "FROM doschedule a, doaddress b, dodetails c where (a.scheduledate between '"+strStartDate+"' and '"+strEndDate+"') and ";
                    strQuery = strQuery + "a.empcode=b.empcode  and a.empcode=c.empcode order by scheduledate, a.shift,empname";
                    rs1=stmt.executeQuery(strQuery);
                        
                    //objLog.info(strQuery);

                    while (rs1.next())
                    {                       

                        arSchedule.add(d1.datedisplay(rs1.getString(1)));
                        arSchedule.add(rs1.getString(2));
                        arSchedule.add(rs1.getString(3));
                        arSchedule.add(rs1.getString(4));
                        arSchedule.add(rs1.getString(5));
                        arSchedule.add(rs1.getString(6));
                        arSchedule.add(rs1.getString(7));
                        arSchedule.add(rs1.getString(8));
                        arSchedule.add(rs1.getString(9));
                        arSchedule.add(rs1.getString(10));
                        arSchedule.add(rs1.getString(11));
                       
                    }
                    rs1.close();


                    request.setAttribute("StartDate",strStartDate1);
                     request.setAttribute("EndDate",strEndDate1);
                      request.setAttribute("arSchedule",arSchedule);
                     view = request.getRequestDispatcher("viewSchedule.jsp");                
                    view.forward(request, response);
                    }
                 }
            }
        }
catch(Exception e)
{
    //objLog.error("ERROR : "+e);
    view = request.getRequestDispatcher("Failure.jsp");
    view.forward(request, response);
}
finally
{
    db.close();
}
    }
}
