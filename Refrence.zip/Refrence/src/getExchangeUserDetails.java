// Function : get role details from role table
// Author   : Gadha PS, Anju Varghese
// Division : COM/CIG
// Date     : 28/01/2009

import java.io.*;
import java.util.*;
import java.util.Date;
import java.text.*;
import java.lang.String;
import java.sql.*;
import java.net.*;
import javax.servlet.*;
import javax.servlet.http.*;
import org.apache.log4j.Logger;
import dateform.*;

public class getExchangeUserDetails extends HttpServlet {
    
    protected void doGet(HttpServletRequest request, HttpServletResponse response)
    throws ServletException, IOException {
        doPost(request,response);
    }
    
    protected void doPost(HttpServletRequest request, HttpServletResponse response)
    throws ServletException, IOException {
        
        RequestDispatcher view = null;
        PrintWriter out= response.getWriter();
        dbConn db=new dbConn();
        dateformat d1=new dateformat();
       // Logger //objLog = Logger.getLogger("ApplicationDO");
        try
{
            Connection conn= null;
            conn = db.Connect();
            Statement stmt = conn.createStatement();
            ResultSet rs1=null;
            String strFlag="invalidSession",strQuery="";
            String strName="",strStaffcode="",strDutydate="",strShift="",strSex="",strType="Edit";
 
            // Get session
            HttpSession curSession=request.getSession(false);
            // Check if valid session
            if(curSession==null)
{
                //objLog.error("Invalid session");
                request.setAttribute("flag",strFlag);
                view=request.getRequestDispatcher("sessionError.jsp");
                view.forward(request, response);
            }
            
            else //valid session
            {
                if((String)curSession.getAttribute("userid")==null)
{
                    //objLog.error("Invalid session");
                    request.setAttribute("flag",strFlag);
                    view=request.getRequestDispatcher("sessionError.jsp");
                    view.forward(request, response);
                }
                else
                {
                     strStaffcode= request.getParameter("cboStaffcode");
             //objLog.info("cbo staff code "+strStaffcode);
                    //check if staffcode="select"
                    if (strStaffcode.equals("Select")) //reset values
                    {
                        strName="";
                        strDutydate="";
                        strShift="";
                        strSex="";
                       
                    }
                    else
                    {
                       strQuery = "SELECT scheduledate,a.shift,empname,sex FROM doschedule a, dodetails b where a.empcode='"+strStaffcode+"' and b.empcode='"+strStaffcode+"'";
                        rs1=stmt.executeQuery(strQuery);
                        //objLog.info("strQuery inside exchaage details java "+strQuery);
                        while (rs1.next())
                        {
                            strDutydate= rs1.getString(1);
                            strShift = rs1.getString(2);
                            strName = rs1.getString(3);
                           strSex = rs1.getString(4);
                          
                        }
                        rs1.close();
                        
                    }     
                     
                    request.setAttribute("strDutydate",strDutydate); 
                    request.setAttribute("strName",strName);  
                    request.setAttribute("strsex",strSex);        
                    request.setAttribute("strShift",strShift);     
                    request.setAttribute("Flag",strType);
                    view = request.getRequestDispatcher("exchangeDO.jsp");
                    view.forward(request, response);
                }
            }
        }
catch(Exception e)
{
    //objLog.error("ERROR : "+e);
    view = request.getRequestDispatcher("Failure.jsp");
    view.forward(request, response);
}
finally
{
    db.close();
}
    }
}
