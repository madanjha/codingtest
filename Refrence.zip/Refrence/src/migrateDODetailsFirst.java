// Function : migrate do details from MSSQL to mysql (one time)
// Author   : Gadha PS, Anju Varghese
// Division : COM/CIG
// Date     : 13/03/2009

import java.io.*;
import java.util.*;
import java.sql.*;
import java.net.*;

public class migrateDODetailsFirst {
    
    /** Creates a new instance of migrateDODetails */
     private static Connection mssqlconn = null;
     private static Connection mysqlconn = null;
   
     public migrateDODetailsFirst() {       
        
        try 
        {
              /* Class.forName("com.mysql.jdbc.Driver");
	       String db_user = "root";       //Username in mysql *****************change here***************
	       String db_pass = "123"; //Password for the user in mysql
	       String url="jdbc:mysql://10.43.32.5/lpscdutyofficer"; 
	       mysqlconn =DriverManager.getConnection(url,db_user,db_pass);*/
        	
               Class.forName("com.mysql.jdbc.Driver");
  	       String db_user = "root";       //Username in mysql
  	       String db_pass = "root"; //Password for the user in mysql
  	       String url="jdbc:mysql://127.0.0.1:3306/lpscdutyofficer";
  	       mysqlconn =DriverManager.getConnection(url,db_user,db_pass);
        	
      	}
        catch (Exception e) 
	{
		System.err.println("Connection failed mysql");
		mysqlconn = null;
	}	
        
        try 
        {
              /*  DriverManager.registerDriver(new com.microsoft.jdbc.sqlserver.SQLServerDriver());
                Class.forName("com.microsoft.jdbc.sqlserver.SQLServerDriver").newInstance();
                String url="jdbc:microsoft:sqlserver://10.101.2.107:1434";//*****************change here***************
                // String url="jdbc:microsoft:sqlserver://10.41.6.220:1433";
                String uid="cowaa";
                String pass="antharam";
                mssqlconn = DriverManager.getConnection(url,uid,pass);*/
            
        	
                DriverManager.registerDriver(new net.sourceforge.jtds.jdbc.Driver());
                Class.forName("net.sourceforge.jtds.jdbc.Driver").newInstance();
               // String url="jdbc:jtds:sqlserver://10.101.2.107:1433/cowaa";//*****************change here***************
                String url="jdbc:jtds:sqlserver://10.101.2.141:1433/cowaa";
                String uid="cowaa";
                String pass="antharam";
                mssqlconn = DriverManager.getConnection(url,uid,pass);

                
              /*  DriverManager.registerDriver(new net.sourceforge.jtds.jdbc.Driver());
                Class.forName("net.sourceforge.jtds.jdbc.Driver").newInstance();
                String url="jdbc:jtds:sybase://10.101.2.3:4100/cowaa";//*****************change here***************
                String uid="cowaa";
                String pass="cowaaa";
                mssqlconn = DriverManager.getConnection(url,uid,pass);*/
      	}
        
        catch (Exception e) 
	  {
		 System.err.println("Connection failed mssql");
		 mssqlconn = null;
	  }	
        
    }
    
     public Connection msConnect()
    {       
      //   objLog.info("MSSQL conn: "+mssqlconn);
        return mssqlconn;
    }
    
      public Connection myConnect()
    {       
      //    objLog.info("MySQL conn: "+mysqlconn);
        return mysqlconn;
    }
    
     public void close()
    {
	try 
	{
		mssqlconn.close();
                mysqlconn.close();
	}
	catch (SQLException e) 
	{	
            System.err.println("Connection closing failed");
	    mssqlconn = null;
            mysqlconn = null;
	}
    }
     
     public static void main(String args[]) 
	{  //Logger objLog = Logger.getLogger("ApplicationDO");
         try
         {
             
               migrateDODetailsFirst migDO=new migrateDODetailsFirst();
	       Connection mssqlconn = migDO.msConnect();
               Statement msstmt = mssqlconn.createStatement();
               Statement msstmt1 = mssqlconn.createStatement();
               Statement msstmt3 = mssqlconn.createStatement();//lpsc
               
               ResultSet msrs=null;
               ResultSet msrs1=null;
               
               ResultSet msrs2=null;//lpsc
               ResultSet msrs3=null;//lpsc
                
                Connection mysqlconn = migDO.myConnect();
                
           //     objLog.info("MSSQL conn: "+mssqlconn);
           //     objLog.info("MySQL conn: "+mysqlconn);
                Statement mystmt =  mysqlconn.createStatement();
                Statement mystmt1 = mysqlconn.createStatement();
                Statement mystmt4 = mysqlconn.createStatement(); //lpssc
                Statement mystmt3 = mysqlconn.createStatement(); //lpssc
                
                ResultSet myrs=null;
                ResultSet myrs1=null;
                
                String strQuery="", strEmpcode="",strSex="",strShift="", strEmpname="", strDiv="", strDesg="", strPhone="";
                String strHouseno="", strHouseName="", strStreet="", strPlace="", strCity="", strDis="", strPin="",strUsername="",strPassword="";
                int strDob=0;
                
		if (mssqlconn != null && mysqlconn != null) 
		{
                    //clear migratedemplist table
                   mystmt.executeUpdate("delete from migratedemplist");
                    
                    //get do details from mssql
                    //query to get deatils from mssql
                 //   strQuery="SELECT  distinct TBAD_BIODATA.EMPLOYEECODE ,TBAD_EMPLOYEE.SALUTATIONCODE ,TBAD_EMPLOYEE.EMPLOYEENAME ,TBAD_DIVISION.DIVNSHORTNAME ,TBAD_DESIGNATIONS.DESGSHORTNAME , TBAD_BIODATA.SEX , TBAD_BIODATA.DATEOFBIRTH ,TBAD_BIODATA.CONTACTPHONE "; 
                 //   strQuery=strQuery+" FROM TBAD_BIODATA ,  TBAD_DESIGNATIONS , TBAD_DIVISION ,  TBAD_EMPLOYEE ,  TBAD_CAREER WHERE ( TBAD_DIVISION.DIVNCODE = TBAD_EMPLOYEE.DIVNCODE ) and  ( TBAD_EMPLOYEE.EMPLOYEECODE = TBAD_BIODATA.EMPLOYEECODE ) and  ( TBAD_EMPLOYEE.GRADECODE = TBAD_DESIGNATIONS.GRADECODE ) and  ( TBAD_EMPLOYEE.DESGCODE = TBAD_DESIGNATIONS.DESGCODE)";
                 //   strQuery=strQuery+" and  ( TBAD_EMPLOYEE.PAYCOMMISSIONNO = TBAD_DESIGNATIONS.PAYCOMMISSIONNO ) and  ( TBAD_EMPLOYEE.EMPLOYEECODE = TBAD_CAREER.EMPLOYEECODE )  and  (TBAD_EMPLOYEE.SERVICESTATCODE = 'SERV' ) and   ( TBAD_DIVISION.ENTITYCODE not in ('82','83','84','70','45') ) and   ( TBAD_DIVISION.DIVNCODE not in ('VS3543','VS6511') ) and  ( (datediff( YEAR,DATEOFBIRTH,GETDATE()) <55)  or ((datediff( YEAR,DATEOFBIRTH,GETDATE()) = 55) and (MONTH(DATEOFBIRTH) > MONTH(GETDATE())))  ) and  ";
                 //   strQuery=strQuery+"((TBAD_EMPLOYEE.DESGCODE in ('1103','1104','5409','5512','5410','5399','5502','5400','5540','5543','5450','5451') ) or (  ((TBAD_EMPLOYEE.DESGCODE in ( '1102' ) ) and ( (datediff( YEAR,TBAD_CAREER.DESGATTAINEDDT,GETDATE()) > 3) or ((datediff( YEAR,TBAD_CAREER.DESGATTAINEDDT,GETDATE()) = 3)  and (MONTH(TBAD_CAREER.DESGATTAINEDDT) < MONTH(GETDATE()) )) and   ( TBAD_CAREER.DESGCODE = '1102' ) )) ))";
                  
                   // [To Exclude IOC Members & RESIDENT ENGINEERS  from DO List] TBAD_EMPLOYEE.EMPLOYEECODE not in('LV62430','LV23022','LV25376','LV61815','LV63683','LV62452','LV62449','VS22064','LV60013','LV66025','LV60082','LV62000','LV63443','LV21962','LV67823','LV67853','LV63453','LV24093','LV67836','LM67743'))
                   //[IOC Members]  TBAD_EMPLOYEE.EMPLOYEECODE not in('LV62430','LV23022','LV25376','LV61815','LV63683','LV62452','LV62449','VS22064','LV60013'))
                   //[ RESIDENT ENGINEERS]  TBAD_EMPLOYEE.EMPLOYEECODE not in('LV66025','LV60082','LV62000','LV63443','LV21962','LV67823','LV67853','LV63453','LV24093','LV67836','LM67743'))
                   
                   strQuery="SELECT  distinct TBAD_BIODATA.EMPLOYEECODE ,TBAD_EMPLOYEE.SALUTATIONCODE ,TBAD_EMPLOYEE.EMPLOYEENAME ,TBAD_DIVISION.DIVNSHORTNAME ,TBAD_DESIGNATIONS.DESGSHORTNAME , TBAD_BIODATA.SEX , TBAD_BIODATA.DATEOFBIRTH ,TBAD_BIODATA.CONTACTPHONE "; 
                   strQuery=strQuery+" FROM TBAD_BIODATA ,  TBAD_DESIGNATIONS , TBAD_DIVISION ,  TBAD_EMPLOYEE, TBAD_CAREER WHERE ( TBAD_DIVISION.DIVNCODE = TBAD_EMPLOYEE.DIVNCODE ) and  ( TBAD_EMPLOYEE.EMPLOYEECODE = TBAD_BIODATA.EMPLOYEECODE ) and  ( TBAD_EMPLOYEE.GRADECODE = TBAD_DESIGNATIONS.GRADECODE ) and  ( TBAD_EMPLOYEE.DESGCODE = TBAD_DESIGNATIONS.DESGCODE)";
                   strQuery=strQuery+" and  ( TBAD_EMPLOYEE.PAYCOMMISSIONNO = TBAD_DESIGNATIONS.PAYCOMMISSIONNO )  and  ( TBAD_EMPLOYEE.EMPLOYEECODE = TBAD_CAREER.EMPLOYEECODE )and (TBAD_BIODATA.HANDICAPCODE IN('NONE','NULL',''))  and (TBAD_EMPLOYEE.SERVICESTATCODE in ('SERV', 'PROB')) and  ( (datediff( YEAR,DATEOFBIRTH,GETDATE()) <55)  or ((datediff( YEAR,DATEOFBIRTH,GETDATE()) = 55) and (MONTH(DATEOFBIRTH) > MONTH(GETDATE())))  ) and  ";
                   strQuery=strQuery+"((TBAD_EMPLOYEE.DESGCODE in ('1102','1103','1104','1105','5409','5410','6285','5399','5502','5400','5540','5543','5450','5451','5399','5438','5400','6451','5441' )))"; 
                   
                   //strQuery=strQuery+"((TBAD_EMPLOYEE.DESGCODE in ('1102','1103','1104','1105','5409','5410','6285','5399','5502','5400','5540','5543','5450','5451','5399','5438','5400','6451','5441' )) and TBAD_EMPLOYEE.EMPLOYEECODE not in('LV62430','LV23022','LV25376','LV61815','LV63683','LV62452','LV62449','VS22064','LV60013','LV66025','LV60082','LV62000','LV63443','LV21962','LV67823','LV67853','LV63453','LV24093','LV67836','LM67743'))"; 

//strQuery=strQuery+"((TBAD_EMPLOYEE.DESGCODE in ('1102','1103','1104','1105','5409','5512','5410','5511','6275','6285','5399','5502','5400','5540','5543','5450','5451','5399','5438','5400','6454','5441','5439','5750' )))"; 

//strQuery=strQuery+"((TBAD_EMPLOYEE.DESGCODE in ('1102','1103','1104','1105','5409','5512','5410','5511','6275','6285','5399','5502','5400','5540','5543','5450','5451')))";
                   
                   
                //    objLog.info(strQuery);
                    msrs=msstmt.executeQuery(strQuery);
                    while (msrs.next())
                    {                        
                        //Populate migratedemplist with new details
                        strEmpname=msrs.getString(3);
                       
                        
                        //System.out.println(" EMPCODE :: "+msrs.getString(1));
                        //System.out.println(" EMPNAME ::  "+strEmpname);
                        
                        
                        if (strEmpname != null)
                        {
                            strEmpname=strEmpname.replace('\'',' ');
                            strEmpname=strEmpname.replace('"',' ');
                            
                             strEmpname=strEmpname.trim();
                        }                        
                        
                        strDiv=msrs.getString(4);
                       
                        if (strDiv != null)
                        {
                             strDiv=strDiv.replace('\'',' ');
                             strDiv=strDiv.replace('"',' ');
                             
                              strDiv=strDiv.trim();
                        }
                        else
                        {
                            strDiv="";
                        }
                        //System.out.println(" strDiv  ::  "+strDiv); 
                        
                        strDesg=msrs.getString(5);
                        
                        
                        if (strDesg != null)
                        {
                         strDesg=strDesg.replace('\'',' ');
                         strDesg=strDesg.replace('"',' ');
                         
                         strDesg = strDesg.trim();
                        }
                        else
                        {
                            strDesg="";
                        }
                       // System.out.println(" strDesg  ::  "+strDesg); 
                        strPhone=msrs.getString(8);
                        
                        if (strPhone != null)
                        {
                           strPhone=strPhone.replace('\'',' ');
                           strPhone=strPhone.replace('"',' ');
                           //strPhone = strPhone.trim();
                        }
                        else
                        {
                            strPhone="";
                        }
                        
                       
                         
                        strQuery="insert into migratedemplist values('"+msrs.getString(1)+"', '"+msrs.getString(2)+"', '"+strEmpname+"', '"+strDiv+"', '"+strDesg+"', '"+msrs.getString(6)+"', '"+msrs.getString(7)+"', ";
                        strQuery=strQuery+"'"+strPhone+"', '', '', '', '', '', '', '', '')";
                      
                        // System.out.println(" INSERTED ");
                       //   objLog.info(strQuery);
                        mystmt.executeUpdate(strQuery);
                    }
                    msrs.close();
                    
                    
                    
                    
                    
                      /* NEW CODE*/
                      //logindata migration from personal portal
                     
                     mystmt4.executeUpdate("delete from authentication");
                     
                     strQuery="SELECT  distinct  username,password from TAB_VSSCMISLOGIN"; 
                     msrs3=msstmt3.executeQuery(strQuery);
                     while(msrs3.next())
                     {
                     //strUsername="",strPassword=""
                     
                        strUsername = msrs3.getString(1);
                        
                        //strUsername = strUsername.trim();
                        
                        
                        if (strUsername != null)
                        {
                         
                            strUsername=strUsername.replace('\'',' ');
                            strUsername=strUsername.replace('"',' ');
                            
                            strUsername = strUsername.trim();
                            
                        }                        
                        
                        strPassword=msrs3.getString(2);
                        if (strPassword != null)
                        {
                             strPassword=strPassword.replace('\'',' ');
                             strPassword=strPassword.replace('"',' ');
                             //strPassword = strPassword.trim();
                        }
                        else
                        {
                            strPassword="";
                        }
                     
                     
                         strQuery="insert into authentication  values('"+strUsername+"', '"+strPassword+"')";
                         mystmt3.executeUpdate(strQuery);
                  
                     }
                     msrs3.close();
                     
                      /* NEW CODE*/
                    
                    //insert in dodetails                       
                   // strQuery="select * from migratedemplist where datediff(curdate(),date_add(dob, INTERVAL 55 year))>0 or (datediff(curdate(),date_add(dojoin, INTERVAL 55 year))<0 and UCASE(designation) = 'SCI/ENG.SC')";
                     
                    strQuery="select * from migratedemplist";
                    myrs=mystmt.executeQuery(strQuery);
                    while (myrs.next())
                    {     
                          strEmpcode=myrs.getString("empcode");   
                          if (strEmpcode != null)
                                {
                                 strEmpcode =strEmpcode.trim();
                                }
                          
                          // update his address details in migratedemplist
                          //strQuery="select HOUSENUMBER,HOUSENAME,STREETNAME,PLACENAME,CITYNAME,DISTRICT,PINCODE, STATECODE from TBAD_EMPADDRESS  where addresstype='RESDN' and employeecode='"+strEmpcode+"' and empaddresskeyno in (select max(empaddresskeyno) from TBAD_EMPADDRESS  where addresstype='RESDN' and employeecode='"+strEmpcode+"')";
                          strQuery="select HOUSENUMBER,HOUSENAME,STREETNAME,PLACENAME,CITYNAME,DISTRICT,PINCODE, STATECODE from TBAD_EMPADDRESS  where ADDRESSTYPE='RESDN' and EMPLOYEECODE='"+strEmpcode+"' and EMPADDRESSKEYNO in (select max(EMPADDRESSKEYNO) from TBAD_EMPADDRESS  where ADDRESSTYPE='RESDN' and EMPLOYEECODE='"+strEmpcode+"')";
                          msrs=msstmt.executeQuery(strQuery);
                           if(msrs.next())
                           {
                               strHouseno = msrs.getString(1);
                               //strHouseno = strHouseno.trim();
                               
                               if(strHouseno != null)
                                {
                                  strHouseno=strHouseno.replace('\'',' ');
                                  strHouseno=strHouseno.replace('"',' ');
                                  
                                  strHouseno = strHouseno.trim();
                               } 
                               else
                               {
                                   strHouseno="";
                               }
                                
                               strHouseName = msrs.getString(2);
                               //strHouseName = strHouseName.trim();
                               
                               if (strHouseName != null)
                                {
                                  strHouseName=strHouseName.replace('\'',' ');
                                  strHouseName=strHouseName.replace('"',' ');
                                  
                                  strHouseName= strHouseName.trim();
                               }
                               else
                               {
                                   strHouseName="";
                               }
                                
                               strStreet=msrs.getString(3);
                              // strStreet = strStreet.trim();
                               if (strStreet != null)
                                {
                                   strStreet=strStreet.replace('\'',' ');
                                   strStreet=strStreet.replace('"',' ');
                                   
                                   //strStreet = strStreet.trim();
                               }
                               else
                               {
                                   strStreet="";
                               }
                                
                               strPlace=msrs.getString(4);
                               
                               //strPlace = strPlace.trim();
                               
                               if (strPlace != null)
                                {
                                   strPlace=strPlace.replace('\'',' ');
                                   strPlace=strPlace.replace('"',' ');
                                   
                                   //strPlace = strPlace.trim();
                               }
                               else
                               {
                                   strPlace="";
                               }
                               
                                
                               strCity=msrs.getString(5);
                               //strCity = strCity.trim();
                               if (strCity != null)
                                {
                                   strCity=strCity.replace('\'',' ');
                                   strCity=strCity.replace('"',' ');
                                   
                                   //strCity = strCity.trim();
                               }
                               else
                               {
                                   strCity="";
                               }
                                
                               strDis=msrs.getString(6);
                               //strDis = strDis.trim();
                               if (strDis != null)
                                {
                                  strDis=strDis.replace('\'',' ');
                                  strDis=strDis.replace('"',' ');
                                  
                                  //strDis = strDis.trim();
                               }
                               else
                               {
                                   strDis="";
                               }
                                
                               strPin=msrs.getString(7);
                               //strPin=strPin.trim();
                               if (strPin != null)
                                {
                                   strPin=strPin.replace('\'',' ');
                                   strPin=strPin.replace('"',' ');
                                   
                                   
                                   //strPin = strPin.trim();
                               }
                               else
                               {
                                   strPin="";
                               }
                               
                                
                               
                                  strQuery="update migratedemplist set housenumber='"+strHouseno+"', housename='"+strHouseName+"', streetname='"+strStreet+"', placename='"+strPlace+"', cityname='"+strCity+"', district='"+strDis+"', pincode='"+strPin+"', ";
                                  strQuery=strQuery+" state='"+msrs.getString(8)+"' WHERE empcode='"+strEmpcode+"'";
                                  mystmt1.executeUpdate(strQuery);
                           }
                           else
                           {
                               strQuery="select HOUSENUMBER,HOUSENAME,STREETNAME,PLACENAME,CITYNAME,DISTRICT,PINCODE, STATECODE from TBAD_EMPADDRESS  where addresstype='PERMN' and employeecode='"+strEmpcode+"' and empaddresskeyno in (select max(empaddresskeyno) from TBAD_EMPADDRESS  where addresstype='PERMN' and employeecode='"+strEmpcode+"')";
                               msrs1=msstmt1.executeQuery(strQuery);
                               if(msrs1.next())
                               {
                                   strHouseno = msrs1.getString(1);
                                   //strHouseno =strHouseno.trim();
                                   if (strHouseno != null)
                                    {
                                      strHouseno=strHouseno.replace('\'',' ');
                                      strHouseno=strHouseno.replace('"',' ');
                                      
                                      strHouseno= strHouseno.trim();
                                    }    
                                   else
                                   {
                                       strHouseno="";
                                   }

                                   strHouseName = msrs1.getString(2);
                                   //strHouseName = strHouseName.trim();
                                   if (strHouseName != null)
                                    {
                                      strHouseName=strHouseName.replace('\'',' ');
                                      strHouseName=strHouseName.replace('"',' ');
                                      
                                      strHouseName = strHouseName.trim();
                                   }
                                   else
                                   {
                                       strHouseName="";
                                   }

                                   strStreet=msrs1.getString(3);
                                   //strStreet = strStreet.trim();
                                   if (strStreet != null)
                                    {
                                      strStreet=strStreet.replace('\'',' ');
                                      strStreet=strStreet.replace('"',' ');
                                      
                                      //strStreet = strStreet.trim();
                                   }
                                   else
                                   {
                                       strStreet="";
                                   }

                                   strPlace=msrs1.getString(4);
                                   //strPlace = strPlace.trim();
                                   if (strPlace != null)
                                    {
                                    strPlace=strPlace.replace('\'',' ');
                                    strPlace=strPlace.replace('"',' ');
                                    
                                    //strPlace = strPlace.trim();
                                   }
                                   else
                                   {
                                       strPlace="";
                                   }

                                   strCity=msrs1.getString(5);
                                   //strCity = strCity.trim();
                                   if (strCity != null)
                                    {
                                      strCity=strCity.replace('\'',' ');
                                      strCity=strCity.replace('"',' ');
                                      
                                      
                                      //strCity = strCity.trim();
                                    }
                                   else
                                   {
                                       strCity="";
                                   }

                                   strDis=msrs1.getString(6);
                                   //strDis= strDis.trim();
                                   if (strDis != null)
                                    {
                                     strDis=strDis.replace('\'',' ');
                                     strDis=strDis.replace('"',' ');
                                     
                                     //strDis= strDis.trim();
                                   }
                                   else
                                   {
                                       strDis="";
                                   }

                                   strPin=msrs1.getString(7);
                                   //strPin = strPin.trim();
                                   if (strPin != null)
                                    {
                                      strPin=strPin.replace('\'',' ');
                                      strPin=strPin.replace('"',' ');
                                      
                                      //strPin = strPin.trim();
                                   }
                                   else
                                   {
                                       strPin="";
                                   }
                                   
                                     strQuery="update migratedemplist set housenumber='"+strHouseno+"', housename='"+strHouseName+"', streetname='"+strStreet+"', placename='"+strPlace+"', cityname='"+strCity+"', district='"+strDis+"', pincode='"+strPin+"', ";
                                     strQuery=strQuery+" state='"+msrs1.getString(8)+"' WHERE empcode='"+strEmpcode+"'";
                                     mystmt1.executeUpdate(strQuery);
                                 }
                               
                                msrs1.close();
                           }
                                msrs.close();                                
                    }
                        
                    myrs.close();
                    
                  
                    // select from migratedemplist to populate dodetails
                    
                    strQuery="select * from migratedemplist order by empname";
                    myrs=mystmt.executeQuery(strQuery);
                    while (myrs.next())
                    {     
                            strQuery="select datediff(curdate(),date_add('"+myrs.getString("dob")+"', INTERVAL 50 year))"; 
                            myrs1=mystmt1.executeQuery(strQuery);
                            if(myrs1.next())
                            {  
                                strDob=myrs1.getInt(1);
                                if(strDob>=0 || myrs.getString("sex").equals("F"))
                                {
                                    strShift="FIRST";
                                }
                                else
                                {
                                     strShift="ANY";
                                }
                                
                            }
                            myrs1.close();
                            
                            strQuery="select * from dodetails where empcode='"+myrs.getString(1)+"' ";
                            
                            myrs1=mystmt1.executeQuery(strQuery);
                           
                            if (myrs1.next())
                            {
                            }
                            else
                            {
                              strQuery="insert into dodetails  values('"+myrs.getString(1)+"','"+myrs.getString(2)+"','"+myrs.getString(3)+"','"+myrs.getString(4)+"','"+myrs.getString(5)+"','"+myrs.getString(6)+"','"+myrs.getString(7)+"','Y','"+strShift+"','0','0','0001-01-01','0001-01-01','')";
                              mystmt1.executeUpdate(strQuery);
                            
                              //insert into doaddress
                              strQuery="insert into doaddress values('"+myrs.getString(1)+"','"+myrs.getString(8)+"','"+myrs.getString(9)+"','"+myrs.getString(10)+"','"+myrs.getString(11)+"','"+myrs.getString(12)+"','"+myrs.getString(13)+"','"+myrs.getString(14)+"','"+myrs.getString(15)+"','"+myrs.getString(16)+"','','','','','') ";
                              mystmt1.executeUpdate(strQuery);
                            }
                             myrs1.close();
                        
                    }
                    myrs.close();
                    
                    //insert into anyshiftdo/firstshiftdo
                    
                    strQuery="insert into anyshiftdo(empcode, prevshift1, prevshift2, prevdutydate, scheduled) select empcode,'','','0000-00-00','N' from dodetails where shift='ANY' order by empname";
                    mystmt.executeUpdate(strQuery);
                    
                    strQuery="insert into firstshiftdo(empcode, prevshift1, prevshift2, prevdutydate, scheduled) select empcode,'','','0000-00-00','N' from dodetails where shift='FIRST' order by empname";
                    mystmt.executeUpdate(strQuery);
                    
                }
		migDO.close();	
                    
	}
         catch(Exception e)
     {
        System.err.println("Exception :: "+e);
        mssqlconn = null;
        mysqlconn = null;
     }
}
}