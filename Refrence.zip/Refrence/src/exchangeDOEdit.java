// Function : get role details from role table
// Author   : Gadha PS, Anju Varghese
// Division : COM/CIG
// Date     : 28/01/2009

import java.io.*;
import java.util.*;
import java.util.Date;
import java.text.*;
import java.lang.String;
import java.sql.*;
import java.net.*;
import javax.servlet.*;
import javax.servlet.http.*;
import org.apache.log4j.Logger;
import dateform.*;



import java.util.Properties;
import javax.mail.Authenticator;
import javax.mail.Message;
import javax.mail.PasswordAuthentication;
import javax.mail.Session;
import javax.mail.Transport;
import javax.mail.internet.InternetAddress;
import javax.mail.internet.MimeMessage;
import java.io.*;

public class exchangeDOEdit extends HttpServlet {
    
    protected void doGet(HttpServletRequest request, HttpServletResponse response)
    throws ServletException, IOException {
        doPost(request,response);
    }
    
    class ThePasswordAuthenticator extends Authenticator {
		String user;
		String pw;
		public ThePasswordAuthenticator(String username, String password) {
			super();
			this.user = username;
			this.pw = password;
		}
		public PasswordAuthentication getPasswordAuthentication() {
			return new PasswordAuthentication(user, pw);
		}
    }
    
    protected void doPost(HttpServletRequest request, HttpServletResponse response)
    throws ServletException, IOException {
        
        RequestDispatcher view = null;
        PrintWriter out= response.getWriter();
        dbConn db=new dbConn();
        dateformat d1=new dateformat();
     //   Logger //objLog = Logger.getLogger("ApplicationDO");
        try
{
            Connection conn= null;
            conn = db.Connect();
            Statement stmt = conn.createStatement();
            ResultSet rs1=null;
            String strFlag="invalidSession";
            ArrayList arSchedule=new ArrayList(); //schedule
            String strShift="",strDutydate="", strQuery="", strStaffcode="", strStartDate="", strEndDate="", mailPath="", strMail="", strExMail="";           
            String strExStaffcode="",strExDutydate="",strExShift="", strPath="",strStartDate1="", strEndDate1="", strConfirm="";
            
            // Get session
            HttpSession curSession=request.getSession(false);
            // Check if valid session
            if(curSession==null)
                {
                //objLog.error("Invalid session");
                request.setAttribute("flag",strFlag);
                view=request.getRequestDispatcher("sessionError.jsp");
                view.forward(request, response);
              }
            
            else //valid session
            {
                if((String)curSession.getAttribute("userid")==null)
                {
                    //objLog.error("Invalid session");
                    request.setAttribute("flag",strFlag);
                    view=request.getRequestDispatcher("sessionError.jsp");
                    view.forward(request, response);
                }
                 else
                {
                    strPath= request.getParameter("path");
                    //objLog.info("Path: "+strPath);
                    
                    strStartDate1=request.getParameter("strStartDate");
                    strStartDate=d1.savedate(strStartDate1);
                    strEndDate1=request.getParameter("strEndDate");  
                    strEndDate=d1.savedate(strEndDate1);
                    
                    if (strPath.equals("exchange"))
                    {
                    
                    strStaffcode=request.getParameter("strStaffcode");
                    strShift=request.getParameter("newShift");
                    strDutydate=request.getParameter("newDate");  
                    strDutydate=d1.savedate(strDutydate);
                   
                    strExStaffcode=request.getParameter("cboStaffcode");
                    strExShift=request.getParameter("txtShift");
                    strExDutydate=request.getParameter("txtDate");  
                    strExDutydate=d1.savedate(strExDutydate);                  
                                            
                    
                    //objLog.info("Exchange Dates");
                    strQuery = "update doschedule set scheduledate='"+strExDutydate+"', shift='"+strExShift+"' where empcode='"+strStaffcode+"' and scheduledate='"+strDutydate+"' ";
                    stmt.executeUpdate(strQuery);
                    //objLog.info(strQuery);
                    
                    strQuery = "update doschedule set scheduledate='"+strDutydate+"', shift='"+strShift+"' where empcode='"+strExStaffcode+"' and scheduledate='"+strExDutydate+"'";
                    stmt.executeUpdate(strQuery);
                    //objLog.info(strQuery);
                    
                    //reset exchange flag to 0 
                    
                    stmt.executeUpdate("update exchangedo set exchangeflag ='0' where empcode1='"+strStaffcode+"' or empcode2='"+strExStaffcode+"' or empcode2='"+strStaffcode+"' or empcode1='"+strExStaffcode+"'");
                          
                    //reset confirm flag
                    
                    stmt.executeUpdate("update doschedule set confirm='N' where empcode='"+strStaffcode+"' or empcode='"+strExStaffcode+"'");
                   
                   
                    strQuery="select email from empemail where scno='"+strStaffcode+"'";
                    rs1=stmt.executeQuery(strQuery);
                    if (rs1.next())
                    {
                        strMail=rs1.getString(1);
                    }
                    else
                    {
                        strMail="NO_EMAIL";
                    }
                    rs1.close();

                    strQuery="select email from empemail where scno='"+strExStaffcode+"'";
                    rs1=stmt.executeQuery(strQuery);
                    if (rs1.next())
                    {
                        strExMail=rs1.getString(1);
                    }
                    else
                    {
                        strExMail="NO_EMAIL";
                    }
                    rs1.close();
                    
                    //check if confirmed                    
                                       
                        //send mail to both
                    
                     strExDutydate=d1.datedisplay(strExDutydate);
                     strDutydate=d1.datedisplay(strDutydate);

                    //mailPath="http://10.41.6.137:8080/VDOS/aoe.do?emailid1="+strMail+"&dutydate1="+strExDutydate+"&shift1="+strExShift+"&emailid2="+strExMail+"&dutydate2="+strDutydate+"&shift2="+strShift;
                    
                     /*NEW CODE Modified on 08-01-10 */
                     ///////////////////////START ////////////////////////////////
                     ////////////////////////To strMAIL///////////////////////////////
                      ///////////////////////////////////////////////////////
                     ///////////////////////////////////////////////////////
                        String mailer = "myprogram";
			//comma separated list of recipients.
			//String to = "shiny@lpscv.dos.gov.in";
			String cc = null;
			String bcc = null;
			String from = "doadmin@lpscv.dos.gov.in";
			String subject ="(TESTING -Please ignore this mail) LPSC Duty Officer System � Intimation of revised schedule";
			
                        String smtpserver = "lpscv.dos.gov.in";
			String smtpport = "25";
			//my username for smtp.att.yahoo.com was a fully
			//qualified email, like joel@att.com.
			String user = "doadmin";
			//String password = "s1s2i3";
			String password = "lpsc1234";
                        Properties props = new Properties();
			//default to "localhost"
			props.put("mail.smtp.host", smtpserver);
			//default to "25"
			props.put("mail.smtp.port", smtpport);
			//uncomment to turn on debugging output which can be useful.
			//props.put("mail.debug", "true");
			//javax.mail.Session
			
			Session session = null;
			if (user != null && password != null)
                        {
                                    props.put("mail.smtp.auth", "true");
                                    session =Session.getInstance(props,new ThePasswordAuthenticator(user,password));
			}
                    
                         Message msg = new MimeMessage(session);
                         try
                         {
		         
                             String body = "Sir/Madam,\r\n"+
			     " (TESTING -PLEASE IGNORE THIS MAIL )Your Duty Officer schedule has been revised as below:\r\n";
                             
                              String bodydate=body + "Schedule date: " +strExDutydate+"\n";
                              String bodyshift=bodydate + "Shift : " +strExShift+"\n";
                              
                              String bodyappnd= "To access LPSC Duty officer System(LDOS) click on the link below: \n"+
                                                //"http://10.101.2.153:8080/LPSCDOS/login.jsp \n"+
                                                "http://X/LPSCDOS/login.jsp \n"+
                                                 "Please login to the above system to confirm/exchange your duty.\n"+
                                                 "\n Regards \n"+
                                                 "System Administrator"+
                                                 "NOTE:- This is an auto-generated mail. Do not reply to this mail.";
                               

                            String bodyfirst= bodyshift + bodyappnd;    

                            msg.setFrom(new InternetAddress(from));
                                                
                            msg.setRecipients(Message.RecipientType.TO,InternetAddress.parse(strMail, false));
                            if (cc != null)
                            msg.setRecipients(Message.RecipientType.CC,InternetAddress.parse(cc, false));
                            if (bcc != null)
                            msg.setRecipients(Message.RecipientType.BCC,InternetAddress.parse(bcc, false));
                            //subject line.
                            msg.setSubject(subject);
                            //set the body of the message, also consider setContent()
                            //for Multipart content
                            msg.setText(bodyfirst);
                            //the name of your program.
                            msg.setHeader("X-Mailer", mailer);
                            //Date sent from this computer.
                            msg.setSentDate(new Date());
                            // send the message!
                            Transport.send(msg);
                            System.out.println("\nMail was sent successfully.");
            
                            
                            
                     ///////////////////////END ////////////////////////////////
                     ////////////////////////To strMAIL///////////////////////////////
                      ///////////////////////////////////////////////////////
                     ///////////////////////////////////////////////////////
                            
                       ///////////////////////START ////////////////////////////////
                     ////////////////////////To strExchnngeMAIL///////////////////////////////
                      ///////////////////////////////////////////////////////
                     ///////////////////////////////////////////////////////
                           // mailPath="http://10.41.6.137:8080/VDOS/aoe.do?emailid1="+strMail+"&dutydate1="+strExDutydate+"&shift1="+strExShift+"&emailid2="+strExMail+"&dutydate2="+strDutydate+"&shift2="+strShift;
                            
                              String  bodydate2=body + "Schedule date: " +strDutydate;
                              bodydate2=bodydate2 + "Shift : " +strShift;
                              
                              String bodysecond= bodydate2 + bodyappnd;    
                              
                            msg.setRecipients(Message.RecipientType.TO,InternetAddress.parse(strExMail, false));
                            if (cc != null)
                            msg.setRecipients(Message.RecipientType.CC,InternetAddress.parse(cc, false));
                            if (bcc != null)
                            msg.setRecipients(Message.RecipientType.BCC,InternetAddress.parse(bcc, false));
                            //subject line.
                            msg.setSubject(subject);
                            //set the body of the message, also consider setContent()
                            //for Multipart content
                            msg.setText(bodysecond);
                            //the name of your program.
                            msg.setHeader("X-Mailer", mailer);
                            //Date sent from this computer.
                            msg.setSentDate(new Date());
                            // send the message!
                            Transport.send(msg);
                            System.out.println("\nMail was sent successfully.");
                     
                      }
                      catch (Exception e) 
                      {
			 
                         System.out.println("Error: " + e.getMessage());
                        // view = request.getRequestDispatcher("requestExchangeDOExptMailLPSC.jsp"); 
                         view = request.getRequestDispatcher("requestExchangeDOMailNotSndLPSC.jsp");
                         view.forward(request, response);
		      }
                         
                       ///////////////////////END ////////////////////////////////
                       ////////////////////////To strExchnngeMAIL///////////////////////////////
                       ///////////////////////////////////////////////////////
                      ///////////////////////////////////////////////////////    
                    /* NEW CODE Modified on 08-01-10 */





                     //objLog.info(" PATH for sending mail : "+mailPath);
                     //response.sendRedirect(mailPath);
                        
                    //redirect to exchangeMailsent.jsp
                         
                    view = request.getRequestDispatcher("exchangeMailsent.jsp");                
                    view.forward(request, response);
                    
                    }
                    else
                    {
                      view = request.getRequestDispatcher("getScheduleEdit.do");                
                      view.forward(request, response);
                    }

                 }
            }
        }
catch(Exception e)
{
    //objLog.error("ERROR : "+e);
    view = request.getRequestDispatcher("Failure.jsp");
    view.forward(request, response);
}
finally
{
    db.close();
}
    }
}
