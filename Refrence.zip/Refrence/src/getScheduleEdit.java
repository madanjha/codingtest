// Function : get role details from role table
// Author   : Gadha PS, Anju Varghese
// Division : COM/CIG
// Date     : 28/01/2009

import java.io.*;
import java.util.*;
import java.util.Date;
import java.text.*;
import java.lang.String;
import java.sql.*;
import java.net.*;
import javax.servlet.*;
import javax.servlet.http.*;
import org.apache.log4j.Logger;
import dateform.*;

public class getScheduleEdit extends HttpServlet {
    
    protected void doGet(HttpServletRequest request, HttpServletResponse response)
    throws ServletException, IOException {
        doPost(request,response);
    }
    
    protected void doPost(HttpServletRequest request, HttpServletResponse response)
    throws ServletException, IOException {
        
        RequestDispatcher view = null;
        PrintWriter out= response.getWriter();
        dbConn db=new dbConn();
        dateformat d1=new dateformat();
     //   Logger //objLog = Logger.getLogger("ApplicationDO");
        try
{
            Connection conn= null;
            conn = db.Connect();
            Statement stmt = conn.createStatement();
            Statement stmt2 = conn.createStatement();
            ResultSet rs1=null, rs2=null;
            String strFlag="invalidSession";
            ArrayList arSchedule=new ArrayList(); //schedule
            String strStartDate1="", strStartDate="",strEndDate1="",strEndDate="", strQuery="", strPath="", strDOConfirm="", strScheduleConfirm="";
             
            // Get session
            HttpSession curSession=request.getSession(false);
            // Check if valid session
            if(curSession==null)
{
                //objLog.error("Invalid session");
                request.setAttribute("flag",strFlag);
                view=request.getRequestDispatcher("sessionError.jsp");
                view.forward(request, response);
            }
            
            else //valid session
            {
                if((String)curSession.getAttribute("userid")==null)
{
                    //objLog.error("Invalid session");
                    request.setAttribute("flag",strFlag);
                    view=request.getRequestDispatcher("sessionError.jsp");
                    view.forward(request, response);
                }
                else
                {             
                    
                    //allow edit for current date to maximum schedule date
                        strQuery="select curdate(), enddate, confirm from scheduledetails where status='NEW'";
                        rs1=stmt.executeQuery(strQuery);
                        if (rs1.next())
                        {
                            strStartDate=rs1.getString(1);        
                            strStartDate1=d1.datedisplay(strStartDate);
                            strEndDate=rs1.getString(2);
                            strEndDate1=d1.datedisplay(strEndDate);     
                            strScheduleConfirm=rs1.getString(3);
                            //objLog.info("Schedule confirm: "+strScheduleConfirm);
                        }                        
                        rs1.close();                                             
                   
                    //select schedule list
                        
                        strQuery = "SELECT scheduledate,dayofweek(scheduledate),a.shift,empname,a.empcode,c.division,sex,designation,sittingphone,resphone,mobile,confirm ";
                        strQuery = strQuery + "FROM doschedule a, doaddress b, dodetails c where (a.scheduledate between '"+strStartDate+"' and '"+strEndDate+"') and ";
                        strQuery = strQuery + "a.empcode=b.empcode  and a.empcode=c.empcode order by scheduledate, a.shift,empname";
                        rs1=stmt.executeQuery(strQuery);
                        
                        //objLog.info(strQuery);
                        
                        while (rs1.next())
                        {                           
                            
                            arSchedule.add(d1.datedisplay(rs1.getString(1)));
                            arSchedule.add(rs1.getString(2));
                            arSchedule.add(rs1.getString(3));
                            arSchedule.add(rs1.getString(4));
                            arSchedule.add(rs1.getString(5));
                            arSchedule.add(rs1.getString(6));
                            arSchedule.add(rs1.getString(7));
                            
                            //get email id
                            strQuery="select email from empemail where scno='"+rs1.getString(5)+"'";
                            rs2=stmt2.executeQuery(strQuery);
                            if (rs2.next())
                            {
                                arSchedule.add(rs2.getString(1));
                            }
                            else
                            {
                                arSchedule.add("NIL");
                            }
                            rs2.close();
                            
                             arSchedule.add(rs1.getString(8));
                             arSchedule.add(rs1.getString(9));
                             arSchedule.add(rs1.getString(10));
                             arSchedule.add(rs1.getString(11)); 
                             arSchedule.add(rs1.getString(12));                                                        
                        }
                        
                        rs1.close();                        
                       
                        
                         request.setAttribute("StartDate",strStartDate1);
                         request.setAttribute("EndDate",strEndDate1);
                         request.setAttribute("scheduleConfirm",strScheduleConfirm);
                         request.setAttribute("arSchedule",arSchedule);
                         view = request.getRequestDispatcher("editScheduleAO.jsp");                
                         view.forward(request, response);
                    
                }
            }
        }
 catch(Exception e)
  {
    //objLog.error("ERROR : "+e);
    view = request.getRequestDispatcher("Failure.jsp");
    view.forward(request, response);
 }
finally
{
    db.close();
}
    }
}
