/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
// Function : get new user details from sysuser table
// Author   : Gadha PS, Anju Varghese
// Division : COM/CIG
// Date     : 28/01/2009

import java.io.*;
import java.util.*;
import java.util.Date;
import java.text.*;
import java.lang.String;
import java.sql.*;
import java.net.*;
import javax.servlet.*;
import javax.servlet.http.*;
import org.apache.log4j.Logger;
import dateform.*;
public class getAllWIC extends HttpServlet {

    protected void doGet(HttpServletRequest request, HttpServletResponse response)
    throws ServletException, IOException {
        doPost(request,response);
    }

    protected void doPost(HttpServletRequest request, HttpServletResponse response)
    throws ServletException, IOException {

        RequestDispatcher view = null;
        PrintWriter out= response.getWriter();
        dbConn db=new dbConn();
         dateformat d1=new dateformat();
     //   Logger //objLog = Logger.getLogger("ApplicationDO");
        String strQuery="",newWIC="";
        try
        {
            Connection conn= null;
            conn = db.Connect();
            Statement stmt = conn.createStatement();
            Statement stmt2 = conn.createStatement();
            Statement stmt3 = conn.createStatement();
            ResultSet rs1=null,rs2=null,rs3=null;
            String strFlag="invalidSession";
            ArrayList arrWIC=new ArrayList();
            String strStartdate="",strEnddate="",startdate="",strScheduletodate="",strEmpcode="",flagviewedit="new",strStartdateView="",strLastdate="";
            int datediff=0,countWIC=5,dayStartdate=0;

            // Get session
            HttpSession curSession=request.getSession(false);
            // Check if valid session
            if(curSession==null)
            {
                //objLog.error("Invalid session");
                request.setAttribute("flag",strFlag);
                view=request.getRequestDispatcher("sessionError.jsp");
                view.forward(request, response);
            }

            else //valid session
            {
              
                strQuery="select startdate , enddate from scheduledetails where status='NEW'";
                //objLog.info(strQuery);
                rs1=stmt.executeQuery(strQuery);
                if(rs1.first())
                {
                    strStartdate=rs1.getString(1);
                    strEnddate=rs1.getString(2);
                }
                rs1.close();
                startdate=strStartdate;
 
                strQuery="select startdate from scheduledetails where status='PREV'";
                //objLog.info(strQuery);
                rs1=stmt.executeQuery(strQuery);
                if(rs1.first())
                {
                    strStartdateView=rs1.getString(1);
                 //   strEnddate=rs1.getString(2);
                }
                rs1.close();

                 

	strQuery="SELECT scheduletodate FROM wicdetails,scheduledetails where datediff(scheduletodate, '"+strEnddate+"' )>=0";
                //objLog.info(strQuery);
                rs1=stmt.executeQuery(strQuery);
                if(rs1.first())
                {
                    flagviewedit="edit";
                     

                }
                rs1.close();

if(flagviewedit.equals("new"))
{
                 strQuery="SELECT DATE_ADD(max(scheduletodate), INTERVAL 1 DAY) from wicdetails;";
                //objLog.info(strQuery);
                rs1=stmt.executeQuery(strQuery);
                if(rs1.first())
                {
                    if(!rs1.getString(1).equals("1000-01-02"))
                    {
                        strStartdate=rs1.getString(1);//if not the first case
                    }

                }
                rs1.close();
                strQuery="select datediff('"+strEnddate+"','"+strStartdate+"'),day('"+strStartdate+"');";
                //objLog.info(strQuery);
                rs1=stmt.executeQuery(strQuery);
                if(rs1.first())
                {
                    datediff=rs1.getInt(1);
	     dayStartdate=rs1.getInt(2);
		
                }
                 rs1.close();

       startdate=strStartdate;
////objLog.info("startdate"+startdate);

              while(datediff>1){
if(dayStartdate>=15)
{
	  strQuery="select LAST_DAY('"+strStartdate+"')";
	//objLog.info(strQuery);
                      rs2=stmt2.executeQuery(strQuery);
                    if(rs2.first())
                    {
	
		strLastdate=rs2.getString(1);
		strQuery="select empcode,max(scheduletodate) from wicdetails group by empcode order by max(scheduletodate)";

		//objLog.info(strQuery);
                             rs1=stmt.executeQuery(strQuery);
                           if(rs1.first())
                            {
                               strEmpcode=rs1.getString(1);
                            //    //objLog.info(strEmpcode);
                           }
                         rs1.close();
		                          
	strQuery="insert into wicdetails values('"+strEmpcode+"','"+strStartdate+"','"+strLastdate+"')";
                          //objLog.info(strQuery);
                          stmt3.executeUpdate(strQuery);

	
	}
rs2.close();
}
else
{
                    strQuery="select DATE_ADD('"+strStartdate+"', interval 14 day),DATE_ADD('"+strStartdate+"', interval 15 day),LAST_DAY('"+strStartdate+"')";
                      //objLog.info(strQuery);
                      rs2=stmt2.executeQuery(strQuery);
                    if(rs2.first())
                    {
                        strScheduletodate=rs2.getString(1);
                        //objLog.info(strScheduletodate);
	                 strLastdate=rs2.getString(3);
                     
                                         
                      
				strQuery="select empcode,max(scheduletodate) from wicdetails group by empcode order by max(scheduletodate)";

				     //objLog.info(strQuery);
                             rs1=stmt.executeQuery(strQuery);
                           if(rs1.first())
                            {
                               strEmpcode=rs1.getString(1);
                              //  //objLog.info(strEmpcode);
                           }
                         rs1.close();
                          
strQuery="insert into wicdetails values('"+strEmpcode+"','"+strStartdate+"','"+strScheduletodate+"')";
                          //objLog.info(strQuery);
                          stmt3.executeUpdate(strQuery);
	strQuery="select empcode,max(scheduletodate) from wicdetails group by empcode order by max(scheduletodate)";

				     //objLog.info(strQuery);
                             rs1=stmt.executeQuery(strQuery);
                           if(rs1.first())
                            {
                               strEmpcode=rs1.getString(1);
                              //  //objLog.info(strEmpcode);
                           }
                         rs1.close();
                          
strQuery="insert into wicdetails values('"+strEmpcode+"','"+rs2.getString(2)+"','"+rs2.getString(3)+"')";
                          //objLog.info(strQuery);
                          stmt3.executeUpdate(strQuery);
                       
                     }
                    rs2.close();
}

strQuery="select DATEDIFF('"+strEnddate+"','"+strLastdate+"'),DATE_ADD('"+strLastdate+"', INTERVAL 1 DAY),day(DATE_ADD('"+strLastdate+"', INTERVAL 1 DAY))";
	//objLog.info(strQuery);
	rs1=stmt.executeQuery(strQuery);
	if(rs1.first())
	{	
		
			datediff=rs1.getInt(1);
////objLog.info("(datediff); "+datediff);

			strStartdate=rs1.getString(2);dayStartdate=rs1.getInt(3);
		
	}


            }
	

             
        }

if(strStartdateView.equals(""))         
			{
				strStartdateView=startdate;
			}
////objLog.info("here2342323");
////objLog.info("strStartdateView "+strStartdateView);
strQuery="select empcode,schedulefromdate,scheduletodate from wicdetails where scheduletodate between '"+strStartdateView+"' and '"+strEnddate+"' or schedulefromdate between '"+strStartdateView+"' and '"+strEnddate+"' and datediff(scheduletodate,'1000-01-01')!=0 order by schedulefromdate";

                        //objLog.info(strQuery);
                        rs2=stmt.executeQuery(strQuery);
                        while(rs2.next())
                        {
                          strQuery="select empname,division from sysuser where empcode='"+rs2.getString("empcode")+"'";
                            //objLog.info(strQuery);
                            rs3=stmt3.executeQuery(strQuery);
                           if(rs3.next())
                           {
                              arrWIC.add(rs2.getString("empcode"));
                              arrWIC.add(rs3.getString("empname"));
                              arrWIC.add(rs3.getString("division"));
                              arrWIC.add(d1.datedisplay(rs2.getString("schedulefromdate")));
                              arrWIC.add(d1.datedisplay(rs2.getString("scheduletodate")));
                           }
                           rs3.close();
                        }

                        rs2.close();


                request.setAttribute("arrWIC",arrWIC);
                view=request.getRequestDispatcher("updateWIC.jsp");
                view.forward(request, response);
   }}
catch(Exception e)
{
    //objLog.error("ERROR : "+e);
    view = request.getRequestDispatcher("Failure.jsp");
    view.forward(request, response);
}
finally
{
    db.close();
}
}
}
