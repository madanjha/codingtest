// Function : get role details from role table
// Author   : Gadha PS, Anju Varghese
// Division : COM/CIG
// Date     : 28/01/2009

import java.io.*;
import java.util.*;
import java.util.Date;
import java.text.*;
import java.lang.String;
import java.sql.*;
import java.net.*;
import javax.servlet.*;
import javax.servlet.http.*;
import org.apache.log4j.Logger;
import dateform.*;

import java.util.Properties;
import javax.mail.Authenticator;
import javax.mail.Message;
import javax.mail.PasswordAuthentication;
import javax.mail.Session;
import javax.mail.Transport;
import javax.mail.internet.InternetAddress;
import javax.mail.internet.MimeMessage;
import java.io.*;

public class confirmSchedule extends HttpServlet {
    
    protected void doGet(HttpServletRequest request, HttpServletResponse response)
    throws ServletException, IOException {
        doPost(request,response);
    }
    
    class ThePasswordAuthenticator extends Authenticator {
		String user;
		String pw;
		public ThePasswordAuthenticator(String username, String password) {
			super();
			this.user = username;
			this.pw = password;
		}
		public PasswordAuthentication getPasswordAuthentication() {
			return new PasswordAuthentication(user, pw);
		}
    }
    protected void doPost(HttpServletRequest request, HttpServletResponse response)
    throws ServletException, IOException {
        
        RequestDispatcher view = null;
        PrintWriter out= response.getWriter();
        dbConn db=new dbConn();
        dateformat d1=new dateformat();
        int intFlgMailError=0;  
      //  Logger //objLog = Logger.getLogger("ApplicationDO");
        try
           {
            Connection conn= null;
            conn = db.Connect();
            Statement stmt = conn.createStatement();
            Statement stmtMaildata = conn.createStatement();
            ResultSet rs1=null;
            //ResultSet rs2=null;
            //String strFlag="invalidSession", sid="", strQuery="", mailPath="";
            String strFlag="invalidSession", strQuery="", mailPath="", strQueryDelete="",strQuerySelect="",strQueryupdate="",strQueryupdate1="";
            String sid="";
            String strEmpcode="",  strShift="", strEmail="",strIsMailSent="";
            Date  date=new Date();
            ArrayList mailData=new ArrayList();
            
            // Get session
            HttpSession curSession=request.getSession(false);
           
            //Check if valid session
            if(curSession==null)
              {
                //objLog.error("Invalid session");
                  request.setAttribute("flag",strFlag);
                  view=request.getRequestDispatcher("sessionError.jsp");
                  view.forward(request, response);
            }
            
            else //valid session
            {
                if((String)curSession.getAttribute("userid")==null)
                 {
                    //objLog.error("Invalid session");
                    request.setAttribute("flag",strFlag);
                    view=request.getRequestDispatcher("sessionError.jsp");
                    view.forward(request, response);
                }
                else
                {
                    //update confirm in scheduledetails to Y
                    // to be done after sending all mails...from mail server
                    //stmt.executeUpdate("update scheduledetails set confirm='Y' where status='NEW'");                    
                  //Iterator ScheduleIterator=mailData.iterator();
                   // ScheduleIterator.
                    //get maximum sid
                    
                    strQuery="select max(scheduleno) from scheduledetails";
                    rs1=stmt.executeQuery(strQuery);
                    if (rs1.next())
                    {
                        sid=rs1.getString(1);
                        //objLog.info("Schedule id to pass to mail: "+sid);
                    }
                    rs1.close();
                    
                    //send mail to all DOs
                    //pass scheduleid as sid	
                    
			//mailPath="http://10.41.6.137:8080/VDOS/dsi.do?sid="+sid;
   			//objLog.info("PATH for sending mail : "+mailPath);			
			//response.sendRedirect(mailPath);			
                    
                          //NEW CODE
                   
                  /*   strQueryDelete="delete from  empemail";
                    stmt.executeQuery(strQueryDelete);
                    //strQuery="insert into empemail(select employeecode,'','',intramailid from tab_empcontactdetails where employeecode in(select empcode from migratedemplist))";
                    rs1=stmt.executeQuery(strQuery);
                    if (rs1.next())
                    {
                       
                         sid=rs1.getString(1);
                        
                        //objLog.info("Schedule id to pass to mail: "+sid);
                    }
                    rs1.close(); 
                   */
                    
                    
                        String mailer = "myprogram";
			//comma separated list of recipients.
			//String to = "shiny@lpscv.dos.gov.in";
			String cc = null;
			String bcc = null;
			//String from = "shiny@lpscv.dos.gov.in";
                        String from = "doadmin@lpscv.dos.gov.in";
                        
			/* String subject = "LPSC Duty Officer System � Intimation of duty(Testing -Please ignore this mail).\r\n";
			 String body = "Sir/Madam ,\r\n"+
                                "Duty Officer System started functioning in LPSC from 20-01-2010 onwards, having two shifts on round-the-clock basis, FIRST shift from 0700 hrs to 1900 hrs, SECOND shift from 1900 hrs to 0700 hrs. \n"+
			        "You are requested to perform DO duty on the date and shift mentioned below:\n";
                               
                        String body1 ="To access LPSC Duty Officer System (LDOS), click on the link below: \n "+
                                       "http://10.101.2.153:8080/LPSCDOS/login.jsp"+
                                        "\n"+
                                       "Please login to the above system to confirm/exchange your duty. In case of unavoidable excuses, please ensure exchange of duty with other officers listed in the roster "+"\n"+
                                       "\n  Regads \n"+
                                       "System Administrator \n"+
                                       "NOTE:- This is an auto-generated mail. Do not reply to this mail.";*/
                                                   
                                
			 String smtpserver = "lpscv.dos.gov.in";
			 String smtpport = "25";
			 //my username for smtp.att.yahoo.com was a fully
			 //qualified email, like joel@att.com.
			 String user = "doadmin";
			 //String password = "s1s2i3";
			 String password = "lpsc1234";
                                                
			Properties props = new Properties();
			//default to "localhost"
			props.put("mail.smtp.host", smtpserver);
			//default to "25"
			props.put("mail.smtp.port", smtpport);
			//uncomment to turn on debugging output which can be useful.
			//props.put("mail.debug", "true");
			//javax.mail.Session
			
			Session session = null;
			if (user != null && password != null) {
				props.put("mail.smtp.auth", "true");
				session =Session.getInstance(props,new ThePasswordAuthenticator(user,password));
			}
                    
			/* else {
			session = Session.getDefaultInstance(props, null);
			}*/
			/*
			* using
			* javax.mail.Message & javax.mail.internet.MimeMessage
			* javax.mail.internet.InternetAddress
			*/
		
                     try 
		      {  
                         ResultSet  rsMailshift=null;
                       
                         //int i=0;
                         //strQuerySelect="select empcode,scheduledate,shift,email from empemail empe,doschedule dos where dos.empcode=empe.scno and dos.scheduleno='"+ sid +"'";
                         
                          strQuerySelect="select empcode,scheduledate,shift,email,ismailsent from empemail empe,doschedule dos where dos.empcode=empe.scno and dos.scheduleno='"+ sid +"'";
                          //select email from empemail e,doschedule d where d.empcode=e.scno and d.scheduleno='1';
                          //rsMailshift=stmt.executeQuery(strQuerySelect);
                          
                          rsMailshift=stmtMaildata.executeQuery(strQuerySelect);
                          
                          //strIsMailSent=rsMailshift.getString("ismailsent");
                         // if(strIsMailSent.equals("N"))
                         //{
           
                             while (rsMailshift.next())
                             {
                       
                               String subject = " (TESTING -PLEASE IGNORE THIS MAIL) LPSC Duty Officer System � Intimation of duty.\r\n";
			       String body = "Sir/Madam ,\r\n"+
                                "(TESTING -PLEASE IGNORE THIS MAIL)Duty Officer System started functioning in LPSC from 09-02-2010 onwards, having two shifts on round-the-clock basis, FIRST shift from 0700 hrs to 1900 hrs, SECOND shift from 1900 hrs to 0700 hrs. \n"+
			        "You are requested to perform DO duty on the date and shift mentioned below:\n";
                               
                               String body1 ="To access LPSC Duty Officer System (LDOS), click on the link below: \n "+
                                       //"http://10.101.2.153:8080/LPSCDOS/login.jsp"+
                                       "http://X/LPSCDOS/login.jsp"+
                                        "\n"+
                                       "Please login to the above system to confirm/exchange your duty. In case of unavoidable excuses, please ensure exchange of duty with other officers listed in the roster "+"\n"+
                                       "\n  Regads \n"+
                                       "System Administrator \n"+
                                       "NOTE:- This is an auto-generated mail. Do not reply to this mail.";
                              
                              
                              
                              
                                 strEmpcode=rsMailshift.getString(1);
                                 date=rsMailshift.getDate(2);
                                 strShift=rsMailshift.getString(3);
                                 strEmail=rsMailshift.getString(4);
                                 strIsMailSent=rsMailshift.getString(5);
                                 
                                 if(strIsMailSent.equals("N"))
                                 {
                                      if(strEmail==null)
                                      {
                                          intFlgMailError=1;
                                          mailData.add(strEmpcode);
                                          mailData.add(strEmail);                               
                                          continue;
                                      }
                                 
                                     if(strEmail.equals("NA") || strEmail.equals("na") || strEmail.equals("nil") || strEmail.equals("Nil") || strEmail.equals(" ") || strEmail.equals(""))
                                     {
                                    
                                     
                                          intFlgMailError=1;
                                          mailData.add(strEmpcode);
                                          mailData.add(strEmail);
                                          continue;
                                     // arSchedule.add(rs1.getString(2));
                                     //arSchedule.add(rs1.getString(3));
                                     // arSchedule.add(rs1.getString(4));
                                     
                                  
                                    }
                                 body=body + "\n Employee code : " + strEmpcode +"\n";
                                 body=body + "\n Schedule date: " + date +"\n";
                                 body=body + "\n Shift : " + strShift +"\n";
                                 body=body + body1;
                        
                       
                                 Message msg = new MimeMessage(session);
                                 msg.setFrom(new InternetAddress(from));
                        
                                /*
                                * Parse the given comma separated sequence of
                                * addresses into an Array of InternetAddress objects
                                * Then set as the desired recipient.
                                */
                        
                                msg.setRecipients(Message.RecipientType.TO,InternetAddress.parse(strEmail, false));
                                if (cc != null)
                                msg.setRecipients(Message.RecipientType.CC,InternetAddress.parse(cc, false));
                                if (bcc != null)
                                msg.setRecipients(Message.RecipientType.BCC,InternetAddress.parse(bcc, false));
                                //subject line.
                                msg.setSubject(subject);
                                //set the body of the message, also consider setContent()
                                //for Multipart content
                                msg.setText(body);
                                //the name of your program.
                                msg.setHeader("X-Mailer", mailer);
                                //Date sent from this computer.
                                msg.setSentDate(new Date());
                                // send the message!
                                Transport.send(msg);
                                System.out.println("\nMail was sent successfully.");
                                                               
                                strQueryupdate = "update doschedule  set ismailsent='Y' where scheduleno='"+ sid +"' and empcode='"+strEmpcode+"'";
                                stmt.executeUpdate(strQueryupdate);
                                
                                
                                subject="";
                                body="";
                                body1="";
                                
                                
                               } //if
                               
                               } //while
                               rsMailshift.close();
                        
// }//if
                        
                        
                   
                        }// 1st try  
                        catch(Exception e)
                        {
                            // mailData.add(strEmpcode);
                            //mailData.add(strEmail);
                            
                            String errmsg = e.getMessage();
                            //System.out.println("Error: " + e.getMessage());
                            intFlgMailError=1;
                            request.setAttribute("error",errmsg);
                            request.setAttribute("Email",strEmpcode);
                            view = request.getRequestDispatcher("requestExchangeDOMailNotSndLPSC.jsp"); 
                            view.forward(request, response);
                           
                        }
                         // strQuery = "update doschedule set scheduledate='"+strDutydate+"', shift='"+strShift+"' where empcode='"+strExStaffcode+"' and scheduledate='"+strExDutydate+"'";
//                         stmt.executeUpdate(strQuery);
                       try
                       {
                        
                        if(intFlgMailError==0)
                        {
                           
                            strQueryupdate1 = "update scheduledetails set confirm='Y' where scheduleno='"+sid +"'";
                            stmt.executeUpdate(strQueryupdate1);
            
                        }
                        
		   }   //2nd TRY
                   catch (Exception e) 
                   {
		       System.out.println("Error: " + e.getMessage());
                   }
                   //NEW CODE
                   //redirect to mailsent.jsp
                       
                        
                    request.setAttribute("mailData",mailData);
                    view=request.getRequestDispatcher("mailsent.jsp");
                    view.forward(request, response);   

                }
            }
        }
catch(Exception e)
{
    //objLog.error("ERROR : "+e);
     String errmsg = e.getMessage();
     
     //System.out.println("Error: " + e.getMessage());
     request.setAttribute("error",errmsg);
     view = request.getRequestDispatcher("FailureLPSC.jsp");
     view.forward(request, response);
}
finally
{
     db.close();
}
    }
}
