/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
// Function : get new user details from sysuser table
// Author   : Gadha PS, Anju Varghese
// Division : COM/CIG
// Date     : 28/01/2009

import java.io.*;
import java.util.*;
import java.util.Date;
import java.text.*;
import java.lang.String;
import java.sql.*;
import java.net.*;
import javax.servlet.*;
import javax.servlet.http.*;
import org.apache.log4j.Logger;

public class getWIC extends HttpServlet {
    
    protected void doGet(HttpServletRequest request, HttpServletResponse response)
    throws ServletException, IOException {
        doPost(request,response);
    }
    
    protected void doPost(HttpServletRequest request, HttpServletResponse response)
    throws ServletException, IOException {
        
        RequestDispatcher view = null;
        PrintWriter out= response.getWriter();
        dbConn db=new dbConn();
    
      //  Logger //objLog = Logger.getLogger("ApplicationDO");
        String strQuery="",newWIC="";
        try
{
            Connection conn= null;
            conn = db.Connect();
            Statement stmt = conn.createStatement();
            Statement stmt2 = conn.createStatement();
            ResultSet rs1=null,rs2=null;
            String strFlag="invalidSession";
            ArrayList arrWIC=new ArrayList();
            ArrayList arrAC=new ArrayList();
            
            // Get session
            HttpSession curSession=request.getSession(false);
            // Check if valid session
            if(curSession==null)
            {
                //objLog.error("Invalid session");
                request.setAttribute("flag",strFlag);
                view=request.getRequestDispatcher("sessionError.jsp");
                view.forward(request, response);
            }
            
            else //valid session
            {
               /* strQuery="select sysuser.empcode,empname,division,designation,offphone,resphone,mobile,datediff(scheduledate,curdate()) from sysuser,iocdetails where sysuser.empcode in(select empcode from iocdetails where datediff(scheduledate,curdate())between -7 and 0) and sysuser.empcode=iocdetails.empcode";
                //objLog.info(strQuery);
                rs1=stmt.executeQuery(strQuery);
                if(rs1.first())
                {
                      arrWIC.add(rs1.getString("empname"));
                      arrWIC.add(rs1.getString("division"));
                      arrWIC.add(rs1.getString("designation"));
                      arrWIC.add(rs1.getString("offphone"));
                      arrWIC.add(rs1.getString("resphone"));
                      arrWIC.add(rs1.getString("mobile"));
                      if(rs1.getInt(7)==0)
                      {
                          strQuery="update iocdetails set prevdutydate=scheduledate where empcode='"+rs1.getString(1)+"'";
                          //objLog.info(strQuery);
                          stmt2.executeUpdate(strQuery);
                      }
                }
                else
                {
                      
                      strQuery="select empcode from iocdetails order by prevdutydate,empcode ";
                      //objLog.info(strQuery);
                      rs2=stmt2.executeQuery(strQuery);
                      if(rs2.first())
                      {
                          newWIC=rs2.getString(1);
                      }
                      rs2.close();
                      strQuery="update iocdetails set scheduledate=curdate() where empcode='"+newWIC+"'";
                      //objLog.info(strQuery);
                      stmt2.executeUpdate(strQuery);
                      strQuery="select empname,division,designation,offphone,resphone,mobile from sysuser where empcode='"+newWIC+"'";
                       //objLog.info(strQuery);
                       rs2=stmt2.executeQuery(strQuery);
                      if(rs2.first())
                    {
                          arrWIC.add(rs2.getString("empname"));
                          arrWIC.add(rs2.getString("division"));
                          arrWIC.add(rs2.getString("designation"));
                          arrWIC.add(rs2.getString("offphone"));
                          arrWIC.add(rs2.getString("resphone"));
                          arrWIC.add(rs2.getString("mobile"));
                    }
                    rs2.close();
                }
                rs1.close();*/
             strQuery="select empname,division,offphone,resphone,mobile from sysuser where empcode in (select empcode from wicdetails where curdate() between schedulefromdate and scheduletodate)";
                       //objLog.info(strQuery);
                       rs2=stmt2.executeQuery(strQuery);
                      if(rs2.first())
                    {
                          arrWIC.add(rs2.getString("empname"));
                          arrWIC.add(rs2.getString("division"));
                       //   arrWIC.add(rs2.getString("designation"));
                          arrWIC.add(rs2.getString("offphone"));
                          arrWIC.add(rs2.getString("resphone"));
                          arrWIC.add(rs2.getString("mobile"));
                    }
                    rs2.close();
                    
                    strQuery="select empname,division,offphone,resphone,mobile from sysuser where role='AO'";
                       //objLog.info(strQuery);
                       rs2=stmt2.executeQuery(strQuery);
                      while (rs2.next())
                    {
                          arrAC.add(rs2.getString("empname"));
                          arrAC.add(rs2.getString("division"));
                       //   arrWIC.add(rs2.getString("designation"));
                          arrAC.add(rs2.getString("offphone"));
                          arrAC.add(rs2.getString("resphone"));
                          arrAC.add(rs2.getString("mobile"));
                    }
                    rs2.close();
                    
                request.setAttribute("arrWIC",arrWIC);
                 request.setAttribute("arrAC",arrAC);
                 //objLog.info(arrAC);
                view=request.getRequestDispatcher("viewWIC.jsp");
                view.forward(request, response);
            }
        }
catch(Exception e)
{
    //objLog.error("ERROR : "+e);
    view = request.getRequestDispatcher("Failure.jsp");
    view.forward(request, response);
}
finally
{
    db.close();
}
}
}
