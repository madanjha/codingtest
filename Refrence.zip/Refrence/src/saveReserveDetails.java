// Function : get role details from role table
// Author   : Gadha PS, Anju Varghese
// Division : COM/CIG
// Date     : 28/01/2009

import java.io.*;
import java.util.*;
import java.util.Date;
import java.text.*;
import java.lang.String;
import java.sql.*;
import java.net.*;
import javax.servlet.*;
import javax.servlet.http.*;
import dateform.*;

public class saveReserveDetails extends HttpServlet {
    
    protected void doGet(HttpServletRequest request, HttpServletResponse response)
    throws ServletException, IOException {
        doPost(request,response);
    }
    
    protected void doPost(HttpServletRequest request, HttpServletResponse response)
    throws ServletException, IOException {
        
        RequestDispatcher view = null;
        PrintWriter out= response.getWriter();
        dbConn db=new dbConn();
        dateformat d1=new dateformat();
   //     Logger objLog = Logger.getLogger("ApplicationDO");
        try
{
            Connection conn= null;
            conn = db.Connect();
            Statement stmt = conn.createStatement();
            Statement stmt1 = conn.createStatement();
            ResultSet rs1=null;
            String strFlag="invalidSession";
            String strStaffcode="", strQuery="", strFlagDO="false",  strFlagReserve="false",strLoginDateTime="";
            String strShift="", strDutyDate="", strName="", strDivision="", strDesgn="", strSex="", strPhone="";
            
            // Get session
            HttpSession curSession=request.getSession(false);
            // Check if valid session
            if(curSession==null)
{
               // objLog.error("Invalid session");
                request.setAttribute("flag",strFlag);
                view=request.getRequestDispatcher("sessionError.jsp");
                view.forward(request, response);
            }
            
            else //valid session
            {
                if((String)curSession.getAttribute("userid")==null)
{
                   // objLog.error("Invalid session");
                    request.setAttribute("flag",strFlag);
                    view=request.getRequestDispatcher("sessionError.jsp");
                    view.forward(request, response);
                }
                else
                {
                     //get staffcode of logged in person
                    strStaffcode=(String)curSession.getAttribute("userid");
                   // objLog.info("Staffcode of logged in officer: "+strStaffcode);
                    
                   // strStaffcode=request.getParameter("txtStaffcode");
                    strShift=request.getParameter("cboShift");
                    strDutyDate=d1.savedate(request.getParameter("txtDutydate"));
                    strName=request.getParameter("txtName");
                    strDivision=request.getParameter("txtDivision");
                    strDesgn=request.getParameter("txtDesgn");
                    strSex=request.getParameter("cboSex");
                    strPhone=request.getParameter("txtPhone");
                    strFlagDO=request.getParameter("flagDO");
                    strFlagReserve=request.getParameter("flagReserve");
                   
                    
                    strQuery="select sysdate()";
                    rs1=stmt.executeQuery(strQuery);
                    if(rs1.first())
                    {
                        strLoginDateTime=rs1.getString(1);
                         strLoginDateTime=strLoginDateTime.substring(0,19);
                       // objLog.info("Login Time: "+strLoginDateTime);
                    }
                    rs1.close();
                    //update scheduled status to N if logindatetime is null for previous day's DOs                    
                    
                   stmt.executeUpdate("update anyshiftdo set scheduled='N' where empcode in (select empcode from doschedule where (datediff(curdate(),scheduledate)=1 or datediff(curdate(),scheduledate)=2) and logindatetime='0000-00-00 00:00:00')");
                   stmt.executeUpdate("update firstshiftdo set scheduled='N' where empcode in (select empcode from doschedule where (datediff(curdate(),scheduledate)=1 or datediff(curdate(),scheduledate)=2) and logindatetime='0000-00-00 00:00:00')");
                    
                    if (strFlagDO.equals("true")) //in dodetails
                    {
                        //update anyshift/firstshiftdo
                      strQuery="update firstshiftdo set prevshift2=prevshift1, prevshift1='"+strShift+"', scheduled='N', prevdutydate='"+strDutyDate+"' where empcode='"+strStaffcode+"'";
                      //objLog.info(strQuery);
                      stmt.executeUpdate(strQuery);
                      strQuery="update anyshiftdo set prevshift2=prevshift1, prevshift1='"+strShift+"', scheduled='N', prevdutydate='"+strDutyDate+"' where empcode='"+strStaffcode+"'";
                     // objLog.info(strQuery);
                      stmt.executeUpdate(strQuery);
                      
                      //update dodetails
                      if (strShift.equals("FIRST"))
                      {
                        strQuery="update dodetails set nooffirstshift=nooffirstshift+1 where empcode='"+strStaffcode+"'";
                      }
                      else
                      {
                          strQuery="update dodetails set noofsecondshift=noofsecondshift+1 where empcode='"+strStaffcode+"'";
                      }                     
                      stmt.executeUpdate(strQuery);                     
                      
                    }
                    else
                    {
                        if(strFlagReserve.equals("true"))
                        {
                             strQuery="update reservelist set empname='"+strName+"', division='"+strDivision+"', designation='"+strDesgn+"',sex='"+strSex+"',phone='"+strPhone+"' where empcode='"+strStaffcode+"'";
                             //objLog.info(strQuery);
                             stmt.executeUpdate(strQuery);
                        }
                        else
                        {
                            strQuery="insert into reservelist values('"+strStaffcode+"','"+strName+"', '"+strDivision+"','"+strDesgn+"','"+strSex+"','"+strPhone+"' )";
                           // objLog.info(strQuery);
                            stmt.executeUpdate(strQuery);
                        }
                    }
                   
                   //check if he is in doschedule on the same date & shift
                   strQuery = "select * from doschedule where empcode='"+strStaffcode+"' and scheduledate='"+strDutyDate+"' and shift='"+strShift+"' ";
                   rs1=stmt1.executeQuery(strQuery);
                    if(rs1.first()) 
                    {
                        stmt.executeUpdate("update doschedule set logindatetime='"+strLoginDateTime+"' where empcode='"+strStaffcode+"' and scheduledate='"+strDutyDate+"' and shift='"+strShift+"'");
                       // objLog.info(strQuery);
                    }
                    else
                    {                  
                       strQuery="insert into reservedutydone values('"+strStaffcode+"','"+strDutyDate+"', '"+strShift+"','"+strLoginDateTime+"')";
                       // objLog.info(strQuery);
                        stmt.executeUpdate(strQuery);
                    }
                   rs1.close();
                   
                    view=request.getRequestDispatcher("getReserveDetails.do");
                        view.forward(request, response);
                }
            }
        }
catch(Exception e)
{
   // objLog.error("ERROR : "+e);
    view = request.getRequestDispatcher("Failure.jsp");
    view.forward(request, response);
}
finally
{
    db.close();
}
    }
}
