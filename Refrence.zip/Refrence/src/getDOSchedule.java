// Function : get role details from role table
// Author   : Gadha PS, Anju Varghese
// Division : COM/CIG
// Date     : 28/01/2009

import java.io.*;
import java.util.*;
import java.util.Date;
import java.text.*;
import java.lang.String;
import java.sql.*;
import java.net.*;
import javax.servlet.*;
import javax.servlet.http.*;
import org.apache.log4j.Logger;
import dateform.*;

public class getDOSchedule extends HttpServlet {
    
    protected void doGet(HttpServletRequest request, HttpServletResponse response)
    throws ServletException, IOException {
        doPost(request,response);
    }
    
    protected void doPost(HttpServletRequest request, HttpServletResponse response)
    throws ServletException, IOException {
        
        RequestDispatcher view = null;
        PrintWriter out= response.getWriter();
        dbConn db=new dbConn();
        dateformat d1=new dateformat();
       // Logger //objLog = Logger.getLogger("ApplicationDO");
        try
{
            Connection conn= null;
            conn = db.Connect();
            Statement stmt = conn.createStatement();
            Statement stmt2 = conn.createStatement();
            Statement stmt3 = conn.createStatement();
            ResultSet rs1=null, rs2=null, rs3=null;
            String strFlag="invalidSession", strStaffcode="", strQuery="", strStartdate="", strEnddate="", strScheduleno="", strExFlag="false", strConFlag="false";
            String strScheduleDate="", strShift="", strConfirm="", strReqFlag="false", strReqEmpname="", strEmpConfirm="", strReqToEmpname="";
            int days=0;
            ArrayList arSchedule=new ArrayList(); //schedule
            
            // Get session
            HttpSession curSession=request.getSession(false);
            // Check if valid session
            if(curSession==null)
{
                //objLog.error("Invalid session");
                request.setAttribute("flag",strFlag);
                view=request.getRequestDispatcher("sessionError.jsp");
                view.forward(request, response);
            }
            
            else //valid session
            {
                if((String)curSession.getAttribute("userid")==null)
{
                    //objLog.error("Invalid session");
                    request.setAttribute("flag",strFlag);
                    view=request.getRequestDispatcher("sessionError.jsp");
                    view.forward(request, response);
                }
                else
                {
                    strStaffcode=(String)curSession.getAttribute("userid");
                    //objLog.info("Logged in DO: "+strStaffcode);
                    
                    //get latest schedule of DO
                    strQuery="select startdate, enddate, scheduleno from scheduledetails   where scheduleno in (select scheduleno from doschedule where empcode='"+strStaffcode+"' and scheduledate in (select max(scheduledate) from doschedule where empcode='"+strStaffcode+"'))";
                    //objLog.info(strQuery);
                    rs1=stmt.executeQuery(strQuery);
                    if (rs1.next())
                    {
                        strStartdate=rs1.getString(1);
                        strEnddate=rs1.getString(2);
                        strScheduleno=rs1.getString(3);
                        
                        strQuery="select datediff(scheduledate, curdate()), scheduledate, shift, confirm from doschedule where scheduleno='"+strScheduleno+"' and empcode='"+strStaffcode+"'";
                        rs2=stmt2.executeQuery(strQuery);
                        if (rs2.next())
                        {
                            days=rs2.getInt(1);
                            //objLog.info("Difference in days: "+days);
                            strScheduleDate=d1.datedisplay(rs2.getString(2));
                            strShift=rs2.getString(3);
                            strEmpConfirm=rs2.getString(4);
                        }
                        rs2.close();
                        
                        //enable Exchange DO link only if duty date is 2 days after current date
                        if (days>=2)
                        {
                            strExFlag="true";
                            //objLog.info("Exchange flag: "+strExFlag);
                        }
                        //enable Confirm link only if duty date is after current date
                        
                        if (days>0)
                        {
                            strConFlag="true";
                            //objLog.info("Confirm flag: "+strConFlag);
                        }
                        
                        //If exchange of duty requested & no action taken, dont display confirm message(both button & text)
                        //Else if confirm='N', display button, else display text
                        
                        strQuery="select empcode2 from exchangedo where empcode1='"+strStaffcode+"' and exchangeflag='1' and scheduledate>curdate()";
                        rs2=stmt2.executeQuery(strQuery);
                        if (rs2.next())
                        {
                            strConfirm="NO"; //no display
                            strQuery="select empname from dodetails where empcode='"+rs2.getString(1)+"'";
                            rs3=stmt3.executeQuery(strQuery);
                            if (rs3.next())
                            {
                                strReqToEmpname=rs3.getString(1);
                            }
                            rs3.close();
                        }
                        else
                        {
                            if (strEmpConfirm.equals("Y"))
                            {
                                strConfirm="TEXT"; //display message
                            }
                            else
                            {
                                strConfirm="BUTTON"; //display button
                            }
                        }
                        rs2.close();
                        
                        //objLog.info("Confirm: "+strConfirm);
                        
                        //show pending exchange duty request only if scheduledate>curdate and flag=1
                        
                        strQuery="select empcode1 from exchangedo where empcode2='"+strStaffcode+"' and exchangeflag='1' and scheduledate between '"+strStartdate+"' and '"+strEnddate+"' and scheduledate>curdate()";
                        rs2=stmt2.executeQuery(strQuery);
                        //objLog.info(strQuery);
                        if (rs2.next())
                        {
                            strReqFlag="true";
                            //objLog.info("Request flag: "+strReqFlag);
                            strQuery="select empname from dodetails where empcode='"+rs2.getString(1)+"'";
                            rs3=stmt3.executeQuery(strQuery);
                            if (rs3.next())
                            {
                                strReqEmpname=rs3.getString(1);
                            }
                            rs3.close();
                        }
                        rs2.close();
                        
                        strQuery="select * from exchangedo where (empcode1='"+strStaffcode+"' or empcode2='"+strStaffcode+"') and exchangeflag='1'";
                        //objLog.info(strQuery);
                        rs2=stmt2.executeQuery(strQuery);
                        if(rs2.first())
                        {
                            strExFlag="false";
                             //objLog.info("Exchange flag: "+strExFlag);
                        }
                        rs2.close();
                        
                        //select schedule list
                        strQuery = "SELECT scheduledate,dayofweek(scheduledate),a.shift,empname,a.empcode,division,sex,boardingpt,confirm,designation,sittingphone,resphone,mobile ";
                        strQuery = strQuery + "FROM doschedule a, doaddress b, dodetails c where (a.scheduledate between '"+strStartdate+"' and '"+strEnddate+"') and ";
                        strQuery = strQuery + "a.empcode=b.empcode  and a.empcode=c.empcode order by scheduledate, a.shift,empname";
                        rs2=stmt2.executeQuery(strQuery);       
                        //objLog.info("dodetail query "+strQuery);
                        while (rs2.next())
                        {   
                                                    
                            arSchedule.add(d1.datedisplay(rs2.getString(1)));
                            arSchedule.add(rs2.getString(2));
                            arSchedule.add(rs2.getString(3));
                            arSchedule.add(rs2.getString(4));
                            arSchedule.add(rs2.getString(5));
                            arSchedule.add(rs2.getString(6));
                            arSchedule.add(rs2.getString(7));
                            arSchedule.add(rs2.getString(8));
                          //  //objLog.info("boarding poing "+rs2.getString(8));
                            arSchedule.add(rs2.getString(9));
                            arSchedule.add(rs2.getString(10));
                            arSchedule.add(rs2.getString(11));                            
                            arSchedule.add(rs2.getString(12));    
                            arSchedule.add(rs2.getString(13));
                        }
                        rs2.close();
                        
                        strStartdate=d1.datedisplay(strStartdate);
                    strEnddate=d1.datedisplay(strEnddate);
                        
                    
                     request.setAttribute("StartDate",strStartdate);
                     request.setAttribute("EndDate",strEnddate);
                      request.setAttribute("arSchedule",arSchedule);
                       request.setAttribute("ExFlag",strExFlag);
                       request.setAttribute("ConFlag",strConFlag);
                       request.setAttribute("scheduledate",strScheduleDate);
                       request.setAttribute("shift",strShift);
                        request.setAttribute("confirm",strConfirm);
                         request.setAttribute("ReqFlag",strReqFlag);
                         request.setAttribute("ReqName",strReqEmpname);
                         request.setAttribute("ReqToName",strReqToEmpname);
                    
                       view=request.getRequestDispatcher("viewDOSchedule.jsp");
                    view.forward(request, response);
                    }
                    else //DO not in any schedule
                    {
                        view=request.getRequestDispatcher("getSchedule.do?path=default");
                        view.forward(request, response);
                    }
                    rs1.close();
                    
                    
                    
                }
            }
        }
catch(Exception e)
{
    //objLog.error("ERROR : "+e);
    view = request.getRequestDispatcher("Failure.jsp");
    view.forward(request, response);
}
finally
{
    db.close();
}
    }
}
