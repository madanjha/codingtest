package com.example.demo.model;

public enum ProductType {

	CONSUMER_ELECTRONICS,
	HOUSE_HOLD
}
