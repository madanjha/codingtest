/*
  --- menu level scope settins structure --- 
  note that this structure has changed its format since previous version.
  Now this structure has the same layout as Tigra Menu GOLD.
  Format description can be found in product documentation.
*/
var MENU_POS_SIDE = [
{
	// item sizes
	'height': 16,
	'width': 130,
	// menu block offset from the origin:
	//	for root level origin is upper left corner of the page
	//	for other levels origin is upper left corner of parent item
	'block_top': 23,
	'block_left': 45,
	// offsets between items of the same level
	'top': 22,
	'left': 0,
	// time in milliseconds before menu is hidden after cursor has gone out
	// of any items
	'hide_delay': 200,
	'css' : {
		'outer' : ['m0l0oouts', 'm0l0oovers'],
		'inner' : ['m0l0iouts', 'm0l0iovers']
	}	
},
{
	'width': 130,
      'block_top': 8,
	'block_left': 120,
	'css' : {
		'outer' : ['m0l1oouts', 'm0l1oovers'],
		'inner' : ['m0l1iouts', 'm0l1iovers']
	}
}
];